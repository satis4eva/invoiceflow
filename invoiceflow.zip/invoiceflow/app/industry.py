"""Industry profiles: which extra details to capture, matching tolerances, starter rules and
industry-specific checks (for example CIS and the domestic reverse charge in construction)."""
from .validation import issue

# Extra header fields: key -> label. Line fields: key -> label. Captured by AI and editable in review.
COMMON_HEADER = {"delivery_note": "Delivery note", "reference": "Project / job / cost centre"}

PROFILES = {
    "general": {
        "label": "General",
        "header": {**COMMON_HEADER},
        "line": {"code": "Product code"},
        "hint": "",
        "settings": {"match_type": "two_way", "price_tol_pct": 2.0, "qty_tol_pct": 0.0, "total_tol": 1.00,
                     "require_po": False, "auto_approve_matched": False, "carriage_allowance": 0.0},
        "rules": [],
    },
    "construction": {
        "label": "Construction",
        "header": {**COMMON_HEADER, "site": "Site", "application_no": "Application for payment no.",
                   "cis_labour": "CIS labour amount", "cis_materials": "CIS materials amount",
                   "cis_rate": "CIS deduction rate %", "cis_deduction": "CIS deduction",
                   "retention_pct": "Retention %", "retention_amount": "Retention amount",
                   "reverse_charge": "Domestic reverse charge (yes/no)"},
        "line": {"code": "Item code", "unit": "Unit"},
        "hint": ("UK construction invoice. Capture CIS (Construction Industry Scheme) labour and materials split, CIS "
                 "deduction rate and amount, retention percentage and amount, application for payment number, site, "
                 "and whether the invoice says 'reverse charge: customer to account for VAT to HMRC'."),
        "settings": {"match_type": "three_way", "price_tol_pct": 0.0, "qty_tol_pct": 0.0, "total_tol": 1.00,
                     "require_po": True, "auto_approve_matched": False, "carriage_allowance": 0.0},
        "rules": [
            {"name": "Subcontractor invoices over £10,000 need a manager", "when": [{"field": "gross_total", "op": "gt", "value": "10000"}],
             "action": "needs_manager", "message": "Over £10,000: a manager must approve"},
        ],
    },
    "building_supplies": {
        "label": "Building supplies",
        "header": {**COMMON_HEADER, "site": "Delivery site", "account_no": "Customer account no."},
        "line": {"code": "Product code", "unit": "Unit", "pack": "Pack size"},
        "hint": "Builders' merchant invoice. Capture delivery note / ticket numbers, delivery site, product codes, units, "
                "and any pallet or returnable deposit charges as separate lines.",
        "settings": {"match_type": "three_way", "price_tol_pct": 0.0, "qty_tol_pct": 0.0, "total_tol": 0.50,
                     "require_po": True, "auto_approve_matched": True, "carriage_allowance": 25.0},
        "rules": [],
    },
    "engineering": {
        "label": "Engineering",
        "header": {**COMMON_HEADER, "job_no": "Job / works order no."},
        "line": {"code": "Part number", "unit": "Unit"},
        "hint": "Engineering invoice. Capture job or works order numbers, part numbers and units.",
        "settings": {"match_type": "three_way", "price_tol_pct": 1.0, "qty_tol_pct": 0.0, "total_tol": 1.00,
                     "require_po": True, "auto_approve_matched": True, "carriage_allowance": 30.0},
        "rules": [],
    },
    "food_beverage": {
        "label": "Food & beverage",
        "header": {**COMMON_HEADER, "delivery_date": "Delivery date"},
        "line": {"code": "Product code", "unit": "Unit (kg, case)", "batch": "Batch / lot", "best_before": "Best before"},
        "hint": "Food and drink supplier invoice. Capture product codes, units (kg, case, each), batch or lot numbers, "
                "best-before dates, and the VAT rate per line (many food items are zero-rated, others 20%).",
        "settings": {"match_type": "three_way", "price_tol_pct": 2.0, "qty_tol_pct": 5.0, "total_tol": 1.00,
                     "require_po": False, "auto_approve_matched": True, "carriage_allowance": 15.0},
        "rules": [],
    },
    "manufacturing": {
        "label": "Manufacturing, logistics & supply chain",
        "header": {**COMMON_HEADER, "incoterms": "Incoterms", "customs_ref": "Customs / import entry ref"},
        "line": {"code": "Part number", "unit": "Unit", "commodity_code": "Commodity code"},
        "hint": "Manufacturing or logistics invoice. Capture part numbers, units, commodity codes, Incoterms, customs or "
                "import entry references, and freight, carriage, duty and surcharges as separate lines.",
        "settings": {"match_type": "three_way", "price_tol_pct": 1.0, "qty_tol_pct": 2.0, "total_tol": 2.00,
                     "require_po": True, "auto_approve_matched": True, "carriage_allowance": 50.0},
        "rules": [],
    },
    "medical": {
        "label": "Medical & pharmaceuticals",
        "header": {**COMMON_HEADER},
        "line": {"code": "Product code", "unit": "Unit", "batch": "Batch / lot", "expiry": "Expiry date"},
        "hint": "Medical or pharmaceutical invoice. Capture product codes, batch or lot numbers, expiry dates and per-line "
                "VAT rates (some items are zero-rated).",
        "settings": {"match_type": "three_way", "price_tol_pct": 0.0, "qty_tol_pct": 0.0, "total_tol": 0.50,
                     "require_po": True, "auto_approve_matched": False, "carriage_allowance": 0.0},
        "rules": [],
    },
    "retail": {
        "label": "Retail",
        "header": {**COMMON_HEADER, "store": "Store / branch"},
        "line": {"code": "SKU", "ean": "EAN / barcode", "pack": "Pack size"},
        "hint": "Retail supplier invoice. Capture SKU, EAN barcodes, pack or case sizes, store or branch, and any "
                "promotional discounts.",
        "settings": {"match_type": "three_way", "price_tol_pct": 0.0, "qty_tol_pct": 0.0, "total_tol": 0.50,
                     "require_po": True, "auto_approve_matched": True, "carriage_allowance": 0.0},
        "rules": [],
    },
    "automotive": {
        "label": "Automotive",
        "header": {**COMMON_HEADER, "vehicle_reg": "Vehicle registration", "job_card": "Job card no."},
        "line": {"code": "Part number", "unit": "Unit"},
        "hint": "Automotive invoice. Capture part numbers, vehicle registration or VIN, and job card numbers.",
        "settings": {"match_type": "two_way", "price_tol_pct": 1.0, "qty_tol_pct": 0.0, "total_tol": 1.00,
                     "require_po": False, "auto_approve_matched": True, "carriage_allowance": 20.0},
        "rules": [],
    },
    "energy": {
        "label": "Energy & utilities",
        "header": {**COMMON_HEADER, "meter": "Meter (MPAN / MPRN)", "period_start": "Billing period from",
                   "period_end": "Billing period to", "consumption": "Consumption (kWh)", "asset": "Asset / site"},
        "line": {"code": "Rate / item code", "unit": "Unit"},
        "hint": "Energy, utility or contractor invoice. Capture meter numbers (MPAN for electricity, MPRN for gas), "
                "billing period start and end dates, consumption in kWh, climate change levy, asset or site, and for "
                "contractors the work order and agreed rates.",
        "settings": {"match_type": "two_way", "price_tol_pct": 0.0, "qty_tol_pct": 0.0, "total_tol": 1.00,
                     "require_po": False, "auto_approve_matched": False, "carriage_allowance": 0.0},
        "rules": [
            {"name": "Energy bills must show the billing period", "when": [{"field": "extras.period_end", "op": "is_empty", "value": ""}],
             "action": "warning", "message": "No billing period found - check for estimated or duplicate periods"},
        ],
    },
}

ORDER = ["general", "construction", "building_supplies", "engineering", "food_beverage", "manufacturing",
         "medical", "retail", "automotive", "energy"]


def get(key: str | None) -> dict:
    return PROFILES.get(key or "general") or PROFILES["general"]


def _num(v):
    try:
        return float(str(v).replace(",", "").replace("£", "").replace("%", "").strip())
    except (TypeError, ValueError):
        return None


def _yes(v) -> bool:
    return str(v or "").strip().lower() in ("yes", "y", "true", "1")


def amount_payable(inv: dict) -> float | None:
    """Gross less CIS deduction and retention, where present."""
    gross = inv.get("gross_total")
    if gross is None:
        return None
    ex = inv.get("extras") or {}
    less = (_num(ex.get("cis_deduction")) or 0) + (_num(ex.get("retention_amount")) or 0)
    return round(gross - less, 2) if less else None


def checks(inv: dict, profile_key: str) -> list[dict]:
    """Industry-specific validation."""
    out = []
    ex = inv.get("extras") or {}
    if profile_key == "construction":
        if _yes(ex.get("reverse_charge")):
            if inv.get("vat_total"):
                out.append(issue("error", "reverse_charge_vat",
                                 "Marked as domestic reverse charge, but VAT has been charged. Reverse-charge invoices "
                                 "show VAT as zero and you account for it to HMRC."))
            if not inv.get("supplier_vat_number"):
                out.append(issue("warning", "reverse_charge_no_vat_no", "Reverse-charge invoice without the supplier's VAT number"))
        labour, rate, ded = _num(ex.get("cis_labour")), _num(ex.get("cis_rate")), _num(ex.get("cis_deduction"))
        if rate is not None and rate not in (0, 20, 30):
            out.append(issue("error", "cis_rate", f"CIS deduction rate {rate:g}% isn't 0%, 20% or 30%"))
        if labour is not None and rate is not None and ded is not None and abs(labour * rate / 100 - ded) > 1:
            out.append(issue("error", "cis_maths",
                             f"CIS deduction should be {labour * rate / 100:.2f} ({rate:g}% of labour {labour:.2f}), not {ded:.2f}"))
        if ded and labour is None:
            out.append(issue("warning", "cis_no_labour", "CIS deducted but the labour amount isn't shown - CIS applies to labour only"))
        mats = _num(ex.get("cis_materials"))
        if labour is not None and mats is not None and inv.get("net_total") is not None and \
                abs(labour + mats - inv["net_total"]) > 1:
            out.append(issue("warning", "cis_split", f"Labour {labour:.2f} + materials {mats:.2f} doesn't equal net {inv['net_total']:.2f}"))
        pct, amt = _num(ex.get("retention_pct")), _num(ex.get("retention_amount"))
        if pct and amt is not None and inv.get("net_total") and abs(inv["net_total"] * pct / 100 - amt) > 1:
            out.append(issue("warning", "retention_maths", f"Retention of {pct:g}% should be about {inv['net_total'] * pct / 100:.2f}"))
    if profile_key == "energy":
        s, e = ex.get("period_start"), ex.get("period_end")
        if s and e and str(e) < str(s):
            out.append(issue("error", "period_order", "Billing period ends before it starts"))
        rates = {l.get("vat_rate") for l in inv.get("line_items") or [] if l.get("vat_rate") is not None}
        if 5.0 in rates:
            out.append(issue("info", "reduced_rate", "5% VAT charged - correct only for qualifying domestic or de minimis supply"))
    if profile_key in ("food_beverage", "medical"):
        for n, l in enumerate(inv.get("line_items") or [], 1):
            lx = l.get("extras") or {}
            exp = lx.get("best_before") or lx.get("expiry")
            if exp and inv.get("invoice_date") and str(exp) < str(inv["invoice_date"]):
                out.append(issue("warning", "expired_stock", f"Line {n}: date {exp} is before the invoice date"))
    return out
