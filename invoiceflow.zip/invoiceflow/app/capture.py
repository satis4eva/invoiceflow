"""Phone photo link: a client opens a secret link, snaps invoices and receipts, and they land
in that business's queue for the accountant. No login needed; the link can be replaced or switched off."""
import json
import secrets
import time
from urllib.parse import quote

from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from . import accounts, config, db, pipeline
from .web import Ctx, back, csrf_token, flash, form_checked, guarded, render, templates

MAX_FILES = 20
_hits: dict[str, list[float]] = {}


def _rate_ok(key: str, limit: int = 60, window: int = 3600) -> bool:
    now = time.time()
    recent = [t for t in _hits.get(key, []) if now - t < window]
    _hits[key] = recent
    return len(recent) < limit


def new_token() -> str:
    return secrets.token_urlsafe(24)


def ensure_token(business: dict) -> str:
    if not business.get("capture_token"):
        token = new_token()
        db.set_capture(business["id"], token=token)
        business["capture_token"] = token
    return business["capture_token"]


def link_for(business: dict) -> str:
    return f"{config.BASE_URL.rstrip('/')}/c/{ensure_token(business)}"


def _lookup(token: str) -> tuple[dict | None, dict | None, str]:
    """Return (business, tenant, problem)."""
    business = db.business_by_capture_token(token)
    if not business or not business.get("capture_enabled", 1):
        return None, None, "This link isn't active any more. Ask your accountant for a new one."
    tenant = db.get_tenant(business["tenant_id"])
    if not tenant or not accounts.access(tenant)["ok"]:
        return business, tenant, "Uploads are paused for this account at the moment. Please contact your accountant."
    return business, tenant, ""


async def page(request: Request):
    token = request.path_params["token"]
    business, tenant, problem = _lookup(token)
    if not business:
        return templates.TemplateResponse(request, "capture.html", {
            "request": request, "problem": problem, "business": None, "tenant": None, "token": token,
            "csrf": "", "sent": None}, status_code=404)
    return templates.TemplateResponse(request, "capture.html", {
        "request": request, "problem": problem, "business": business, "tenant": tenant, "token": token,
        "csrf": csrf_token(request), "sent": request.query_params.get("sent")})


async def receive(request: Request):
    token = request.path_params["token"]
    business, tenant, problem = _lookup(token)
    wants_json = "application/json" in request.headers.get("accept", "")

    def fail(msg: str, code: int = 400):
        if wants_json:
            return JSONResponse({"ok": False, "error": msg}, status_code=code)
        return templates.TemplateResponse(request, "capture.html", {
            "request": request, "problem": msg, "business": business, "tenant": tenant, "token": token,
            "csrf": csrf_token(request), "sent": None}, status_code=code)

    if problem:
        return fail(problem, 403)
    ip = request.client.host if request.client else ""
    if not _rate_ok(f"{token}|{ip}"):
        return fail("Too many uploads in the last hour. Please try again later.", 429)
    try:
        form = await form_checked(request)
    except PermissionError:
        return fail("The page was open too long. Reload it and try again.")

    files = [f for f in form.getlist("files") if getattr(f, "filename", "")][:MAX_FILES]
    if not files:
        return fail("Take a photo or choose a file first.")
    allowance, _ = accounts.upload_allowance(tenant)
    if allowance is not None and allowance < len(files):
        if allowance == 0:
            return fail("Your accountant's account has reached its limit for this month. Please let them know.", 403)
        files = files[:allowance]
    note = str(form.get("note", ""))[:500]
    ok, bad = 0, []
    for f in files:
        try:
            pipeline.process_upload(business, f.filename or "photo.jpg", await f.read(), "client via photo link",
                                    accounts.has_feature(tenant, "supplier_memory"), source="client_link", note=note)
            ok += 1
        except Exception as exc:
            bad.append(f"{f.filename}: {exc}")
    for _ in range(ok):
        _hits.setdefault(f"{token}|{ip}", []).append(time.time())
    if wants_json:
        return JSONResponse({"ok": ok > 0, "received": ok, "errors": bad})
    return back(f"/c/{token}?sent={ok}")


async def manifest(request: Request):
    token = request.path_params["token"]
    business = db.business_by_capture_token(token)
    if not business:
        return Response(status_code=404)
    data = {
        "name": f"Send to accountant - {business['name']}",
        "short_name": "Send invoices",
        "start_url": f"/c/{token}",
        "scope": f"/c/{token}",
        "display": "standalone",
        "background_color": "#f6f8fa",
        "theme_color": "#24427c",
        "icons": [{"src": "/static/icon.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any"}],
    }
    return Response(json.dumps(data), media_type="application/manifest+json")


# ---- managing the link (accountant side) ------------------------------------------------

@guarded("app")
async def manage(request: Request, c: Ctx):
    link = link_for(c.business)
    biz = db.get_business(c.business["id"])
    msg = (f"Hi, you can send me your invoices and receipts for {c.business['name']} from your phone: "
           f"open {link}, take a photo and press Send. Tip: add the page to your home screen.")
    clients = db.q("""SELECT COUNT(*) c, MAX(created_at) last FROM invoices
                      WHERE business_id = ? AND source = 'client_link'""", (c.business["id"],))[0]
    return render(request, "capture_manage.html", c, link=link, enabled=bool(biz.get("capture_enabled", 1)),
                  whatsapp=f"https://wa.me/?text={quote(msg)}", sms=f"sms:?&body={quote(msg)}",
                  mailto=f"mailto:?subject={quote('Send me your invoices from your phone')}&body={quote(msg)}",
                  message=msg, stats=clients)


@guarded("manager")
async def manage_post(request: Request, c: Ctx):
    form = await form_checked(request)
    action = form.get("action")
    if action == "replace":
        db.set_capture(c.business["id"], token=new_token(), enabled=True)
        db.admin_log(c.tenant["id"], "photo_link_replaced", c.business["name"], c.who)
        flash(request, "New link made. The old link no longer works, so send the new one to your client.")
    elif action == "off":
        db.set_capture(c.business["id"], enabled=False)
        flash(request, "Photo link switched off. Nothing more can be sent through it.")
    elif action == "on":
        db.set_capture(c.business["id"], enabled=True)
        flash(request, "Photo link switched on.")
    return back("/send-link")


routes = [
    Route("/c/{token}", page),
    Route("/c/{token}", receive, methods=["POST"]),
    Route("/c/{token}/manifest.json", manifest),
    Route("/send-link", manage),
    Route("/send-link", manage_post, methods=["POST"]),
]
