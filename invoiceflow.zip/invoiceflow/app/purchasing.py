"""Purchasing: purchase orders (e-ordering), supplier acknowledgements, goods received, suppliers."""
import csv
import io
import json
import re
import secrets
import uuid
from datetime import date
from pathlib import Path

from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Route

from . import bankfiles, config, db, einvoice, extraction, mailboxes, mailer, matching, peppol, po_pdf, rules, xero
from .esign import _deliver
from .web import Ctx, back, csrf_token, flash, form_checked, guarded, render, templates

PO_STATUS = {"draft": "Draft", "awaiting_approval": "Awaiting approval", "approved": "Approved", "sent": "Sent",
             "acknowledged": "Confirmed by supplier", "rejected": "Rejected by supplier",
             "part_received": "Part received", "received": "Received", "closed": "Closed", "cancelled": "Cancelled"}
STAMP = {"draft": "posted", "awaiting_approval": "ready", "approved": "ready", "sent": "posted",
         "acknowledged": "approved", "rejected": "needs_review", "part_received": "ready", "received": "approved",
         "closed": "rejected", "cancelled": "rejected"}
MAX_LINES = 60


def _f(v):
    try:
        return round(float(str(v).replace(",", "").replace("£", "").strip()), 4) if str(v or "").strip() else None
    except ValueError:
        return None


def load(po_id: int, business_id: int) -> dict | None:
    po = db.q1("SELECT * FROM purchase_orders WHERE id = ? AND business_id = ?", (po_id, business_id))
    if po:
        po["lines"] = json.loads(po["lines"] or "[]")
    return po


def totals(lines: list[dict]) -> tuple[float, float, float]:
    net = round(sum((l.get("qty") or 0) * (l.get("unit_price") or 0) for l in lines), 2)
    vat = round(sum((l.get("qty") or 0) * (l.get("unit_price") or 0) * (l.get("vat_rate") or 0) / 100 for l in lines), 2)
    return net, vat, round(net + vat, 2)


def next_number(business_id: int) -> str:
    prefix = rules.settings_for(business_id).get("po_prefix") or "PO-"
    nums = [int(m.group(1)) for r in db.q("SELECT po_number FROM purchase_orders WHERE business_id = ?", (business_id,))
            if (m := re.search(r"(\d+)$", r["po_number"]))]
    return f"{prefix}{(max(nums) + 1) if nums else 1:05d}"


def _gate(request: Request, c: Ctx):
    if not c.can("matching"):
        return render(request, "upgrade.html", c, feature="Purchasing and 3-way matching",
                      blurb="Raise purchase orders, send them to suppliers electronically, record goods received and "
                            "let invoices match themselves against the order and the delivery.")
    return None


def _lines_from_form(form) -> list[dict]:
    lines = []
    for i in range(MAX_LINES):
        desc = str(form.get(f"l{i}_description", "")).strip()
        if not desc:
            continue
        lines.append({"line": len(lines) + 1, "code": str(form.get(f"l{i}_code", "")).strip()[:60] or None,
                      "description": desc[:300], "qty": _f(form.get(f"l{i}_qty")) or 0,
                      "unit": str(form.get(f"l{i}_unit", "")).strip()[:20] or None,
                      "unit_price": _f(form.get(f"l{i}_unit_price")) or 0,
                      "vat_rate": _f(form.get(f"l{i}_vat_rate")) if _f(form.get(f"l{i}_vat_rate")) is not None else 20.0,
                      "account_code": str(form.get(f"l{i}_account_code", "")).strip()[:20] or None})
    return lines


def _needs_approval(c: Ctx, gross: float) -> bool:
    limit = float(rules.settings_for(c.business["id"]).get("po_approval_limit") or 0)
    return bool(limit) and gross > limit and not c.is_manager()


# ---- list / create / edit ---------------------------------------------------------------------

@guarded("app")
async def po_list(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    status = request.query_params.get("status", "")
    sql, args = "SELECT * FROM purchase_orders WHERE business_id = ?", [c.business["id"]]
    if status == "open":
        sql += " AND status IN ('approved','sent','acknowledged','part_received')"
    elif status:
        sql += " AND status = ?"
        args.append(status)
    rows = db.q(sql + " ORDER BY id DESC LIMIT 500", args)
    return render(request, "po_list.html", c, rows=rows, status=status, PO_STATUS=PO_STATUS, STAMP=STAMP,
                  xero_ok=bool(xero.connection(c.business["id"])))


def _form_ctx(c: Ctx, po: dict | None, error: str | None = None, values: dict | None = None) -> dict:
    return {"po": po, "error": error, "values": values or {}, "suppliers": db.list_suppliers(c.business["id"]),
            "MAX_LINES": MAX_LINES, "default_number": next_number(c.business["id"]),
            "limit": float(rules.settings_for(c.business["id"]).get("po_approval_limit") or 0)}


@guarded("app")
async def po_new(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    if request.method == "GET":
        return render(request, "po_form.html", c, **_form_ctx(c, None))
    return await _save(request, c, None)


@guarded("app")
async def po_edit(request: Request, c: Ctx):
    po = load(int(request.path_params["id"]), c.business["id"])
    if not po or po["status"] not in ("draft", "awaiting_approval", "approved"):
        return back(f"/purchasing/{request.path_params['id']}")
    if request.method == "GET":
        return render(request, "po_form.html", c, **_form_ctx(c, po))
    return await _save(request, c, po)


async def _save(request: Request, c: Ctx, po: dict | None):
    form = await form_checked(request)
    v = {k: str(form.get(k, "")).strip() for k in ("po_number", "supplier_name", "supplier_email", "order_date",
                                                     "delivery_date", "delivery_address", "reference", "notes")}
    lines = _lines_from_form(form)
    error = None
    if not v["supplier_name"]:
        error = "Choose or type the supplier."
    elif not lines:
        error = "Add at least one line."
    elif v["supplier_email"] and not mailboxes.EMAIL_RE.match(v["supplier_email"]):
        error = "The supplier email doesn't look right."
    number = v["po_number"] or (po["po_number"] if po else next_number(c.business["id"]))
    clash = db.q1("SELECT id FROM purchase_orders WHERE business_id = ? AND po_number = ? AND id != ?",
                  (c.business["id"], number, po["id"] if po else -1))
    if not error and clash:
        error = f"PO number {number} is already used."
    if error:
        draft = {**(po or {}), **v, "lines": lines}
        return render(request, "po_form.html", c, **_form_ctx(c, draft if po else None, error, {**v, "lines": lines}))
    net, vat, gross = totals(lines)
    status = "awaiting_approval" if _needs_approval(c, gross) else "approved"
    if form.get("action") == "draft":
        status = "draft"
    values = {"po_number": number[:40], "supplier_name": v["supplier_name"][:200], "supplier_email": v["supplier_email"] or None,
              "order_date": v["order_date"] or date.today().isoformat(), "delivery_date": v["delivery_date"] or None,
              "delivery_address": v["delivery_address"][:300] or None, "reference": v["reference"][:120] or None,
              "notes": v["notes"][:2000] or None, "lines": json.dumps(lines), "net_total": net, "vat_total": vat,
              "gross_total": gross, "status": status, "updated_at": db.now()}
    if status == "approved":
        values["approved_by"] = c.who
    if po:
        sets = ", ".join(f"{k} = ?" for k in values)
        db.ex(f"UPDATE purchase_orders SET {sets} WHERE id = ?", [*values.values(), po["id"]])
        pid = po["id"]
    else:
        values.update({"tenant_id": c.tenant["id"], "business_id": c.business["id"], "created_by": c.who,
                       "created_at": db.now(), "source": "manual", "ack_token": secrets.token_urlsafe(24),
                       "currency": config.DEFAULT_CURRENCY})
        cols = ", ".join(values)
        pid = db.ex(f"INSERT INTO purchase_orders ({cols}) VALUES ({', '.join('?' for _ in values)})", list(values.values()))
    if v["supplier_email"]:
        db.save_supplier(c.business["id"], v["supplier_name"], {"email": v["supplier_email"]})
    if status == "awaiting_approval":
        flash(request, f"Saved. Orders over £{rules.settings_for(c.business['id']).get('po_approval_limit'):,.0f} "
                       "need an owner or admin to approve before sending.", "warn")
    elif form.get("action") == "send" and status == "approved":
        ok, msg = send_po(load(pid, c.business["id"]), c)
        flash(request, msg, "ok" if ok else "warn")
    else:
        flash(request, "Purchase order saved.")
    return back(f"/purchasing/{pid}")


# ---- detail and actions ----------------------------------------------------------------------

def _usage(po: dict) -> list[dict]:
    rec = matching.received_by_line(po["id"])
    inv = matching.invoiced_by_line(po["id"], None)
    out = []
    for i, l in enumerate(po["lines"]):
        n = int(l.get("line", i + 1))
        out.append({**l, "received": rec.get(n, 0), "invoiced": inv.get(n, 0),
                    "outstanding": max(0, (l.get("qty") or 0) - rec.get(n, 0))})
    return out


@guarded("app")
async def po_detail(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    po = load(int(request.path_params["id"]), c.business["id"])
    if not po:
        return Response("Not found", status_code=404)
    grns = db.q("SELECT * FROM goods_receipts WHERE po_id = ? ORDER BY id DESC", (po["id"],))
    for g in grns:
        g["lines"] = json.loads(g["lines"] or "[]")
    invoices = db.q("SELECT id, supplier_name, invoice_number, gross_total, status, match_status FROM invoices "
                    "WHERE po_id = ? ORDER BY id DESC", (po["id"],))
    supplier = db.get_supplier(c.business["id"], po["supplier_name"]) or {}
    return render(request, "po_detail.html", c, po=po, lines=_usage(po), grns=grns, invoices=invoices,
                  PO_STATUS=PO_STATUS, STAMP=STAMP, ack_link=f"{config.BASE_URL.rstrip('/')}/po/{po['ack_token']}",
                  can_peppol=peppol.configured() and peppol.valid_id(supplier.get("peppol_id")),
                  today=date.today().isoformat())


def send_po(po: dict, c: Ctx) -> tuple[bool, str]:
    supplier = db.get_supplier(c.business["id"], po["supplier_name"]) or {}
    link = f"{config.BASE_URL.rstrip('/')}/po/{po['ack_token']}"
    pdf = po_pdf.build(po, c.business["name"], link)
    xml = einvoice.order_xml(po, {"name": c.business["name"]}, c.business.get("peppol_id"), supplier.get("peppol_id"))
    sent_by = []
    if peppol.configured() and peppol.valid_id(supplier.get("peppol_id")) and peppol.valid_id(c.business.get("peppol_id")):
        ok, _ = peppol.send(c.business["peppol_id"], supplier["peppol_id"], "order", xml)
        if ok:
            sent_by.append("Peppol")
    email = po.get("supplier_email") or supplier.get("email")
    if email:
        body = (f"Hello,\n\nPlease find attached purchase order {po['po_number']} from {c.business['name']}"
                + (f", for delivery by {po['delivery_date']}" if po.get("delivery_date") else "") + ".\n\n"
                f"Please confirm the order using the button below, and quote {po['po_number']} on your delivery note "
                f"and invoice.\n\nThank you,\n{c.business['name']}")
        ok = _deliver(c.business, c.who, email, f"Purchase order {po['po_number']} from {c.business['name']}", body,
                      button=("Confirm this order", link),
                      attachments=[(f"{po['po_number']}.pdf", pdf, "application/pdf"),
                                   (f"{po['po_number']}.xml", xml, "application/xml")], related=f"po:{po['id']}")
        if ok:
            sent_by.append(f"email to {email}")
    if not sent_by:
        return False, "Couldn't send automatically. Add the supplier's email (and connect a mailbox), or download the PDF."
    db.ex("UPDATE purchase_orders SET status = 'sent', sent_at = ?, updated_at = ? WHERE id = ?",
          (db.now(), db.now(), po["id"]))
    return True, f"Sent {po['po_number']} by {' and '.join(sent_by)}."


@guarded("app")
async def po_action(request: Request, c: Ctx):
    po = load(int(request.path_params["id"]), c.business["id"])
    if not po:
        return Response(status_code=404)
    form = await form_checked(request)
    act = form.get("action")
    if act == "approve" and po["status"] in ("awaiting_approval", "draft"):
        if not c.is_manager() and _needs_approval(c, po["gross_total"] or 0):
            flash(request, "Only an owner or admin can approve this order.", "error")
        else:
            db.ex("UPDATE purchase_orders SET status = 'approved', approved_by = ?, updated_at = ? WHERE id = ?",
                  (c.who, db.now(), po["id"]))
            flash(request, "Order approved.")
    elif act == "send" and po["status"] in ("approved", "sent", "acknowledged", "rejected"):
        ok, msg = send_po(po, c)
        flash(request, msg, "ok" if ok else "warn")
    elif act == "mark_sent" and po["status"] == "approved":
        db.ex("UPDATE purchase_orders SET status = 'sent', sent_at = ? WHERE id = ?", (db.now(), po["id"]))
        flash(request, "Marked as sent.")
    elif act == "cancel" and po["status"] not in ("received", "closed"):
        db.ex("UPDATE purchase_orders SET status = 'cancelled', updated_at = ? WHERE id = ?", (db.now(), po["id"]))
        flash(request, "Order cancelled.")
    elif act == "close":
        db.ex("UPDATE purchase_orders SET status = 'closed', updated_at = ? WHERE id = ?", (db.now(), po["id"]))
        flash(request, "Order closed.")
    return back(f"/purchasing/{po['id']}")


@guarded("app")
async def po_receive(request: Request, c: Ctx):
    po = load(int(request.path_params["id"]), c.business["id"])
    if not po or po["status"] in ("draft", "awaiting_approval", "cancelled", "closed"):
        return Response(status_code=404)
    form = await form_checked(request)
    got = []
    for i, l in enumerate(po["lines"]):
        q = _f(form.get(f"r{i}"))
        if q:
            got.append({"po_line": int(l.get("line", i + 1)), "code": l.get("code"), "description": l.get("description"), "qty": q})
    if not got:
        flash(request, "Enter the quantities received.", "error")
        return back(f"/purchasing/{po['id']}")
    db.ex("""INSERT INTO goods_receipts (tenant_id, business_id, po_id, grn_number, delivery_note, received_date, lines,
             source, notes, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'manual', ?, ?, ?)""",
          (c.tenant["id"], c.business["id"], po["id"], f"GRN-{po['po_number']}-{len(db.q('SELECT id FROM goods_receipts WHERE po_id = ?', (po['id'],))) + 1}",
           str(form.get("delivery_note", "")).strip()[:60] or None, form.get("received_date") or date.today().isoformat(),
           json.dumps(got), str(form.get("notes", ""))[:500] or None, c.who, db.now()))
    matching.refresh_po_status(po["id"])
    _rematch_waiting(c, po["id"])
    flash(request, "Goods received recorded. Waiting invoices for this order were checked again.")
    return back(f"/purchasing/{po['id']}")


@guarded("app")
async def po_delivery_note(request: Request, c: Ctx):
    """Read a delivery note (photo or PDF) and record what arrived against the PO."""
    po = load(int(request.path_params["id"]), c.business["id"])
    if not po or po["status"] in ("draft", "awaiting_approval", "cancelled", "closed"):
        return Response(status_code=404)
    form = await form_checked(request)
    upload = form.get("file")
    if not getattr(upload, "filename", ""):
        flash(request, "Choose a delivery note photo or PDF.", "error")
        return back(f"/purchasing/{po['id']}")
    folder = config.UPLOAD_DIR / f"b{c.business['id']}" / "delivery"
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / f"{uuid.uuid4().hex}{Path(upload.filename).suffix.lower()}"
    dest.write_bytes(await upload.read())
    try:
        data = extraction.extract(dest, {"hint": "This is a delivery note or goods received note. Record the quantities "
                                                 "delivered as line quantities, and the delivery note number as invoice_number.",
                                         "header": {"delivery_note": "Delivery note number"}, "line": {"code": "Product code"}})
    except Exception as exc:
        flash(request, f"Couldn't read the delivery note: {exc}", "error")
        return back(f"/purchasing/{po['id']}")
    lines = data.get("line_items") or []
    pairs = matching._pair(lines, po["lines"])
    got, unmatched = [], []
    for li, idx in zip(lines, pairs):
        if idx is None:
            unmatched.append(li.get("description", "")[:40])
            continue
        pl = po["lines"][idx]
        got.append({"po_line": int(pl.get("line", idx + 1)), "code": pl.get("code"), "description": pl.get("description"),
                    "qty": li.get("quantity") or 0})
    if not got:
        flash(request, "Nothing on the delivery note matched this order. Record the quantities by hand.", "warn")
        return back(f"/purchasing/{po['id']}")
    db.ex("""INSERT INTO goods_receipts (tenant_id, business_id, po_id, grn_number, delivery_note, received_date, lines,
             source, stored_path, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'delivery_note', ?, ?, ?)""",
          (c.tenant["id"], c.business["id"], po["id"], f"GRN-{po['po_number']}-DN",
           (data.get("extras") or {}).get("delivery_note") or data.get("invoice_number"),
           data.get("invoice_date") or date.today().isoformat(), json.dumps(got), str(dest), c.who, db.now()))
    matching.refresh_po_status(po["id"])
    _rematch_waiting(c, po["id"])
    msg = f"Delivery note read: {len(got)} line(s) recorded as received."
    if unmatched:
        msg += f" Not on the order: {', '.join(unmatched)}."
    flash(request, msg, "warn" if unmatched else "ok")
    return back(f"/purchasing/{po['id']}")


@guarded("app")
async def grn_delete(request: Request, c: Ctx):
    await form_checked(request)
    g = db.q1("SELECT * FROM goods_receipts WHERE id = ? AND business_id = ?", (int(request.path_params["id"]), c.business["id"]))
    if not g:
        return Response(status_code=404)
    db.ex("DELETE FROM goods_receipts WHERE id = ?", (g["id"],))
    po = db.q1("SELECT status FROM purchase_orders WHERE id = ?", (g["po_id"],))
    if po and po["status"] in ("received", "part_received"):
        db.ex("UPDATE purchase_orders SET status = 'sent' WHERE id = ?", (g["po_id"],))
        matching.refresh_po_status(g["po_id"])
    flash(request, "Goods received entry removed.")
    return back(f"/purchasing/{g['po_id']}")


def _rematch_waiting(c: Ctx, po_id: int) -> None:
    from . import pipeline
    po = db.q1("SELECT po_number FROM purchase_orders WHERE id = ?", (po_id,))
    for inv in db.list_invoices(c.business["id"]):
        if inv["status"] in ("needs_review", "ready") and \
                (inv.get("po_id") == po_id or matching._norm(inv.get("po_number")) == matching._norm(po["po_number"])):
            data = {k: inv.get(k) for k in pipeline.FIELDS}
            data["source"] = inv.get("source")
            result = pipeline.assess(data, c.business["id"], inv["id"], inv["file_hash"], **pipeline._features(c.tenant))
            db.update_invoice(inv["id"], result)


@guarded("app")
async def po_file(request: Request, c: Ctx):
    po = load(int(request.path_params["id"]), c.business["id"])
    if not po:
        return Response(status_code=404)
    if request.path_params["kind"] == "xml":
        supplier = db.get_supplier(c.business["id"], po["supplier_name"]) or {}
        xml = einvoice.order_xml(po, {"name": c.business["name"]}, c.business.get("peppol_id"), supplier.get("peppol_id"))
        return Response(xml, media_type="application/xml",
                        headers={"Content-Disposition": f'attachment; filename="{po["po_number"]}.xml"'})
    pdf = po_pdf.build(po, c.business["name"], f"{config.BASE_URL.rstrip('/')}/po/{po['ack_token']}")
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{po["po_number"]}.pdf"'})


# ---- import from CSV and Xero ------------------------------------------------------------------

def _upsert_po(c: Ctx, number: str, supplier: str, lines: list[dict], source: str, extra: dict | None = None) -> bool:
    net, vat, gross = totals(lines)
    existing = db.q1("SELECT id, status FROM purchase_orders WHERE business_id = ? AND po_number = ?", (c.business["id"], number))
    if existing:
        if existing["status"] in ("draft", "approved", "sent", "acknowledged"):
            db.ex("UPDATE purchase_orders SET supplier_name = ?, lines = ?, net_total = ?, vat_total = ?, gross_total = ?, "
                  "updated_at = ? WHERE id = ?", (supplier, json.dumps(lines), net, vat, gross, db.now(), existing["id"]))
        return False
    vals = {"tenant_id": c.tenant["id"], "business_id": c.business["id"], "po_number": number[:40], "supplier_name": supplier[:200],
            "status": "approved", "order_date": date.today().isoformat(), "lines": json.dumps(lines), "net_total": net,
            "vat_total": vat, "gross_total": gross, "source": source, "ack_token": secrets.token_urlsafe(24),
            "created_by": c.who, "created_at": db.now(), "approved_by": f"{source} import", "currency": config.DEFAULT_CURRENCY}
    vals.update(extra or {})
    db.ex(f"INSERT INTO purchase_orders ({', '.join(vals)}) VALUES ({', '.join('?' for _ in vals)})", list(vals.values()))
    return True


@guarded("app")
async def po_import(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    form = await form_checked(request)
    upload = form.get("file")
    if not getattr(upload, "filename", ""):
        flash(request, "Choose a CSV file.", "error")
        return back("/purchasing")
    text = (await upload.read()).decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    norm = lambda h: re.sub(r"[^a-z]", "", (h or "").lower())
    orders: dict[str, dict] = {}
    for row in reader:
        r = {norm(k): (v or "").strip() for k, v in row.items()}
        number = r.get("ponumber") or r.get("po") or r.get("ordernumber") or r.get("purchaseorder")
        supplier = r.get("supplier") or r.get("suppliername") or r.get("vendor")
        desc = r.get("description") or r.get("item") or r.get("product")
        if not number or not supplier or not desc:
            continue
        o = orders.setdefault(number, {"supplier": supplier, "lines": []})
        o["lines"].append({"line": len(o["lines"]) + 1, "code": r.get("code") or r.get("sku") or r.get("partnumber") or None,
                           "description": desc, "qty": _f(r.get("qty") or r.get("quantity")) or 0,
                           "unit": r.get("unit") or None, "unit_price": _f(r.get("unitprice") or r.get("price")) or 0,
                           "vat_rate": _f(r.get("vatrate") or r.get("vat")) if _f(r.get("vatrate") or r.get("vat")) is not None else 20.0,
                           "account_code": r.get("accountcode") or r.get("account") or None})
    if not orders:
        flash(request, "No orders found. The CSV needs columns: PO number, Supplier, Description, Qty, Unit price "
                       "(optional: Code, Unit, VAT rate, Account code).", "error")
        return back("/purchasing")
    added = sum(_upsert_po(c, n, o["supplier"], o["lines"], "csv") for n, o in orders.items())
    flash(request, f"Imported {len(orders)} order(s): {added} new, {len(orders) - added} updated.")
    return back("/purchasing")


@guarded("app")
async def po_xero_sync(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    await form_checked(request)
    try:
        data = xero._api(c.business["id"], "GET", "/PurchaseOrders?status=AUTHORISED")
    except Exception as exc:
        flash(request, f"Couldn't fetch purchase orders from Xero: {exc}", "error")
        return back("/purchasing")
    added = 0
    for p in data.get("PurchaseOrders", []):
        lines = [{"line": i + 1, "code": li.get("ItemCode"), "description": li.get("Description") or "Item",
                  "qty": li.get("Quantity") or 0, "unit_price": li.get("UnitAmount") or 0,
                  "vat_rate": 20.0 if (li.get("TaxAmount") or 0) else 0.0, "account_code": li.get("AccountCode")}
                 for i, li in enumerate(p.get("LineItems", []))]
        added += _upsert_po(c, p.get("PurchaseOrderNumber") or p["PurchaseOrderID"][:8], (p.get("Contact") or {}).get("Name", ""),
                            lines, "xero", {"external_id": p.get("PurchaseOrderID"), "reference": p.get("Reference")})
    flash(request, f"Fetched {len(data.get('PurchaseOrders', []))} approved order(s) from Xero, {added} new.")
    return back("/purchasing")


# ---- supplier acknowledgement (public link) ------------------------------------------------------

async def ack_page(request: Request):
    po = db.q1("SELECT * FROM purchase_orders WHERE ack_token = ?", (request.path_params["token"],))
    if not po or len(request.path_params["token"]) < 20:
        return Response("This order link isn't valid.", status_code=404)
    po["lines"] = json.loads(po["lines"] or "[]")
    business = db.get_business(po["business_id"])
    if request.method == "POST":
        form = await form_checked(request)
        if po["status"] in ("sent", "approved", "acknowledged", "rejected"):
            accept = form.get("action") == "accept"
            note = str(form.get("note", "")).strip()[:1000]
            db.ex("UPDATE purchase_orders SET status = ?, ack_note = ?, updated_at = ? WHERE id = ?",
                  ("acknowledged" if accept else "rejected", note or None, db.now(), po["id"]))
            box = db.q1("SELECT * FROM mailboxes WHERE tenant_id = ? ORDER BY shared DESC, id LIMIT 1", (po["tenant_id"],))
            notify = box["from_email"] if box else None
            if notify:
                _deliver(business, "e-ordering", notify,
                         f"{po['supplier_name']} {'confirmed' if accept else 'rejected'} {po['po_number']}",
                         f"{po['supplier_name']} has {'confirmed' if accept else 'rejected'} purchase order {po['po_number']}."
                         + (f"\n\nTheir note: {note}" if note else ""), related=f"po:{po['id']}")
        return back(f"/po/{request.path_params['token']}")
    return templates.TemplateResponse(request, "po_ack.html", {"request": request, "po": po, "business": business,
                                                               "csrf": csrf_token(request), "PO_STATUS": PO_STATUS})


# ---- suppliers -------------------------------------------------------------------------------------

@guarded("app")
async def suppliers_page(request: Request, c: Ctx):
    if request.method == "POST":
        form = await form_checked(request)
        name = str(form.get("name", "")).strip()[:200]
        if not name:
            flash(request, "Enter the supplier name.", "error")
            return back("/suppliers")
        pid = str(form.get("peppol_id", "")).strip()
        if pid and not peppol.valid_id(pid):
            flash(request, "A Peppol ID looks like 0088:5012345678900 or 9932:GB123456789.", "error")
            return back("/suppliers")
        terms = str(form.get("terms_days", "")).strip()
        db.save_supplier(c.business["id"], name, {
            "email": str(form.get("email", "")).strip() or None,
            "vat_number": re.sub(r"\s", "", str(form.get("vat_number", ""))).upper() or None,
            "account_code": str(form.get("account_code", "")).strip() or None,
            "peppol_id": pid or None,
            "terms_days": int(terms) if terms.isdigit() else None,
            "match_type": form.get("match_type") if form.get("match_type") in ("two_way", "three_way") else None,
        })
        flash(request, f"Saved {name}.")
        return back("/suppliers")
    from . import payments
    sups = db.list_suppliers(c.business["id"])
    for s in sups:
        b = payments.supplier_bank(c.business["id"], s["name"])
        s["bank_masked"] = bankfiles.masked(b["approved"]) if b["approved"] else ""
        s["bank_pending_masked"] = bankfiles.masked(b["pending"]) if b["pending"] else ""
        s["can_verify"] = c.is_manager() and (not b["pending_by_id"] or not c.user or b["pending_by_id"] != c.user["id"]
                                              or not payments.four_eyes_possible(c.tenant["id"]))
    return render(request, "suppliers.html", c, suppliers=sups, pay_on=c.can("payments"))


routes = [
    Route("/purchasing", po_list),
    Route("/purchasing/new", po_new, methods=["GET", "POST"]),
    Route("/purchasing/import", po_import, methods=["POST"]),
    Route("/purchasing/xero-sync", po_xero_sync, methods=["POST"]),
    Route("/purchasing/{id:int}", po_detail),
    Route("/purchasing/{id:int}/edit", po_edit, methods=["GET", "POST"]),
    Route("/purchasing/{id:int}/action", po_action, methods=["POST"]),
    Route("/purchasing/{id:int}/receive", po_receive, methods=["POST"]),
    Route("/purchasing/{id:int}/delivery-note", po_delivery_note, methods=["POST"]),
    Route("/purchasing/{id:int}/file/{kind}", po_file),
    Route("/purchasing/grn/{id:int}/delete", grn_delete, methods=["POST"]),
    Route("/po/{token}", ack_page, methods=["GET", "POST"]),
    Route("/suppliers", suppliers_page, methods=["GET", "POST"]),
]
