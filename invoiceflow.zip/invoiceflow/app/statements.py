"""Supplier statement reconciliation: read a statement (PDF/photo via AI, or CSV), match each line to the
invoices and credit notes held for that supplier, and show what's missing, different or duplicated."""
import csv
import difflib
import io
import json
import re
import uuid
from datetime import date, datetime
from pathlib import Path

from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Route

from . import config, db, extraction, mailboxes
from .web import Ctx, back, flash, form_checked, guarded, render

STATEMENT_TOOL = {
    "name": "record_statement",
    "description": "Record the lines of a supplier statement of account.",
    "input_schema": {
        "type": "object",
        "properties": {
            "supplier_name": {"type": "string", "description": "Company that issued the statement"},
            "statement_date": {"type": ["string", "null"], "description": "YYYY-MM-DD"},
            "closing_balance": {"type": ["number", "null"], "description": "Total balance owed at the statement date"},
            "currency": {"type": "string"},
            "lines": {"type": "array", "items": {"type": "object", "properties": {
                "date": {"type": ["string", "null"], "description": "YYYY-MM-DD"},
                "reference": {"type": ["string", "null"], "description": "Invoice, credit note or payment number"},
                "type": {"type": "string", "enum": ["invoice", "credit", "payment", "other"]},
                "amount": {"type": "number", "description": "Positive for invoices; positive for credits and payments too (type marks them)"},
            }, "required": ["type", "amount"]}},
        },
        "required": ["supplier_name", "lines", "currency"],
    },
}
PROMPT = ("Read this supplier statement of account for a UK business. List every transaction line. UK dates are "
          "day/month/year; return YYYY-MM-DD. Amounts are plain positive numbers; mark each line's type. "
          "Call the record_statement tool.")


def _norm(s) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower()).lstrip("0")


def _f(v):
    try:
        return round(float(str(v).replace(",", "").replace("£", "").replace("(", "-").replace(")", "").strip()), 2)
    except (TypeError, ValueError):
        return None


def _date(v: str | None) -> str | None:
    if not v:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y", "%d %b %Y", "%d %B %Y"):
        try:
            return datetime.strptime(v.strip(), fmt).date().isoformat()
        except ValueError:
            continue
    return None


def parse_csv(text: str) -> dict:
    reader = csv.DictReader(io.StringIO(text))
    norm = lambda h: re.sub(r"[^a-z]", "", (h or "").lower())
    lines = []
    for row in reader:
        r = {norm(k): (v or "").strip() for k, v in row.items()}
        ref = r.get("reference") or r.get("ref") or r.get("invoice") or r.get("invoicenumber") or r.get("document") or ""
        kind = (r.get("type") or r.get("transactiontype") or "").lower()
        debit, credit = _f(r.get("debit")), _f(r.get("credit"))
        amount = _f(r.get("amount") or r.get("value"))
        if debit or credit:
            amount = (debit or 0) - (credit or 0)
        if amount is None:
            continue
        if "pay" in kind or "receipt" in kind:
            t = "payment"
        elif "credit" in kind or "cn" == kind or (amount < 0 and "inv" not in kind):
            t = "credit"
        elif kind and "inv" not in kind:
            t = "other"
        else:
            t = "invoice"
        lines.append({"date": _date(r.get("date")), "reference": ref, "type": t, "amount": abs(amount)})
    return {"supplier_name": "", "statement_date": None, "closing_balance": None, "currency": "GBP", "lines": lines}


def read_statement(path: Path) -> dict:
    if path.suffix.lower() == ".csv":
        return parse_csv(path.read_text(encoding="utf-8-sig", errors="replace"))
    if not config.ANTHROPIC_API_KEY:
        raise extraction.ExtractionError("Reading statement PDFs and photos needs AI reading switched on. Upload a CSV instead.")
    media = extraction.SUPPORTED.get(path.suffix.lower())
    if not media:
        raise extraction.ExtractionError("Upload a PDF, a photo or a CSV.")
    return extraction._extract_with_claude(path, media, tool=STATEMENT_TOOL, prompt=PROMPT)


def reconcile(business_id: int, supplier: str, lines: list[dict], statement_date: str | None) -> dict:
    """Match statement lines to invoices/credits for this supplier."""
    ours = [i for i in db.list_invoices(business_id) if i["status"] != "rejected" and i.get("supplier_name") and
            difflib.SequenceMatcher(None, i["supplier_name"].lower(), (supplier or "").lower()).ratio() >= 0.75]
    by_ref: dict[str, list[dict]] = {}
    for i in ours:
        by_ref.setdefault(_norm(i.get("invoice_number")), []).append(i)
    seen_refs: dict[str, int] = {}
    used: set[int] = set()
    rows = []
    for n, l in enumerate(lines):
        t, amount, ref = l.get("type", "invoice"), abs(_f(l.get("amount")) or 0), _norm(l.get("reference"))
        row = {"n": n, "date": l.get("date"), "reference": l.get("reference"), "type": t, "amount": amount,
               "status": "", "invoice_id": None, "note": ""}
        if t in ("payment", "other"):
            row["status"] = "payment" if t == "payment" else "info"
            rows.append(row)
            continue
        if ref:
            seen_refs[ref] = seen_refs.get(ref, 0) + 1
        cands = [i for i in by_ref.get(ref, []) if i["id"] not in used] if ref else []
        if not cands:
            # fall back to the same amount and type when references differ slightly
            cands = [i for i in ours if i["id"] not in used and abs((i.get("gross_total") or 0) - amount) < 0.01
                     and (i.get("document_type") == "credit_note") == (t == "credit")
                     and ref and _norm(i.get("invoice_number")).endswith(ref[-4:])]
        if ref and seen_refs[ref] > 1:
            row["status"], row["note"] = "duplicate", "Appears more than once on the statement"
        elif not cands:
            row["status"] = "missing_credit" if t == "credit" else "missing"
            row["note"] = "Credit note not received - ask the supplier for it" if t == "credit" else \
                "Not received - ask the supplier for a copy"
        else:
            inv = cands[0]
            used.add(inv["id"])
            row["invoice_id"] = inv["id"]
            diff = round(amount - (inv.get("gross_total") or 0), 2)
            if abs(diff) >= 0.01:
                row["status"], row["note"] = "different", f"Statement {amount:.2f}, invoice {inv.get('gross_total') or 0:.2f} ({diff:+.2f})"
            else:
                row["status"] = "matched"
        rows.append(row)
    cutoff = statement_date or date.today().isoformat()
    not_on = [{"invoice_id": i["id"], "reference": i.get("invoice_number"), "date": i.get("invoice_date"),
               "amount": i.get("gross_total"), "type": i.get("document_type")}
              for i in ours if i["id"] not in used and (i.get("invoice_date") or "") <= cutoff]
    dup_ours = [k for k, v in by_ref.items() if k and len(v) > 1]
    count = lambda s: sum(1 for r in rows if r["status"] == s)
    inv_total = sum(r["amount"] for r in rows if r["type"] == "invoice")
    less = sum(r["amount"] for r in rows if r["type"] in ("credit", "payment"))
    return {"rows": rows, "not_on_statement": not_on, "duplicates_in_books": dup_ours,
            "summary": {"matched": count("matched"), "missing": count("missing"), "missing_credit": count("missing_credit"),
                        "different": count("different"), "duplicate": count("duplicate"),
                        "not_on_statement": len(not_on), "statement_net": round(inv_total - less, 2)}}


def _gate(request: Request, c: Ctx):
    if not c.can("statements"):
        return render(request, "upgrade.html", c, feature="Supplier statement reconciliation",
                      blurb="Upload a supplier's statement and see at once which invoices you're missing, which credits "
                            "haven't arrived, and which amounts don't agree.")
    return None


@guarded("app")
async def list_page(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    rows = db.q("SELECT * FROM statements WHERE business_id = ? ORDER BY id DESC LIMIT 200", (c.business["id"],))
    for r in rows:
        r["result"] = json.loads(r["result"] or "{}")
    suppliers = sorted({i["supplier_name"] for i in db.list_invoices(c.business["id"]) if i.get("supplier_name")})
    return render(request, "statements.html", c, rows=rows, suppliers=suppliers)


@guarded("app")
async def upload(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    form = await form_checked(request)
    f = form.get("file")
    if not getattr(f, "filename", ""):
        flash(request, "Choose the statement file.", "error")
        return back("/statements")
    folder = config.UPLOAD_DIR / f"b{c.business['id']}" / "statements"
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / f"{uuid.uuid4().hex}{Path(f.filename).suffix.lower()}"
    dest.write_bytes(await f.read())
    try:
        data = read_statement(dest)
    except Exception as exc:
        flash(request, f"Couldn't read the statement: {exc}", "error")
        return back("/statements")
    supplier = str(form.get("supplier", "")).strip() or data.get("supplier_name") or ""
    if not supplier:
        flash(request, "Choose which supplier this statement is from.", "error")
        return back("/statements")
    lines = [{"date": _date(l.get("date")) or l.get("date"), "reference": str(l.get("reference") or "")[:60],
              "type": l.get("type") or "invoice", "amount": abs(_f(l.get("amount")) or 0)} for l in data.get("lines") or []]
    sdate = _date(str(form.get("statement_date", ""))) or _date(data.get("statement_date") or "")
    result = reconcile(c.business["id"], supplier, lines, sdate)
    sid = db.ex("""INSERT INTO statements (tenant_id, business_id, supplier_name, statement_date, closing_balance, currency,
                   lines, result, filename, stored_path, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (c.tenant["id"], c.business["id"], supplier[:200], sdate, _f(data.get("closing_balance")),
                 data.get("currency") or "GBP", json.dumps(lines), json.dumps(result), f.filename[:200], str(dest), c.who, db.now()))
    return back(f"/statements/{sid}")


def _load(c: Ctx, sid: int) -> dict | None:
    s = db.q1("SELECT * FROM statements WHERE id = ? AND business_id = ?", (sid, c.business["id"]))
    if s:
        s["lines"] = json.loads(s["lines"] or "[]")
        s["result"] = json.loads(s["result"] or "{}")
    return s


@guarded("app")
async def detail(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    s = _load(c, int(request.path_params["id"]))
    if not s:
        return Response(status_code=404)
    supplier = db.get_supplier(c.business["id"], s["supplier_name"]) or {}
    missing = [r for r in s["result"]["rows"] if r["status"] in ("missing", "missing_credit")]
    boxes = mailboxes.usable(c.tenant["id"], c.user, c.impersonating) if c.can("email") else []
    body = ""
    if missing:
        body = (f"Hello,\n\nWe've reconciled your statement{(' dated ' + s['statement_date']) if s['statement_date'] else ''} "
                f"and don't have copies of the following:\n\n"
                + "\n".join(f"- {'Credit note' if r['type'] == 'credit' else 'Invoice'} {r['reference'] or '(no reference)'}"
                            f"{(' dated ' + r['date']) if r['date'] else ''}: £{r['amount']:,.2f}" for r in missing)
                + f"\n\nPlease could you send them over.\n\nThank you,\n{c.business['name']}")
    return render(request, "statement_detail.html", c, s=s, missing=missing, boxes=boxes, body=body,
                  supplier_email=supplier.get("email") or "")


@guarded("app")
async def rerun(request: Request, c: Ctx):
    await form_checked(request)
    s = _load(c, int(request.path_params["id"]))
    if not s:
        return Response(status_code=404)
    result = reconcile(c.business["id"], s["supplier_name"], s["lines"], s["statement_date"])
    db.ex("UPDATE statements SET result = ? WHERE id = ?", (json.dumps(result), s["id"]))
    flash(request, "Checked again against your latest invoices.")
    return back(f"/statements/{s['id']}")


@guarded("app")
async def request_copies(request: Request, c: Ctx):
    form = await form_checked(request)
    s = _load(c, int(request.path_params["id"]))
    if not s:
        return Response(status_code=404)
    box = mailboxes.get(int(form.get("mailbox_id") or 0), c.tenant["id"])
    try:
        to = mailboxes.parse_addresses(str(form.get("to", "")))
    except mailboxes.MailError as exc:
        flash(request, str(exc), "error")
        return back(f"/statements/{s['id']}")
    if not box or not to:
        flash(request, "Choose a mailbox and enter the supplier's email.", "error")
        return back(f"/statements/{s['id']}")
    ok, msg = mailboxes.send_and_log(c.tenant["id"], c.business["id"], box, c.who, to,
                                     f"Missing invoices - {c.business['name']}", str(form.get("body", "")),
                                     related=f"statement:{s['id']}")
    if ok:
        db.save_supplier(c.business["id"], s["supplier_name"], {"email": to[0]})
    flash(request, f"Request sent to {to[0]}." if ok else f"Not sent: {msg}", "ok" if ok else "error")
    return back(f"/statements/{s['id']}")


routes = [
    Route("/statements", list_page),
    Route("/statements/upload", upload, methods=["POST"]),
    Route("/statements/{id:int}", detail),
    Route("/statements/{id:int}/rerun", rerun, methods=["POST"]),
    Route("/statements/{id:int}/request", request_copies, methods=["POST"]),
]
