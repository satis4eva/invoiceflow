"""Central configuration, read from environment variables (or a .env file)."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    """Minimal .env loader so the app needs no extra dependency."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(BASE_DIR / ".env")

# Branding - change to your own product name
APP_NAME = os.getenv("APP_NAME", "InvoiceFlow")

# Storage
DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data"))
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "invoiceflow.db"
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# AI extraction (Claude API). Without a key the app falls back to the
# built-in text parser, which only works on digital (non-scanned) PDFs.
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
EXTRACTION_MODEL = os.getenv("EXTRACTION_MODEL", "claude-sonnet-5-5")

# Master control login (you). Created on first start if no superadmin exists;
# after that, change the password from the app, not here.
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-me")

# Public address of the app, used in emails and Stripe redirects
BASE_URL = os.getenv("BASE_URL") or (f"https://{os.getenv('DOMAIN')}" if os.getenv("DOMAIN") else "http://localhost:8000")
SUPPORT_EMAIL = os.getenv("SUPPORT_EMAIL", "")

# Email (SMTP). Leave SMTP_HOST empty to disable sending.
SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
MAIL_FROM = os.getenv("MAIL_FROM", "")

# Optional "Sign in with Google / Microsoft" for connecting work mailboxes (see DEPLOY.md)
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")
MICROSOFT_CLIENT_ID = os.getenv("MICROSOFT_CLIENT_ID", "")
MICROSOFT_CLIENT_SECRET = os.getenv("MICROSOFT_CLIENT_SECRET", "")
DOCS_DIR_NAME = "documents"

# Stripe billing. Leave empty to run without card payments (trials + manual plans).
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")
STRIPE_PORTAL_CONFIG = os.getenv("STRIPE_PORTAL_CONFIG", "")
ALLOW_SIGNUP = os.getenv("ALLOW_SIGNUP", "1") == "1"
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
SECURE_COOKIES = os.getenv("SECURE_COOKIES", "0") == "1"  # set to 1 when served over HTTPS

# Accounting defaults
DEFAULT_CURRENCY = os.getenv("DEFAULT_CURRENCY", "GBP")
DEFAULT_EXPENSE_ACCOUNT = os.getenv("DEFAULT_EXPENSE_ACCOUNT", "429")  # Xero "General Expenses"
DEFAULT_PAYMENT_TERMS_DAYS = int(os.getenv("DEFAULT_PAYMENT_TERMS_DAYS", "30"))
# Totals may differ by this much (rounding) before we flag a mismatch
TOLERANCE = float(os.getenv("TOLERANCE", "0.02"))

# Xero OAuth2 (create an app at https://developer.xero.com/app/manage)
XERO_CLIENT_ID = os.getenv("XERO_CLIENT_ID", "")
XERO_CLIENT_SECRET = os.getenv("XERO_CLIENT_SECRET", "")
XERO_REDIRECT_URI = os.getenv("XERO_REDIRECT_URI", "http://localhost:8000/xero/callback")
# Granular scopes (required for Xero apps created on or after 2 March 2026)
XERO_SCOPES = os.getenv(
    "XERO_SCOPES",
    "openid profile email offline_access accounting.invoices accounting.payments accounting.contacts accounting.settings.read",
)
