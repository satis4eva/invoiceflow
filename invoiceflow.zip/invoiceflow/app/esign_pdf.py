"""PDF work for e-signing: checking uploads, page previews, stamping signatures, the certificate page."""
import base64
import hashlib
import io
import re
from datetime import datetime
from pathlib import Path

from pypdf import PdfReader, PdfWriter
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

MAX_BYTES = 20 * 1024 * 1024
MAX_PAGES = 100


class PdfProblem(Exception):
    pass


def sha256(path: Path | str) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare_upload(content: bytes, dest: Path) -> int:
    """Validate a PDF, bake page rotation into the content (so coordinates are simple), save it. Returns page count."""
    if len(content) > MAX_BYTES:
        raise PdfProblem("The PDF is larger than 20 MB.")
    if not content.startswith(b"%PDF"):
        raise PdfProblem("That file isn't a PDF.")
    try:
        reader = PdfReader(io.BytesIO(content))
        if reader.is_encrypted:
            raise PdfProblem("The PDF is password-protected. Save an unprotected copy and try again.")
        pages = len(reader.pages)
    except PdfProblem:
        raise
    except Exception:
        raise PdfProblem("The PDF couldn't be read. Try saving it again as a PDF.")
    if not pages or pages > MAX_PAGES:
        raise PdfProblem(f"PDFs need between 1 and {MAX_PAGES} pages.")
    writer = PdfWriter()
    for page in reader.pages:
        if page.get("/Rotate", 0):
            page.transfer_rotation_to_content()
        writer.add_page(page)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with open(dest, "wb") as fh:
        writer.write(fh)
    return pages


def page_png(pdf_path: Path, index: int, width: int = 1000) -> bytes:
    cache = pdf_path.with_suffix(f".p{index}.w{width}.png")
    if cache.exists():
        return cache.read_bytes()
    import pypdfium2 as pdfium
    pdf = pdfium.PdfDocument(str(pdf_path))
    try:
        if index < 0 or index >= len(pdf):
            raise PdfProblem("No such page")
        page = pdf[index]
        scale = width / page.get_width()
        img = page.render(scale=scale).to_pil()
        buf = io.BytesIO()
        img.convert("RGB").save(buf, "PNG", optimize=True)
    finally:
        pdf.close()
    data = buf.getvalue()
    cache.write_bytes(data)
    return data


def page_ratios(pdf_path: Path) -> list[float]:
    """height / width for each page, for laying out previews."""
    reader = PdfReader(str(pdf_path))
    out = []
    for p in reader.pages:
        box = p.cropbox
        out.append(float(box.height) / float(box.width))
    return out


def decode_signature(data_url: str) -> bytes:
    m = re.fullmatch(r"data:image/png;base64,([A-Za-z0-9+/=]+)", data_url or "")
    if not m:
        raise PdfProblem("Draw your signature first.")
    raw = base64.b64decode(m.group(1))
    if not raw.startswith(b"\x89PNG") or len(raw) > 600_000:
        raise PdfProblem("That signature image couldn't be used. Please draw it again.")
    return raw


def _when(iso: str | None) -> str:
    if not iso:
        return "-"
    return datetime.fromisoformat(iso).strftime("%d %b %Y %H:%M UTC")


def _draw_signature(c: canvas.Canvas, signer: dict, x: float, y: float, w: float, h: float, caption: bool = True) -> None:
    cap_h = 7 if caption and h > 22 else 0
    area_h = h - cap_h
    if signer["signature_type"] == "drawn":
        img = ImageReader(io.BytesIO(decode_signature(signer["signature_data"])))
        iw, ih = img.getSize()
        scale = min(w / iw, area_h / ih)
        dw, dh = iw * scale, ih * scale
        c.drawImage(img, x + (w - dw) / 2, y + cap_h + (area_h - dh) / 2, dw, dh, mask="auto")
    else:
        text = signer["signature_data"] or signer["signed_name"]
        size = min(area_h * 0.8, 40)
        while size > 6 and c.stringWidth(text, "Times-BoldItalic", size) > w * 0.95:
            size -= 1
        c.setFillColor(HexColor("#1d2636"))
        c.setFont("Times-BoldItalic", size)
        c.drawCentredString(x + w / 2, y + cap_h + (area_h - size * 0.7) / 2, text)
    if cap_h:
        c.setFont("Helvetica", 5.5)
        c.setFillColor(HexColor("#24427c"))
        c.drawString(x + 1, y + 1, f"Signed electronically by {signer['signed_name']}, {_when(signer['signed_at'])}"[:120])


def build_final(original: Path, dest: Path, request: dict, signers: list[dict], events: list[dict],
                sender_name: str) -> None:
    reader = PdfReader(str(original))
    writer = PdfWriter()
    for index, page in enumerate(reader.pages):
        box = page.cropbox
        pw, ph = float(box.width), float(box.height)
        left, bottom = float(box.left), float(box.bottom)
        marks = [(s, f) for s in signers if s["status"] == "signed" for f in (s["fields"] or []) if f["page"] == index]
        if marks:
            buf = io.BytesIO()
            c = canvas.Canvas(buf, pagesize=(float(page.mediabox.width), float(page.mediabox.height)))
            for signer, f in marks:
                x = left + f["x"] * pw
                w, h = f["w"] * pw, f["h"] * ph
                y = bottom + ph - (f["y"] * ph) - h
                _draw_signature(c, signer, x, y, w, h)
            c.save()
            buf.seek(0)
            page.merge_page(PdfReader(buf).pages[0])
        writer.add_page(page)

    cert = io.BytesIO()
    _certificate(cert, request, signers, events, sender_name)
    cert.seek(0)
    for p in PdfReader(cert).pages:
        writer.add_page(p)
    writer.add_metadata({"/Title": request["title"], "/Subject": "Signed document",
                         "/Producer": "InvoiceFlow e-signing"})
    dest.parent.mkdir(parents=True, exist_ok=True)
    with open(dest, "wb") as fh:
        writer.write(fh)


def _certificate(out, request: dict, signers: list[dict], events: list[dict], sender_name: str) -> None:
    W, H = A4
    m = 48
    c = canvas.Canvas(out, pagesize=A4)
    ink, muted, blue, rule = HexColor("#1d2636"), HexColor("#5c6a80"), HexColor("#24427c"), HexColor("#d6dee9")
    y = H - m

    def line(text, size=9.5, font="Helvetica", color=ink, gap=14):
        nonlocal y
        if y < m + 20:
            c.showPage()
            y = H - m
        c.setFont(font, size)
        c.setFillColor(color)
        c.drawString(m, y, text[:140])
        y -= gap

    c.setFillColor(blue)
    c.rect(0, H - 8, W, 8, stroke=0, fill=1)
    line("Signature certificate", 18, "Helvetica-Bold", gap=24)
    line(f"Document: {request['title']}", 11, "Helvetica-Bold", gap=16)
    line(f"Sent by: {sender_name}")
    line(f"Reference: SR-{request['id']:06d}")
    line(f"Original file: {request.get('filename') or '-'} ({request.get('page_count') or '?'} pages)")
    line(f"Original document fingerprint (SHA-256): {request['original_hash']}", 8, "Courier", muted)
    line(f"Sent: {_when(request.get('sent_at'))}    Completed: {_when(request.get('completed_at'))}", gap=22)

    c.setStrokeColor(rule)
    for s in signers:
        need = 92
        if y - need < m:
            c.showPage()
            y = H - m
        c.line(m, y + 6, W - m, y + 6)
        y -= 8
        line(f"{s['signed_name'] or s['name']}", 11, "Helvetica-Bold", gap=14)
        line(f"Email: {s['email'] or '-'}    Signed: {_when(s['signed_at'])}", 9)
        line(f"Method: {'drawn signature' if s['signature_type'] == 'drawn' else 'typed signature'}    "
             f"IP address: {s['ip'] or '-'}", 9)
        line(f"Device: {(s['user_agent'] or '-')[:110]}", 7.5, color=muted, gap=12)
        box_y = y - 44
        c.setStrokeColor(rule)
        c.rect(m, box_y, 220, 48, stroke=1, fill=0)
        _draw_signature(c, s, m + 6, box_y + 4, 208, 40, caption=False)
        y = box_y - 18

    line("Audit trail", 12, "Helvetica-Bold", gap=16)
    for e in events:
        who = f" ({e['signer_name']})" if e.get("signer_name") else ""
        ip = f"  IP {e['ip']}" if e.get("ip") else ""
        line(f"{_when(e['at'])}  {e['event'].replace('_', ' ')}{who}{(': ' + e['detail']) if e.get('detail') else ''}{ip}",
             8, gap=11)
    y -= 10
    line("Each signer opened a unique link sent to them and agreed to sign electronically before signing.", 8, color=muted, gap=11)
    line("Electronic signatures are recognised in the UK under the Electronic Communications Act 2000 and UK eIDAS.", 8,
         color=muted, gap=11)
    c.save()
