"""Configurable business rules, set per business: 'when these conditions are true, do this'."""
from datetime import date

from . import db, industry
from .validation import issue

FIELDS = {
    "supplier_name": "Supplier",
    "gross_total": "Total (gross)",
    "net_total": "Net total",
    "vat_total": "VAT total",
    "currency": "Currency",
    "po_number": "PO number",
    "invoice_number": "Invoice number",
    "document_type": "Document type",
    "age_days": "Days since invoice date",
    "line_description": "Any line description",
    "line_vat_rate": "Any line VAT rate",
    "match_status": "Matching result",
    "source": "Received via",
}
OPS = {"equals": "is", "not_equals": "is not", "contains": "contains", "gt": "is more than", "lt": "is less than",
       "is_empty": "is empty", "is_not_empty": "is not empty"}
ACTIONS = {
    "error": "Block approval with a message",
    "warning": "Show a warning",
    "needs_manager": "Require an owner or admin to approve",
    "set_account": "Code lines to account",
    "auto_approve": "Approve automatically if nothing else is wrong",
}


def settings_for(business_id: int) -> dict:
    """Business settings merged over the industry profile's defaults."""
    stored = db.business_settings(business_id)
    profile = industry.get(stored.get("industry"))
    merged = {**profile["settings"], **{k: v for k, v in stored.items() if k not in ("rules",)}}
    merged["industry"] = stored.get("industry") or "general"
    merged["rules"] = stored.get("rules") if "rules" in stored else list(profile["rules"])
    return merged


def _values(inv: dict, field: str) -> list:
    if field.startswith("extras."):
        return [(inv.get("extras") or {}).get(field[7:])]
    if field == "age_days":
        try:
            return [(date.today() - date.fromisoformat(inv["invoice_date"])).days]
        except (TypeError, ValueError, KeyError):
            return [None]
    if field == "line_description":
        return [l.get("description") for l in inv.get("line_items") or []] or [None]
    if field == "line_vat_rate":
        return [l.get("vat_rate") for l in inv.get("line_items") or []] or [None]
    return [inv.get(field)]


def _num(v):
    try:
        return float(str(v).replace(",", "").replace("£", ""))
    except (TypeError, ValueError):
        return None


def _test(value, op: str, target: str) -> bool:
    empty = value is None or str(value).strip() == ""
    if op == "is_empty":
        return empty
    if op == "is_not_empty":
        return not empty
    if empty:
        return op == "not_equals"
    if op in ("gt", "lt"):
        a, b = _num(value), _num(target)
        if a is None or b is None:
            return False
        return a > b if op == "gt" else a < b
    a, b = str(value).strip().lower(), str(target).strip().lower()
    if op == "equals":
        return a == b or (_num(a) is not None and _num(a) == _num(b))
    if op == "not_equals":
        return not (a == b or (_num(a) is not None and _num(a) == _num(b)))
    if op == "contains":
        return b in a
    return False


def matches(rule: dict, inv: dict) -> bool:
    conds = rule.get("when") or []
    if not conds:
        return False
    return all(any(_test(v, c.get("op", "equals"), c.get("value", "")) for v in _values(inv, c.get("field", "")))
               for c in conds)


def apply(inv: dict, settings: dict) -> tuple[list[dict], bool]:
    """Run the business's rules. Returns (issues to add, auto_approve wanted). May set account codes on inv."""
    out, auto = [], False
    for rule in settings.get("rules") or []:
        if not rule.get("enabled", True) or not matches(rule, inv):
            continue
        action, msg = rule.get("action"), rule.get("message") or rule.get("name") or "Business rule"
        if action == "error":
            out.append(issue("error", "rule", msg))
        elif action == "warning":
            out.append(issue("warning", "rule", msg))
        elif action == "needs_manager":
            out.append(issue("info", "needs_manager", msg))
        elif action == "set_account":
            code = str(rule.get("value") or "").strip()
            if code:
                for l in inv.get("line_items") or []:
                    if not l.get("account_code"):
                        l["account_code"] = code
        elif action == "auto_approve":
            auto = True
    return out, auto
