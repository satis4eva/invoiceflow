"""Web application: upload, review, approve, post and export supplier invoices."""
import secrets
from datetime import date
from pathlib import Path

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, RedirectResponse, Response
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles
from starlette.templating import Jinja2Templates

from . import config, db, exports, pipeline, validation, xero

BASE = Path(__file__).parent
templates = Jinja2Templates(directory=str(BASE / "templates"))

STATUS_LABELS = {
    "needs_review": "Needs review",
    "ready": "Ready to approve",
    "approved": "Approved",
    "posted": "Posted",
    "rejected": "Rejected",
}
templates.env.globals.update(APP_NAME=config.APP_NAME, STATUS_LABELS=STATUS_LABELS,
                             DEFAULT_ACCOUNT=config.DEFAULT_EXPENSE_ACCOUNT)


def money(v, cur="GBP"):
    if v is None:
        return "-"
    sym = {"GBP": "£", "EUR": "€", "USD": "$"}.get(cur or "GBP", "")
    return f"{'-' if v < 0 else ''}{sym}{abs(v):,.2f}" + ("" if sym else f" {cur}")


def uk_date(v):
    try:
        return date.fromisoformat(v).strftime("%d %b %Y") if v else "-"
    except ValueError:
        return v


templates.env.filters.update(money=money, uk_date=uk_date)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def user(request: Request) -> str | None:
    return request.session.get("user")


def flash(request: Request, message: str, level: str = "ok") -> None:
    request.session.setdefault("flash", []).append({"level": level, "message": message})


def render(request: Request, name: str, **ctx):
    if "csrf" not in request.session:
        request.session["csrf"] = secrets.token_urlsafe(24)
    ctx.update(request=request, user=user(request), csrf=request.session["csrf"],
               flashes=request.session.pop("flash", []), counts=db.status_counts())
    return templates.TemplateResponse(request, name, ctx)


async def form_checked(request: Request) -> dict:
    form = await request.form()
    if not secrets.compare_digest(str(form.get("csrf", "")), request.session.get("csrf", "")):
        raise PermissionError("Form expired - reload the page and try again")
    return form


def back(url: str) -> RedirectResponse:
    return RedirectResponse(url, status_code=303)


class LoginRequired(Exception):
    pass


def guard(handler):
    async def wrapped(request: Request):
        if not user(request):
            return back("/login?next=" + request.url.path)
        try:
            return await handler(request)
        except PermissionError as exc:
            flash(request, str(exc), "error")
            return back(request.headers.get("referer") or "/")
    return wrapped


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------

async def login(request: Request):
    if request.method == "POST":
        form = await request.form()
        ok_user = secrets.compare_digest(str(form.get("username", "")), config.ADMIN_USER)
        ok_pass = secrets.compare_digest(str(form.get("password", "")), config.ADMIN_PASSWORD)
        if ok_user and ok_pass:
            request.session["user"] = config.ADMIN_USER
            nxt = request.query_params.get("next", "/")
            return back(nxt if nxt.startswith("/") else "/")
        return render(request, "login.html", error="That username and password don't match.")
    return render(request, "login.html", error=None)


async def logout(request: Request):
    request.session.clear()
    return back("/login")


# ---------------------------------------------------------------------------
# invoices
# ---------------------------------------------------------------------------

@guard
async def register(request: Request):
    status = request.query_params.get("status") or None
    return render(request, "register.html", invoices=db.list_invoices(status), status=status,
                  ai_enabled=bool(config.ANTHROPIC_API_KEY), xero_connected=bool(xero.connection()))


@guard
async def upload(request: Request):
    form = await form_checked(request)
    files = form.getlist("files")
    done, failed = [], []
    for f in files:
        if not getattr(f, "filename", ""):
            continue
        try:
            done.append(pipeline.process_upload(f.filename, await f.read(), user(request)))
        except Exception as exc:
            failed.append(f"{f.filename}: {exc}")
    if done:
        flash(request, f"Read {len(done)} document{'s' if len(done) != 1 else ''}. Check anything marked for review.")
    for msg in failed:
        flash(request, msg, "error")
    if len(done) == 1 and not failed:
        return back(f"/invoices/{done[0]}")
    return back("/")


@guard
async def review(request: Request):
    inv_id = int(request.path_params["id"])
    inv = db.get_invoice(inv_id)
    if not inv:
        return Response("Invoice not found", status_code=404)
    ids = [i["id"] for i in db.list_invoices() if i["status"] in ("needs_review", "ready")]
    nxt = next((i for i in ids if i < inv_id), None)
    return render(request, "review.html", inv=inv, audit=db.get_audit(inv_id), next_id=nxt,
                  is_image=Path(inv["stored_path"]).suffix.lower() != ".pdf",
                  xero_connected=bool(xero.connection()))


@guard
async def save(request: Request):
    inv_id = int(request.path_params["id"])
    form = await form_checked(request)
    issues = pipeline.save_edits(inv_id, dict(form), user(request))
    action = form.get("action")
    if action == "approve":
        ok, msg = pipeline.approve(inv_id, user(request))
        flash(request, msg if not ok else "Approved.", "ok" if ok else "error")
        if ok and form.get("next_id"):
            return back(f"/invoices/{form['next_id']}")
    else:
        errs = validation.blocking(issues)
        flash(request, "Changes saved." if not errs else f"Saved. {len(errs)} problem(s) still need fixing.",
              "ok" if not errs else "warn")
    return back(f"/invoices/{inv_id}")


@guard
async def reject(request: Request):
    inv_id = int(request.path_params["id"])
    form = await form_checked(request)
    pipeline.reject(inv_id, str(form.get("reason", "")), user(request))
    flash(request, "Rejected. It won't be exported or posted.")
    return back("/")


@guard
async def reopen(request: Request):
    inv_id = int(request.path_params["id"])
    await form_checked(request)
    inv = db.get_invoice(inv_id)
    issues = validation.validate(inv, inv_id, inv["file_hash"])
    db.update_invoice(inv_id, {"status": validation.status_for(issues), "issues": issues})
    db.audit(inv_id, "reopen", "", user(request))
    flash(request, "Reopened for review.")
    return back(f"/invoices/{inv_id}")


@guard
async def reprocess(request: Request):
    inv_id = int(request.path_params["id"])
    await form_checked(request)
    try:
        pipeline.reprocess(inv_id, user(request))
        flash(request, "Read the document again. Your earlier edits were replaced.")
    except Exception as exc:
        flash(request, f"Couldn't read the document: {exc}", "error")
    return back(f"/invoices/{inv_id}")


@guard
async def original(request: Request):
    inv = db.get_invoice(int(request.path_params["id"]))
    if not inv:
        return Response(status_code=404)
    return FileResponse(inv["stored_path"], filename=inv["filename"], content_disposition_type="inline")


# ---------------------------------------------------------------------------
# posting & exports
# ---------------------------------------------------------------------------

def _post_one(inv: dict, who: str, xero_status: str) -> tuple[bool, str]:
    if inv["status"] != "approved":
        return False, f"#{inv['id']} isn't approved"
    try:
        xid = xero.post_bill(inv, xero_status)
    except Exception as exc:
        db.audit(inv["id"], "post_failed", str(exc), who)
        return False, f"#{inv['id']} {inv.get('invoice_number')}: {exc}"
    db.update_invoice(inv["id"], {"status": "posted", "external_id": xid, "posted_to": "xero",
                                  "posted_at": db.now()})
    db.audit(inv["id"], "posted", f"Xero {xero_status.lower()} bill {xid}", who)
    return True, xid


@guard
async def post_xero(request: Request):
    form = await form_checked(request)
    status = "AUTHORISED" if form.get("xero_status") == "AUTHORISED" else "DRAFT"
    if "id" in request.path_params:
        targets = [db.get_invoice(int(request.path_params["id"]))]
    else:
        targets = db.list_invoices("approved")
    ok = fail = 0
    for inv in targets:
        good, msg = _post_one(inv, user(request), status)
        ok += good
        if not good:
            fail += 1
            flash(request, msg, "error")
    if ok:
        word = "draft bills" if status == "DRAFT" else "bills awaiting payment"
        flash(request, f"Sent {ok} to Xero as {word}.")
    if not targets:
        flash(request, "Nothing approved to send.", "warn")
    return back(request.headers.get("referer") or "/")


@guard
async def export(request: Request):
    fmt = request.path_params["fmt"]
    if fmt not in exports.EXPORTERS:
        return Response("Unknown format", status_code=404)
    status = request.query_params.get("status", "approved")
    invoices = db.list_invoices(status if status != "all" else None)
    _, fn = exports.EXPORTERS[fmt]
    body = fn(invoices)
    if request.query_params.get("mark") == "1" and fmt != "summary":
        for inv in invoices:
            if inv["status"] == "approved":
                db.update_invoice(inv["id"], {"status": "posted", "posted_to": f"{fmt} csv", "posted_at": db.now()})
                db.audit(inv["id"], "exported", f"{fmt} CSV", user(request))
    name = f"{fmt}-bills-{date.today().isoformat()}.csv"
    return Response(body, media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ---------------------------------------------------------------------------
# settings / Xero connection
# ---------------------------------------------------------------------------

@guard
async def settings(request: Request):
    accounts, acct_error = [], None
    if xero.connection():
        try:
            accounts = [a for a in xero.list_accounts() if a["type"] in ("EXPENSE", "DIRECTCOSTS", "OVERHEADS", "FIXED")]
        except Exception as exc:
            acct_error = str(exc)
    return render(request, "settings.html", xero_configured=xero.configured(), conn=xero.connection(),
                  accounts=accounts, acct_error=acct_error, ai_enabled=bool(config.ANTHROPIC_API_KEY),
                  model=config.EXTRACTION_MODEL, redirect_uri=config.XERO_REDIRECT_URI)


@guard
async def xero_connect(request: Request):
    if not xero.configured():
        flash(request, "Add XERO_CLIENT_ID and XERO_CLIENT_SECRET to .env first.", "error")
        return back("/settings")
    return RedirectResponse(xero.authorize_url())


@guard
async def xero_callback(request: Request):
    q = request.query_params
    if q.get("error"):
        flash(request, f"Xero didn't connect: {q.get('error_description') or q['error']}", "error")
        return back("/settings")
    try:
        conn = xero.handle_callback(q.get("code", ""), q.get("state", ""))
        flash(request, f"Connected to {conn['tenant_name']}.")
    except Exception as exc:
        flash(request, str(exc), "error")
    return back("/settings")


@guard
async def xero_disconnect(request: Request):
    await form_checked(request)
    xero.disconnect()
    flash(request, "Disconnected from Xero.")
    return back("/settings")


# ---------------------------------------------------------------------------
# JSON API (read-only) and health
# ---------------------------------------------------------------------------

@guard
async def api_invoices(request: Request):
    invs = db.list_invoices(request.query_params.get("status"))
    for i in invs:
        i.pop("raw", None)
        i.pop("stored_path", None)
    return JSONResponse(invs)


async def health(request: Request):
    return JSONResponse({"ok": True})


routes = [
    Route("/", register),
    Route("/login", login, methods=["GET", "POST"]),
    Route("/logout", logout),
    Route("/upload", upload, methods=["POST"]),
    Route("/invoices/{id:int}", review),
    Route("/invoices/{id:int}/save", save, methods=["POST"]),
    Route("/invoices/{id:int}/reject", reject, methods=["POST"]),
    Route("/invoices/{id:int}/reopen", reopen, methods=["POST"]),
    Route("/invoices/{id:int}/reprocess", reprocess, methods=["POST"]),
    Route("/invoices/{id:int}/file", original),
    Route("/invoices/{id:int}/post-xero", post_xero, methods=["POST"]),
    Route("/post-xero", post_xero, methods=["POST"]),
    Route("/export/{fmt}", export),
    Route("/settings", settings),
    Route("/xero/connect", xero_connect),
    Route("/xero/callback", xero_callback),
    Route("/xero/disconnect", xero_disconnect, methods=["POST"]),
    Route("/api/invoices", api_invoices),
    Route("/health", health),
    Mount("/static", StaticFiles(directory=str(BASE / "static")), name="static"),
]

db.init_db()
app = Starlette(routes=routes, middleware=[
    Middleware(SessionMiddleware, secret_key=config.SECRET_KEY, same_site="lax", max_age=60 * 60 * 12,
               https_only=config.SECURE_COOKIES),
])
