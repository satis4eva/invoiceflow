"""Web application: public pricing and sign-up, the customer app, account settings and billing.
Master control routes live in admin.py."""
import json
import logging
from datetime import date
from pathlib import Path

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, RedirectResponse, Response
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from . import accounts, admin, billing, capture, esign, mail_web, purchasing, settings_web, statements, industry, rules, config, db, exports, mailer, pipeline, plans, validation, xero
from .web import BASE, Ctx, back, flash, form_checked, guarded, render

log = logging.getLogger("invoiceflow")


# ---------------------------------------------------------------------------
# public: pricing, sign-up, login, password reset, invites
# ---------------------------------------------------------------------------

async def home(request: Request):
    c = Ctx(request)
    if c.user:
        return back("/app" if c.tenant else "/admin")
    return render(request, "pricing.html", c)


async def pricing(request: Request):
    return render(request, "pricing.html")


async def signup(request: Request):
    c = Ctx(request)
    if c.user and not c.is_super:
        return back("/app")
    plan = request.query_params.get("plan", "standard")
    if not config.ALLOW_SIGNUP:
        return render(request, "signup.html", c, plan=plan, values={}, error="Sign-up is closed at the moment.")
    if request.method == "GET":
        return render(request, "signup.html", c, plan=plan if plan in plans.PLANS else "standard", values={}, error=None)

    form = await form_checked(request)
    values = {k: str(form.get(k, "")).strip() for k in ("company", "name", "email", "plan")}
    password = str(form.get("password", ""))
    plan = values["plan"] if values["plan"] in plans.PLANS else "standard"
    error = None
    if not values["company"]:
        error = "Enter your company name."
    elif not accounts.EMAIL_RE.match(values["email"]):
        error = "Enter a valid email address."
    elif db.user_by_email(values["email"]):
        error = "There's already an account with that email. Sign in or reset your password."
    elif accounts.password_problem(password):
        error = accounts.password_problem(password)
    elif not form.get("terms"):
        error = "Please accept the terms to continue."
    if error:
        return render(request, "signup.html", c, plan=plan, values=values, error=error)

    verified = not mailer.enabled()
    tenant_id, user_id = accounts.create_account(values["company"], values["email"], plan, password,
                                                 values["name"], verified=verified)
    db.admin_log(tenant_id, "signup", f"{plans.get(plan)['name']} trial by {values['email']}", values["email"])
    if not verified:
        mailer.verify_email(values["email"], accounts.new_token(user_id, "verify", 48))
    request.session.clear()
    request.session["uid"] = user_id
    flash(request, f"Welcome! Your {plans.TRIAL_DAYS}-day free trial of {plans.get(plan)['name']} has started."
          + ("" if verified else " Check your inbox to confirm your email."))
    return back("/app")


async def login(request: Request):
    c = Ctx(request)
    if request.method == "GET":
        if c.user:
            return back("/")
        return render(request, "login.html", c, error=None, email="")
    form = await form_checked(request)
    email = str(form.get("email", "")).strip().lower()
    key = f"{email}|{request.client.host if request.client else ''}"
    if accounts.throttled(key):
        return render(request, "login.html", c, email=email,
                      error="Too many attempts. Wait 15 minutes or reset your password.")
    user = db.user_by_email(email)
    if not user or not user["active"] or not accounts.check_password(str(form.get("password", "")), user["password_hash"]):
        accounts.record_failure(key)
        return render(request, "login.html", c, email=email, error="That email and password don't match.")
    accounts.clear_failures(key)
    request.session.clear()
    request.session["uid"] = user["id"]
    db.update_user(user["id"], {"last_login": db.now()})
    nxt = request.query_params.get("next", "")
    if nxt.startswith("/") and not nxt.startswith("//"):
        return back(nxt)
    return back("/admin" if user["role"] == "superadmin" else "/app")


async def logout(request: Request):
    request.session.clear()
    return back("/login")


async def verify(request: Request):
    user = db.user_by_token(request.path_params["token"], "verify")
    if not user:
        flash(request, "That confirmation link has expired or was already used.", "warn")
        return back("/login")
    db.update_user(user["id"], {"email_verified": 1})
    accounts.clear_token(user["id"])
    flash(request, "Email confirmed. Thanks!")
    return back("/app" if request.session.get("uid") == user["id"] else "/login")


async def forgot(request: Request):
    c = Ctx(request)
    if request.method == "GET":
        return render(request, "forgot.html", c, sent=False)
    form = await form_checked(request)
    user = db.user_by_email(str(form.get("email", "")))
    if user and user["active"] and user["password_hash"]:
        mailer.reset_password(user["email"], accounts.new_token(user["id"], "reset", 2))
    # Same answer either way, so the form can't be used to discover accounts
    return render(request, "forgot.html", c, sent=True, mail_enabled=mailer.enabled())


async def reset(request: Request):
    c = Ctx(request)
    token = request.path_params["token"]
    user = db.user_by_token(token, "reset")
    if not user:
        flash(request, "That reset link has expired. Ask for a new one.", "warn")
        return back("/forgot")
    if request.method == "GET":
        return render(request, "set_password.html", c, title="Choose a new password", error=None, email=user["email"])
    form = await form_checked(request)
    pw = str(form.get("password", ""))
    if accounts.password_problem(pw):
        return render(request, "set_password.html", c, title="Choose a new password",
                      error=accounts.password_problem(pw), email=user["email"])
    db.update_user(user["id"], {"password_hash": accounts.hash_password(pw), "email_verified": 1})
    accounts.clear_token(user["id"])
    flash(request, "Password changed. Sign in with your new password.")
    return back("/login")


async def accept_invite(request: Request):
    c = Ctx(request)
    user = db.user_by_token(request.path_params["token"], "invite")
    if not user:
        flash(request, "That invitation has expired. Ask for a new one.", "warn")
        return back("/login")
    tenant = db.get_tenant(user["tenant_id"])
    title = f"Join {tenant['name']}"
    if request.method == "GET":
        return render(request, "set_password.html", c, title=title, error=None, email=user["email"], ask_name=True)
    form = await form_checked(request)
    pw = str(form.get("password", ""))
    if accounts.password_problem(pw):
        return render(request, "set_password.html", c, title=title, error=accounts.password_problem(pw),
                      email=user["email"], ask_name=True)
    db.update_user(user["id"], {"password_hash": accounts.hash_password(pw), "email_verified": 1,
                                "name": str(form.get("name", "")).strip()})
    accounts.clear_token(user["id"])
    request.session.clear()
    request.session["uid"] = user["id"]
    flash(request, f"Welcome to {tenant['name']}.")
    return back("/app")


# ---------------------------------------------------------------------------
# the customer app: invoices
# ---------------------------------------------------------------------------

def _inv(c: Ctx, request: Request) -> dict | None:
    return db.get_invoice(int(request.path_params["id"]), c.business["id"])


@guarded("app")
async def register(request: Request, c: Ctx):
    status = request.query_params.get("status") or None
    allowance, _ = accounts.upload_allowance(c.tenant)
    return render(request, "register.html", c, invoices=db.list_invoices(c.business["id"], status), status=status,
                  ai_enabled=bool(config.ANTHROPIC_API_KEY), xero_connected=bool(xero.connection(c.business["id"])),
                  usage=accounts.usage(c.tenant), allowance=allowance)


@guarded("app")
async def upload(request: Request, c: Ctx):
    form = await form_checked(request)
    files = [f for f in form.getlist("files") if getattr(f, "filename", "")]
    allowance, why = accounts.upload_allowance(c.tenant)
    if allowance is not None and len(files) > allowance:
        if allowance == 0:
            flash(request, why, "error")
            return back("/app")
        flash(request, f"Only the first {allowance} files were read - that's what's left in your package.", "warn")
        files = files[:allowance]
    done, failed = [], []
    memory = c.can("supplier_memory")
    for f in files:
        try:
            done.append(pipeline.process_upload(c.business, f.filename, await f.read(), c.who, memory))
        except Exception as exc:
            failed.append(f"{f.filename}: {exc}")
    if done:
        flash(request, f"Read {len(done)} document{'s' if len(done) != 1 else ''}. Check anything marked for review.")
    for msg in failed:
        flash(request, msg, "error")
    if len(done) == 1 and not failed:
        return back(f"/invoices/{done[0]}")
    return back("/app")


@guarded("app")
async def review(request: Request, c: Ctx):
    inv = _inv(c, request)
    if not inv:
        return Response("Invoice not found", status_code=404)
    ids = [i["id"] for i in db.list_invoices(c.business["id"]) if i["status"] in ("needs_review", "ready")]
    nxt = next((i for i in ids if i < inv["id"]), None)
    profile = industry.get(rules.settings_for(c.business["id"])["industry"])
    return render(request, "review.html", c, inv=inv, audit=db.get_audit(inv["id"]), next_id=nxt, profile=profile,
                  line_extra={k: v for k, v in profile["line"].items() if k not in ("code", "unit")},
                  payable=industry.amount_payable(inv),
                  is_image=Path(inv["stored_path"]).suffix.lower() != ".pdf",
                  xero_connected=bool(xero.connection(c.business["id"])) and c.can("direct_posting"))


@guarded("app")
async def save(request: Request, c: Ctx):
    inv = _inv(c, request)
    if not inv:
        return Response(status_code=404)
    form = await form_checked(request)
    issues = pipeline.save_edits(inv, dict(form), c.who, c.can("supplier_memory"))
    if form.get("action") == "approve":
        ok, msg = pipeline.approve(inv, c.who, c.role)
        flash(request, "Approved." if ok else msg, "ok" if ok else "error")
        if ok and form.get("next_id"):
            return back(f"/invoices/{int(form['next_id'])}")
    else:
        errs = validation.blocking(issues)
        flash(request, "Changes saved." if not errs else f"Saved. {len(errs)} problem(s) still need fixing.",
              "ok" if not errs else "warn")
    return back(f"/invoices/{inv['id']}")


@guarded("app")
async def reject(request: Request, c: Ctx):
    inv = _inv(c, request)
    if not inv:
        return Response(status_code=404)
    form = await form_checked(request)
    pipeline.reject(inv, str(form.get("reason", ""))[:500], c.who)
    flash(request, "Rejected. It won't be exported or posted.")
    return back("/app")


@guarded("app")
async def reopen(request: Request, c: Ctx):
    inv = _inv(c, request)
    if not inv:
        return Response(status_code=404)
    await form_checked(request)
    issues = validation.validate(inv, inv["id"], inv["file_hash"], inv["business_id"])
    db.update_invoice(inv["id"], {"status": validation.status_for(issues), "issues": issues})
    db.audit(inv["id"], "reopen", "", c.who)
    flash(request, "Reopened for review.")
    return back(f"/invoices/{inv['id']}")


@guarded("app")
async def reprocess(request: Request, c: Ctx):
    inv = _inv(c, request)
    if not inv:
        return Response(status_code=404)
    await form_checked(request)
    try:
        pipeline.reprocess(inv, c.who, c.can("supplier_memory"))
        flash(request, "Read the document again. Your earlier edits were replaced.")
    except Exception as exc:
        flash(request, f"Couldn't read the document: {exc}", "error")
    return back(f"/invoices/{inv['id']}")


@guarded("app")
async def original(request: Request, c: Ctx):
    inv = _inv(c, request)
    if not inv:
        return Response(status_code=404)
    return FileResponse(inv["stored_path"], filename=inv["filename"], content_disposition_type="inline")


@guarded("app")
async def switch_business(request: Request, c: Ctx):
    form = await form_checked(request)
    bid = int(form.get("business_id", 0) or 0)
    if any(b["id"] == bid for b in c.businesses):
        request.session["bid"] = bid
    return back("/app")


# ---------------------------------------------------------------------------
# posting & exports
# ---------------------------------------------------------------------------

def _post_one(inv: dict, who: str, xero_status: str) -> tuple[bool, str]:
    if inv["status"] != "approved":
        return False, f"#{inv['id']} isn't approved"
    try:
        xid = xero.post_bill(inv, xero_status)
    except Exception as exc:
        db.audit(inv["id"], "post_failed", str(exc), who)
        return False, f"#{inv['id']} {inv.get('invoice_number')}: {exc}"
    db.update_invoice(inv["id"], {"status": "posted", "external_id": xid, "posted_to": "xero",
                                  "posted_at": db.now()})
    db.audit(inv["id"], "posted", f"Xero {xero_status.lower()} bill {xid}", who)
    return True, xid


@guarded("app")
async def post_xero(request: Request, c: Ctx):
    form = await form_checked(request)
    if not c.can("direct_posting"):
        flash(request, "Direct posting to Xero is part of Standard and above. Use the Xero CSV, or upgrade.", "warn")
        return back("/account")
    status = "AUTHORISED" if form.get("xero_status") == "AUTHORISED" else "DRAFT"
    if "id" in request.path_params:
        one = _inv(c, request)
        targets = [one] if one else []
    else:
        targets = db.list_invoices(c.business["id"], "approved")
    ok = 0
    for inv in targets:
        good, msg = _post_one(inv, c.who, status)
        ok += good
        if not good:
            flash(request, msg, "error")
    if ok:
        flash(request, f"Sent {ok} to Xero as {'draft bills' if status == 'DRAFT' else 'bills awaiting payment'}.")
    if not targets:
        flash(request, "Nothing approved to send.", "warn")
    return back("/app")


@guarded("app")
async def export(request: Request, c: Ctx):
    fmt = request.path_params["fmt"]
    if fmt not in exports.EXPORTERS:
        return Response("Unknown format", status_code=404)
    status = request.query_params.get("status", "approved")
    invoices = db.list_invoices(c.business["id"], status if status != "all" else None)
    body = exports.EXPORTERS[fmt][1](invoices)
    if request.query_params.get("mark") == "1" and fmt != "summary":
        for inv in invoices:
            if inv["status"] == "approved":
                db.update_invoice(inv["id"], {"status": "posted", "posted_to": f"{fmt} csv", "posted_at": db.now()})
                db.audit(inv["id"], "exported", f"{fmt} CSV", c.who)
    name = f"{fmt}-bills-{date.today().isoformat()}.csv"
    return Response(body, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ---------------------------------------------------------------------------
# connections (per business)
# ---------------------------------------------------------------------------

@guarded("app")
async def settings(request: Request, c: Ctx):
    accounts_list, acct_error = [], None
    conn = xero.connection(c.business["id"])
    if conn:
        try:
            accounts_list = [a for a in xero.list_accounts(c.business["id"])
                             if a["type"] in ("EXPENSE", "DIRECTCOSTS", "OVERHEADS", "FIXED")]
        except Exception as exc:
            acct_error = str(exc)
    from . import peppol as _peppol
    return render(request, "settings.html", c, xero_configured=xero.configured(), conn=conn,
                  api_keys=db.q("SELECT * FROM api_keys WHERE business_id = ? ORDER BY id", (c.business["id"],)),
                  peppol_on=_peppol.configured(), base_url=config.BASE_URL.rstrip("/"),
                  industry_label=industry.get(rules.settings_for(c.business["id"])["industry"])["label"],
                  accounts=accounts_list, acct_error=acct_error, ai_enabled=bool(config.ANTHROPIC_API_KEY),
                  model=config.EXTRACTION_MODEL, redirect_uri=config.XERO_REDIRECT_URI,
                  can_post=c.can("direct_posting"))


@guarded("manager")
async def xero_connect(request: Request, c: Ctx):
    if not xero.configured():
        flash(request, "Xero isn't set up on this server yet.", "error")
        return back("/settings")
    if not c.can("direct_posting"):
        flash(request, "Connecting Xero is part of Standard and above.", "warn")
        return back("/account")
    return RedirectResponse(xero.authorize_url(c.business["id"]))


@guarded("manager")
async def xero_callback(request: Request, c: Ctx):
    q = request.query_params
    if q.get("error"):
        flash(request, f"Xero didn't connect: {q.get('error_description') or q['error']}", "error")
        return back("/settings")
    bid = xero.state_business(q.get("state", ""))
    if not any(b["id"] == bid for b in c.businesses):
        flash(request, "That Xero connection doesn't belong to this account.", "error")
        return back("/settings")
    try:
        conn = xero.handle_callback(q.get("code", ""), q.get("state", ""), bid)
        request.session["bid"] = bid
        flash(request, f"Connected to {conn['tenant_name']}.")
    except Exception as exc:
        flash(request, str(exc), "error")
    return back("/settings")


@guarded("manager")
async def xero_disconnect(request: Request, c: Ctx):
    await form_checked(request)
    xero.disconnect(c.business["id"])
    flash(request, "Disconnected from Xero.")
    return back("/settings")


# ---------------------------------------------------------------------------
# account: package, billing, businesses, team, profile
# ---------------------------------------------------------------------------

@guarded("account")
async def account(request: Request, c: Ctx):
    q = request.query_params
    if q.get("billing") == "success":
        flash(request, "Thanks - your subscription is being set up. It can take a few seconds to show here.")
    elif q.get("billing") == "cancelled":
        flash(request, "Checkout was cancelled. Nothing was charged.", "warn")
    users = db.list_users(c.tenant["id"])
    return render(request, "account.html", c, usage=accounts.usage(c.tenant), users=users,
                  plan=plans.get(c.tenant["plan"]), can_add_user=accounts.can_add_user(c.tenant),
                  can_add_business=accounts.can_add_business(c.tenant),
                  trial_left=accounts.days_left(c.tenant.get("trial_ends_at")))


@guarded("manager")
async def checkout(request: Request, c: Ctx):
    form = await form_checked(request)
    plan = str(form.get("plan", "")) if str(form.get("plan", "")) in plans.PLANS else c.tenant["plan"]
    interval = "yearly" if form.get("interval") == "yearly" else "monthly"
    if c.role != "owner":
        flash(request, "Only the account owner can change billing.", "error")
        return back("/account")
    if not billing.enabled():
        # No card payments yet: during the trial the customer can still switch package
        if c.tenant["status"] == "trialing":
            db.update_tenant(c.tenant["id"], {"plan": plan, "billing_interval": interval})
            db.admin_log(c.tenant["id"], "plan_change", f"trial switched to {plan}", c.who)
            flash(request, f"Your trial is now on {plans.get(plan)['name']}.")
        else:
            flash(request, "Card payments aren't switched on yet. Contact us to activate your package.", "warn")
        return back("/account")
    if c.tenant.get("stripe_subscription_id") and c.tenant["status"] in ("active", "past_due", "trialing"):
        return _portal_redirect(request, c)  # existing subscribers change plan in Stripe's portal
    try:
        return RedirectResponse(billing.checkout_url(c.tenant, c.user, plan, interval), status_code=303)
    except billing.BillingError as exc:
        flash(request, str(exc), "error")
        return back("/account")


@guarded("manager")
async def portal(request: Request, c: Ctx):
    await form_checked(request)
    return _portal_redirect(request, c)


def _portal_redirect(request: Request, c: Ctx):
    try:
        return RedirectResponse(billing.portal_url(c.tenant), status_code=303)
    except billing.BillingError as exc:
        flash(request, str(exc), "error")
        return back("/account")


@guarded("manager")
async def add_business(request: Request, c: Ctx):
    form = await form_checked(request)
    name = str(form.get("name", "")).strip()[:120]
    if not name:
        flash(request, "Enter a business name.", "error")
    elif not accounts.can_add_business(c.tenant):
        flash(request, f"Your package includes {plans.get(c.tenant['plan'])['businesses']} business(es). "
                       "Upgrade to add more.", "warn")
    else:
        bid = db.create_business(c.tenant["id"], name)
        request.session["bid"] = bid
        db.admin_log(c.tenant["id"], "business_added", name, c.who)
        flash(request, f"Added {name}. You're now working in it.")
    return back("/account")


@guarded("manager")
async def rename_business(request: Request, c: Ctx):
    form = await form_checked(request)
    bid = int(request.path_params["id"])
    name = str(form.get("name", "")).strip()[:120]
    if name and any(b["id"] == bid for b in c.businesses):
        db.rename_business(bid, name)
        flash(request, "Renamed.")
    return back("/account")


@guarded("manager")
async def invite_user(request: Request, c: Ctx):
    form = await form_checked(request)
    email = str(form.get("email", "")).strip().lower()
    role = str(form.get("role", "reviewer"))
    if role not in ("admin", "reviewer") or (role == "admin" and c.role != "owner"):
        role = "reviewer"
    if not accounts.EMAIL_RE.match(email):
        flash(request, "Enter a valid email address.", "error")
    elif db.user_by_email(email):
        flash(request, "That email already has an account.", "error")
    elif not accounts.can_add_user(c.tenant):
        flash(request, f"Your package includes {plans.get(c.tenant['plan'])['users']} users. Upgrade to add more.", "warn")
    else:
        uid = db.create_user(email, c.tenant["id"], role)
        token = accounts.new_token(uid, "invite", 24 * 7)
        sent = mailer.invite(email, token, c.tenant["name"], c.user["name"] or c.user["email"])
        db.admin_log(c.tenant["id"], "user_invited", f"{email} as {role}", c.who)
        if sent:
            flash(request, f"Invitation sent to {email}.")
        else:
            flash(request, f"Email isn't set up, so send {email} this link yourself: {mailer.link('/invite/' + token)}", "warn")
    return back("/account")


@guarded("manager")
async def change_user(request: Request, c: Ctx):
    form = await form_checked(request)
    target = db.get_user(int(request.path_params["id"]))
    if not target or target["tenant_id"] != c.tenant["id"]:
        return Response(status_code=404)
    if target["role"] == "owner" or (c.user and target["id"] == c.user["id"]):
        flash(request, "You can't change the owner or yourself here.", "error")
        return back("/account")
    action = form.get("action")
    if action == "remove":
        db.delete_user(target["id"])
        db.admin_log(c.tenant["id"], "user_removed", target["email"], c.who)
        flash(request, f"Removed {target['email']}.")
    elif action in ("admin", "reviewer"):
        if action == "admin" and c.role != "owner":
            flash(request, "Only the owner can make someone an admin.", "error")
        else:
            db.update_user(target["id"], {"role": action})
            flash(request, f"{target['email']} is now {accounts.ROLES[action].lower()}.")
    return back("/account")


@guarded("login")
async def profile(request: Request, c: Ctx):
    form = await form_checked(request)
    if not accounts.check_password(str(form.get("current", "")), c.user["password_hash"]):
        flash(request, "Your current password isn't right.", "error")
    elif accounts.password_problem(str(form.get("password", ""))):
        flash(request, accounts.password_problem(str(form.get("password", ""))), "error")
    else:
        db.update_user(c.user["id"], {"password_hash": accounts.hash_password(str(form["password"]))})
        flash(request, "Password changed.")
    return back("/admin/profile" if c.is_super and not c.tenant else "/account")


# ---------------------------------------------------------------------------
# Stripe webhook, API, health
# ---------------------------------------------------------------------------

async def stripe_webhook(request: Request):
    payload = await request.body()
    if not config.STRIPE_WEBHOOK_SECRET or not billing.verify_signature(
            payload, request.headers.get("stripe-signature", ""), config.STRIPE_WEBHOOK_SECRET):
        return Response("bad signature", status_code=400)
    try:
        result = billing.handle_event(json.loads(payload))
    except Exception as exc:
        log.exception("Stripe webhook failed")
        return Response(f"error: {exc}", status_code=500)  # Stripe retries
    return JSONResponse({"received": True, "result": result})


@guarded("app")
async def api_invoices(request: Request, c: Ctx):
    if not c.can("api"):
        return JSONResponse({"error": "API access is part of Advanced and Practice."}, status_code=403)
    invs = db.list_invoices(c.business["id"], request.query_params.get("status"))
    for i in invs:
        i.pop("raw", None)
        i.pop("stored_path", None)
    return JSONResponse(invs)


async def health(request: Request):
    return JSONResponse({"ok": True})


# ---------------------------------------------------------------------------
# startup
# ---------------------------------------------------------------------------

def bootstrap() -> None:
    db.init_db()
    if db.count_superadmins() == 0:
        login_id = (config.ADMIN_EMAIL or config.ADMIN_USER).strip().lower()
        if not db.user_by_email(login_id):
            db.create_user(login_id, None, "superadmin", "Administrator",
                           accounts.hash_password(config.ADMIN_PASSWORD), verified=True)
    # Invoices from the single-company version go into a demo account you can open from master control
    if db.q1("SELECT 1 FROM invoices WHERE business_id IS NULL LIMIT 1") or db.get_setting("xero_connection"):
        tid = db.create_tenant("Demo account", "practice", "comped", None)
        db.update_tenant(tid, {"comped_until": "2099-12-31"})
        bid = db.create_business(tid, "Demo business")
        db.adopt_orphans(tid, bid)


routes = [
    Route("/", home),
    Route("/pricing", pricing),
    Route("/signup", signup, methods=["GET", "POST"]),
    Route("/login", login, methods=["GET", "POST"]),
    Route("/logout", logout),
    Route("/verify/{token}", verify),
    Route("/forgot", forgot, methods=["GET", "POST"]),
    Route("/reset/{token}", reset, methods=["GET", "POST"]),
    Route("/invite/{token}", accept_invite, methods=["GET", "POST"]),
    Route("/app", register),
    Route("/upload", upload, methods=["POST"]),
    Route("/business/switch", switch_business, methods=["POST"]),
    Route("/invoices/{id:int}", review),
    Route("/invoices/{id:int}/save", save, methods=["POST"]),
    Route("/invoices/{id:int}/reject", reject, methods=["POST"]),
    Route("/invoices/{id:int}/reopen", reopen, methods=["POST"]),
    Route("/invoices/{id:int}/reprocess", reprocess, methods=["POST"]),
    Route("/invoices/{id:int}/file", original),
    Route("/invoices/{id:int}/post-xero", post_xero, methods=["POST"]),
    Route("/post-xero", post_xero, methods=["POST"]),
    Route("/export/{fmt}", export),
    Route("/settings", settings),
    Route("/xero/connect", xero_connect),
    Route("/xero/callback", xero_callback),
    Route("/xero/disconnect", xero_disconnect, methods=["POST"]),
    Route("/account", account),
    Route("/account/billing/checkout", checkout, methods=["POST"]),
    Route("/account/billing/portal", portal, methods=["POST"]),
    Route("/account/businesses", add_business, methods=["POST"]),
    Route("/account/businesses/{id:int}", rename_business, methods=["POST"]),
    Route("/account/users", invite_user, methods=["POST"]),
    Route("/account/users/{id:int}", change_user, methods=["POST"]),
    Route("/account/password", profile, methods=["POST"]),
    Route("/stripe/webhook", stripe_webhook, methods=["POST"]),
    Route("/api/invoices", api_invoices),
    Route("/health", health),
    *admin.routes,
    *capture.routes,
    *mail_web.routes,
    *esign.routes,
    *purchasing.routes,
    *statements.routes,
    *settings_web.routes,
    Mount("/static", StaticFiles(directory=str(BASE / "static")), name="static"),
]

bootstrap()
app = Starlette(routes=routes, middleware=[
    Middleware(SessionMiddleware, secret_key=config.SECRET_KEY, same_site="lax", max_age=60 * 60 * 12,
               https_only=config.SECURE_COOKIES),
])
