"""SQLite storage. Swap for PostgreSQL when moving to multi-client SaaS."""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    file_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'needs_review',
    document_type TEXT,
    supplier_name TEXT,
    supplier_vat_number TEXT,
    supplier_email TEXT,
    supplier_address TEXT,
    invoice_number TEXT,
    invoice_date TEXT,
    due_date TEXT,
    po_number TEXT,
    currency TEXT,
    net_total REAL,
    vat_total REAL,
    gross_total REAL,
    line_items TEXT,
    extraction_method TEXT,
    confidence REAL,
    issues TEXT,
    raw TEXT,
    external_id TEXT,
    posted_to TEXT,
    posted_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_inv_hash ON invoices(file_hash);
CREATE INDEX IF NOT EXISTS idx_inv_supplier_no ON invoices(supplier_name, invoice_number);

CREATE TABLE IF NOT EXISTS suppliers (
    name TEXT PRIMARY KEY,
    account_code TEXT,
    vat_number TEXT,
    updated_at TEXT
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER,
    action TEXT NOT NULL,
    detail TEXT,
    user TEXT,
    at TEXT NOT NULL
);
"""

JSON_FIELDS = ("line_items", "issues", "raw")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def connect():
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)


def _row_to_dict(row) -> dict | None:
    if row is None:
        return None
    d = dict(row)
    for f in JSON_FIELDS:
        if d.get(f):
            d[f] = json.loads(d[f])
        else:
            d[f] = [] if f != "raw" else {}
    return d


def _encode(values: dict) -> dict:
    out = {}
    for k, v in values.items():
        out[k] = json.dumps(v) if k in JSON_FIELDS and v is not None else v
    return out


# ---- invoices -------------------------------------------------------------

def insert_invoice(values: dict) -> int:
    values = _encode({**values, "created_at": now(), "updated_at": now()})
    cols = ", ".join(values)
    marks = ", ".join("?" for _ in values)
    with connect() as conn:
        cur = conn.execute(f"INSERT INTO invoices ({cols}) VALUES ({marks})", list(values.values()))
        return cur.lastrowid


def update_invoice(invoice_id: int, values: dict) -> None:
    values = _encode({**values, "updated_at": now()})
    sets = ", ".join(f"{k} = ?" for k in values)
    with connect() as conn:
        conn.execute(f"UPDATE invoices SET {sets} WHERE id = ?", [*values.values(), invoice_id])


def get_invoice(invoice_id: int) -> dict | None:
    with connect() as conn:
        return _row_to_dict(conn.execute("SELECT * FROM invoices WHERE id = ?", (invoice_id,)).fetchone())


def list_invoices(status: str | None = None) -> list[dict]:
    q, args = "SELECT * FROM invoices", []
    if status:
        q += " WHERE status = ?"
        args.append(status)
    q += " ORDER BY id DESC"
    with connect() as conn:
        return [_row_to_dict(r) for r in conn.execute(q, args).fetchall()]


def find_by_hash(file_hash: str, exclude_id: int | None = None) -> dict | None:
    with connect() as conn:
        row = conn.execute(
            "SELECT * FROM invoices WHERE file_hash = ? AND id != ? AND status != 'rejected'",
            (file_hash, exclude_id or -1),
        ).fetchone()
        return _row_to_dict(row)


def find_duplicates(supplier: str, number: str, exclude_id: int | None = None) -> list[dict]:
    if not supplier or not number:
        return []
    with connect() as conn:
        rows = conn.execute(
            """SELECT * FROM invoices
               WHERE lower(trim(supplier_name)) = lower(trim(?))
                 AND lower(replace(invoice_number,' ','')) = lower(replace(?,' ',''))
                 AND id != ? AND status != 'rejected'""",
            (supplier, number, exclude_id or -1),
        ).fetchall()
        return [_row_to_dict(r) for r in rows]


def status_counts() -> dict:
    with connect() as conn:
        rows = conn.execute("SELECT status, COUNT(*) c FROM invoices GROUP BY status").fetchall()
        return {r["status"]: r["c"] for r in rows}


# ---- suppliers (remembers account coding per supplier) ---------------------

def get_supplier(name: str) -> dict | None:
    if not name:
        return None
    with connect() as conn:
        row = conn.execute("SELECT * FROM suppliers WHERE lower(name) = lower(?)", (name.strip(),)).fetchone()
        return dict(row) if row else None


def upsert_supplier(name: str, account_code: str | None, vat_number: str | None) -> None:
    if not name:
        return
    with connect() as conn:
        conn.execute(
            """INSERT INTO suppliers (name, account_code, vat_number, updated_at) VALUES (?, ?, ?, ?)
               ON CONFLICT(name) DO UPDATE SET
                 account_code = COALESCE(excluded.account_code, suppliers.account_code),
                 vat_number = COALESCE(excluded.vat_number, suppliers.vat_number),
                 updated_at = excluded.updated_at""",
            (name.strip(), account_code, vat_number, now()),
        )


# ---- settings / audit -----------------------------------------------------

def get_setting(key: str, default=None):
    with connect() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return json.loads(row["value"]) if row else default


def set_setting(key: str, value) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, json.dumps(value)),
        )


def audit(invoice_id: int | None, action: str, detail: str = "", user: str = "system") -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO audit_log (invoice_id, action, detail, user, at) VALUES (?, ?, ?, ?, ?)",
            (invoice_id, action, detail, user, now()),
        )


def get_audit(invoice_id: int) -> list[dict]:
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM audit_log WHERE invoice_id = ? ORDER BY id DESC", (invoice_id,)
        ).fetchall()
        return [dict(r) for r in rows]
