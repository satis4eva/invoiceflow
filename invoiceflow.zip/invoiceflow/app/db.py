"""SQLite storage for a multi-company app.

Model:  account (the paying customer, "tenant")
          -> businesses (the companies whose invoices are processed)
               -> invoices, suppliers, accounting connections
          -> users (owner / admin / reviewer)
        superadmin users (you) have no account and use the master control panel.
"""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS tenants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    plan TEXT NOT NULL DEFAULT 'basic',
    billing_interval TEXT NOT NULL DEFAULT 'monthly',
    status TEXT NOT NULL DEFAULT 'trialing',      -- trialing, active, past_due, paused, cancelled, comped
    trial_ends_at TEXT,
    comped_until TEXT,                             -- free access granted from master control
    period_start TEXT,
    period_end TEXT,
    stripe_customer_id TEXT,
    stripe_subscription_id TEXT,
    notes TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS businesses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id INTEGER NOT NULL REFERENCES tenants(id),
    name TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_biz_tenant ON businesses(tenant_id);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id INTEGER REFERENCES tenants(id),       -- NULL for superadmins
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name TEXT,
    password_hash TEXT,                              -- NULL until an invite is accepted
    role TEXT NOT NULL DEFAULT 'owner',              -- owner, admin, reviewer, superadmin
    email_verified INTEGER NOT NULL DEFAULT 0,
    token TEXT,                                      -- email verification / invite / reset token
    token_purpose TEXT,
    token_expires TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    last_login TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_users_token ON users(token);

CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id INTEGER,
    business_id INTEGER,
    filename TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    file_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'needs_review',
    document_type TEXT,
    supplier_name TEXT,
    supplier_vat_number TEXT,
    supplier_email TEXT,
    supplier_address TEXT,
    invoice_number TEXT,
    invoice_date TEXT,
    due_date TEXT,
    po_number TEXT,
    currency TEXT,
    net_total REAL,
    vat_total REAL,
    gross_total REAL,
    line_items TEXT,
    extraction_method TEXT,
    confidence REAL,
    issues TEXT,
    raw TEXT,
    external_id TEXT,
    posted_to TEXT,
    posted_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS supplier_rules (
    business_id INTEGER NOT NULL,
    name TEXT NOT NULL COLLATE NOCASE,
    account_code TEXT,
    vat_number TEXT,
    updated_at TEXT,
    PRIMARY KEY (business_id, name)
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER,
    action TEXT NOT NULL,
    detail TEXT,
    user TEXT,
    at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS admin_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id INTEGER,
    action TEXT NOT NULL,
    detail TEXT,
    actor TEXT,
    at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stripe_events (
    id TEXT PRIMARY KEY,
    type TEXT,
    at TEXT
);
"""

JSON_FIELDS = ("line_items", "issues", "raw")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def connect():
    conn = sqlite3.connect(config.DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def q(sql: str, args=()) -> list[dict]:
    with connect() as conn:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]


def q1(sql: str, args=()) -> dict | None:
    rows = q(sql, args)
    return rows[0] if rows else None


def ex(sql: str, args=()) -> int:
    with connect() as conn:
        cur = conn.execute(sql, args)
        return cur.lastrowid


def _cols(conn, table) -> set[str]:
    return {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def init_db() -> None:
    with connect() as conn:
        # Upgrade an older single-company database before applying the schema
        tables = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "invoices" in tables:
            cols = _cols(conn, "invoices")
            for col in ("tenant_id", "business_id"):
                if col not in cols:
                    conn.execute(f"ALTER TABLE invoices ADD COLUMN {col} INTEGER")
        conn.executescript(SCHEMA)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_inv_biz ON invoices(business_id, status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_inv_hash ON invoices(business_id, file_hash)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_inv_tenant_created ON invoices(tenant_id, created_at)")


def adopt_orphans(tenant_id: int, business_id: int) -> None:
    """Attach invoices and settings from the old single-company version to an account."""
    with connect() as conn:
        n = conn.execute("UPDATE invoices SET tenant_id = ?, business_id = ? WHERE business_id IS NULL",
                         (tenant_id, business_id)).rowcount
        tables = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "suppliers" in tables:
            conn.execute("""INSERT OR IGNORE INTO supplier_rules (business_id, name, account_code, vat_number, updated_at)
                            SELECT ?, name, account_code, vat_number, updated_at FROM suppliers""", (business_id,))
            conn.execute("DROP TABLE suppliers")
        old = conn.execute("SELECT value FROM settings WHERE key = 'xero_connection'").fetchone()
        if old:
            conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                         (f"b{business_id}:xero_connection", old["value"]))
            conn.execute("DELETE FROM settings WHERE key = 'xero_connection'")
    if n:
        admin_log(tenant_id, "migrated", f"{n} invoices from the single-company version", "system")


# ---- tenants (accounts) ---------------------------------------------------------

def create_tenant(name: str, plan: str, status: str, trial_ends_at: str | None,
                  interval: str = "monthly") -> int:
    return ex("""INSERT INTO tenants (name, plan, billing_interval, status, trial_ends_at, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)""", (name, plan, interval, status, trial_ends_at, now(), now()))


def get_tenant(tenant_id: int) -> dict | None:
    return q1("SELECT * FROM tenants WHERE id = ?", (tenant_id,))


def tenant_by_stripe(customer_id: str) -> dict | None:
    return q1("SELECT * FROM tenants WHERE stripe_customer_id = ?", (customer_id,)) if customer_id else None


def update_tenant(tenant_id: int, values: dict) -> None:
    values = {**values, "updated_at": now()}
    sets = ", ".join(f"{k} = ?" for k in values)
    ex(f"UPDATE tenants SET {sets} WHERE id = ?", [*values.values(), tenant_id])


def list_tenants(search: str = "", status: str = "") -> list[dict]:
    sql = """SELECT t.*,
               (SELECT email FROM users u WHERE u.tenant_id = t.id AND u.role = 'owner' ORDER BY u.id LIMIT 1) owner_email,
               (SELECT COUNT(*) FROM users u WHERE u.tenant_id = t.id) user_count,
               (SELECT COUNT(*) FROM businesses b WHERE b.tenant_id = t.id) business_count,
               (SELECT MAX(last_login) FROM users u WHERE u.tenant_id = t.id) last_login
             FROM tenants t WHERE 1=1"""
    args = []
    if search:
        sql += """ AND (t.name LIKE ? OR EXISTS (SELECT 1 FROM users u WHERE u.tenant_id = t.id AND u.email LIKE ?))"""
        args += [f"%{search}%", f"%{search}%"]
    if status:
        sql += " AND t.status = ?"
        args.append(status)
    return q(sql + " ORDER BY t.id DESC", args)


# ---- businesses -----------------------------------------------------------------

def create_business(tenant_id: int, name: str) -> int:
    return ex("INSERT INTO businesses (tenant_id, name, created_at) VALUES (?, ?, ?)", (tenant_id, name, now()))


def list_businesses(tenant_id: int) -> list[dict]:
    return q("SELECT * FROM businesses WHERE tenant_id = ? ORDER BY name", (tenant_id,))


def get_business(business_id: int) -> dict | None:
    return q1("SELECT * FROM businesses WHERE id = ?", (business_id,))


def rename_business(business_id: int, name: str) -> None:
    ex("UPDATE businesses SET name = ? WHERE id = ?", (name, business_id))


# ---- users ------------------------------------------------------------------------

def create_user(email: str, tenant_id: int | None, role: str, name: str = "", password_hash: str | None = None,
                verified: bool = False) -> int:
    return ex("""INSERT INTO users (tenant_id, email, name, password_hash, role, email_verified, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)""",
              (tenant_id, email.strip().lower(), name, password_hash, role, int(verified), now()))


def get_user(user_id: int) -> dict | None:
    return q1("SELECT * FROM users WHERE id = ?", (user_id,))


def user_by_email(email: str) -> dict | None:
    return q1("SELECT * FROM users WHERE email = ?", ((email or "").strip().lower(),))


def user_by_token(token: str, purpose: str) -> dict | None:
    if not token:
        return None
    u = q1("SELECT * FROM users WHERE token = ? AND token_purpose = ?", (token, purpose))
    if u and u["token_expires"] and u["token_expires"] < now():
        return None
    return u


def update_user(user_id: int, values: dict) -> None:
    sets = ", ".join(f"{k} = ?" for k in values)
    ex(f"UPDATE users SET {sets} WHERE id = ?", [*values.values(), user_id])


def delete_user(user_id: int) -> None:
    ex("DELETE FROM users WHERE id = ?", (user_id,))


def list_users(tenant_id: int) -> list[dict]:
    return q("SELECT * FROM users WHERE tenant_id = ? ORDER BY id", (tenant_id,))


def count_superadmins() -> int:
    return q1("SELECT COUNT(*) c FROM users WHERE role = 'superadmin'")["c"]


# ---- invoices (always scoped to a business) --------------------------------------

def _row(d: dict | None) -> dict | None:
    if d is None:
        return None
    for f in JSON_FIELDS:
        d[f] = json.loads(d[f]) if d.get(f) else ([] if f != "raw" else {})
    return d


def _encode(values: dict) -> dict:
    return {k: (json.dumps(v) if k in JSON_FIELDS and v is not None else v) for k, v in values.items()}


def insert_invoice(values: dict) -> int:
    values = _encode({**values, "created_at": now(), "updated_at": now()})
    cols = ", ".join(values)
    marks = ", ".join("?" for _ in values)
    return ex(f"INSERT INTO invoices ({cols}) VALUES ({marks})", list(values.values()))


def update_invoice(invoice_id: int, values: dict) -> None:
    values = _encode({**values, "updated_at": now()})
    sets = ", ".join(f"{k} = ?" for k in values)
    ex(f"UPDATE invoices SET {sets} WHERE id = ?", [*values.values(), invoice_id])


def get_invoice(invoice_id: int, business_id: int | None = None) -> dict | None:
    if business_id is None:
        return _row(q1("SELECT * FROM invoices WHERE id = ?", (invoice_id,)))
    return _row(q1("SELECT * FROM invoices WHERE id = ? AND business_id = ?", (invoice_id, business_id)))


def list_invoices(business_id: int, status: str | None = None) -> list[dict]:
    sql, args = "SELECT * FROM invoices WHERE business_id = ?", [business_id]
    if status:
        sql += " AND status = ?"
        args.append(status)
    return [_row(r) for r in q(sql + " ORDER BY id DESC", args)]


def find_by_hash(business_id: int, file_hash: str, exclude_id: int | None = None) -> dict | None:
    return _row(q1("""SELECT * FROM invoices WHERE business_id = ? AND file_hash = ? AND id != ?
                      AND status != 'rejected'""", (business_id, file_hash, exclude_id or -1)))


def find_duplicates(business_id: int, supplier: str, number: str, exclude_id: int | None = None) -> list[dict]:
    if not supplier or not number:
        return []
    return [_row(r) for r in q(
        """SELECT * FROM invoices WHERE business_id = ?
             AND lower(trim(supplier_name)) = lower(trim(?))
             AND lower(replace(invoice_number,' ','')) = lower(replace(?,' ',''))
             AND id != ? AND status != 'rejected'""",
        (business_id, supplier, number, exclude_id or -1))]


def status_counts(business_id: int) -> dict:
    return {r["status"]: r["c"] for r in q(
        "SELECT status, COUNT(*) c FROM invoices WHERE business_id = ? GROUP BY status", (business_id,))}


def count_invoices_since(tenant_id: int, since: str) -> int:
    return q1("SELECT COUNT(*) c FROM invoices WHERE tenant_id = ? AND created_at >= ?", (tenant_id, since))["c"]


# ---- supplier coding memory (per business) ----------------------------------------

def get_supplier(business_id: int, name: str) -> dict | None:
    if not name:
        return None
    return q1("SELECT * FROM supplier_rules WHERE business_id = ? AND name = ?", (business_id, name.strip()))


def upsert_supplier(business_id: int, name: str, account_code: str | None, vat_number: str | None) -> None:
    if not name:
        return
    ex("""INSERT INTO supplier_rules (business_id, name, account_code, vat_number, updated_at) VALUES (?, ?, ?, ?, ?)
          ON CONFLICT(business_id, name) DO UPDATE SET
            account_code = COALESCE(excluded.account_code, supplier_rules.account_code),
            vat_number = COALESCE(excluded.vat_number, supplier_rules.vat_number),
            updated_at = excluded.updated_at""",
       (business_id, name.strip(), account_code, vat_number, now()))


# ---- settings / logs ----------------------------------------------------------------

def get_setting(key: str, default=None):
    row = q1("SELECT value FROM settings WHERE key = ?", (key,))
    return json.loads(row["value"]) if row else default


def set_setting(key: str, value) -> None:
    ex("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
       (key, json.dumps(value)))


def audit(invoice_id: int | None, action: str, detail: str = "", user: str = "system") -> None:
    ex("INSERT INTO audit_log (invoice_id, action, detail, user, at) VALUES (?, ?, ?, ?, ?)",
       (invoice_id, action, detail, user, now()))


def get_audit(invoice_id: int) -> list[dict]:
    return q("SELECT * FROM audit_log WHERE invoice_id = ? ORDER BY id DESC", (invoice_id,))


def admin_log(tenant_id: int | None, action: str, detail: str = "", actor: str = "system") -> None:
    ex("INSERT INTO admin_log (tenant_id, action, detail, actor, at) VALUES (?, ?, ?, ?, ?)",
       (tenant_id, action, detail, actor, now()))


def get_admin_log(tenant_id: int | None = None, limit: int = 50) -> list[dict]:
    if tenant_id is None:
        return q("SELECT * FROM admin_log ORDER BY id DESC LIMIT ?", (limit,))
    return q("SELECT * FROM admin_log WHERE tenant_id = ? ORDER BY id DESC LIMIT ?", (tenant_id, limit))


def stripe_event_seen(event_id: str, event_type: str) -> bool:
    """Record a webhook event; True if it was already processed."""
    try:
        ex("INSERT INTO stripe_events (id, type, at) VALUES (?, ?, ?)", (event_id, event_type, now()))
        return False
    except sqlite3.IntegrityError:
        return True
