"""Work mailboxes: accountants connect their own email (any SMTP provider, or Google / Microsoft
sign-in) and send from inside each client business. Every email is logged against the business."""
import base64
import imaplib
import ipaddress
import json
import re
import secrets
import smtplib
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from email.message import EmailMessage
from email.utils import formataddr, make_msgid
from html import escape

from . import config, crypto, db

EMAIL_RE = re.compile(r"^[^@\s,;<>\"]+@[^@\s,;<>\"]+\.[^@\s,;<>\"]+$")
DAILY_LIMIT = 500
MAX_ATTACH = 20 * 1024 * 1024

PRESETS = {  # common providers, so people don't need to know server names
    "hostinger": {"label": "Hostinger email", "smtp_host": "smtp.hostinger.com", "smtp_port": 465, "security": "ssl",
                  "imap_host": "imap.hostinger.com"},
    "microsoft365": {"label": "Microsoft 365 / Outlook", "smtp_host": "smtp.office365.com", "smtp_port": 587,
                     "security": "starttls", "imap_host": "outlook.office365.com"},
    "gmail": {"label": "Gmail / Google Workspace (app password)", "smtp_host": "smtp.gmail.com", "smtp_port": 465,
              "security": "ssl", "imap_host": ""},
    "zoho": {"label": "Zoho Mail (UK/EU)", "smtp_host": "smtp.zoho.eu", "smtp_port": 465, "security": "ssl",
             "imap_host": "imap.zoho.eu"},
    "other": {"label": "Other provider", "smtp_host": "", "smtp_port": 587, "security": "starttls", "imap_host": ""},
}


class MailError(Exception):
    pass


def clean_header(v: str) -> str:
    return re.sub(r"[\r\n]+", " ", v or "").strip()


def parse_addresses(raw: str) -> list[str]:
    out = []
    for part in re.split(r"[,;\s]+", raw or ""):
        part = part.strip().strip("<>")
        if part:
            if not EMAIL_RE.match(part):
                raise MailError(f"'{part}' isn't a valid email address")
            out.append(part.lower())
    return out


# ---- mailbox records ----------------------------------------------------------------------

def create(tenant_id: int, user_id: int | None, kind: str, from_email: str, from_name: str, settings: dict,
           shared: bool = True, label: str = "") -> int:
    return db.ex("""INSERT INTO mailboxes (tenant_id, user_id, kind, label, from_name, from_email, config_enc, shared, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                 (tenant_id, user_id, kind, label or from_email, clean_header(from_name), from_email.lower(),
                  crypto.seal(settings), int(shared), db.now()))


def get(mailbox_id: int | None, tenant_id: int) -> dict | None:
    if not mailbox_id:
        return None
    return db.q1("SELECT * FROM mailboxes WHERE id = ? AND tenant_id = ?", (mailbox_id, tenant_id))


def usable(tenant_id: int, user: dict | None, impersonating: bool = False) -> list[dict]:
    rows = db.q("SELECT * FROM mailboxes WHERE tenant_id = ? ORDER BY from_email", (tenant_id,))
    if impersonating or not user:
        return rows
    return [m for m in rows if m["shared"] or m["user_id"] == user["id"]]


def remove(mailbox_id: int, tenant_id: int) -> None:
    db.ex("DELETE FROM mailboxes WHERE id = ? AND tenant_id = ?", (mailbox_id, tenant_id))
    db.ex("UPDATE businesses SET mailbox_id = NULL WHERE mailbox_id = ? AND tenant_id = ?", (mailbox_id, tenant_id))


def default_for(business: dict, tenant_id: int, user: dict | None, impersonating: bool = False) -> dict | None:
    boxes = usable(tenant_id, user, impersonating)
    chosen = next((m for m in boxes if m["id"] == business.get("mailbox_id")), None)
    return chosen or (boxes[0] if boxes else None)


def sent_today(tenant_id: int) -> int:
    since = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - 86400))
    return db.q1("SELECT COUNT(*) c FROM emails WHERE tenant_id = ? AND created_at >= ? AND status = 'sent'",
                 (tenant_id, since))["c"]


# ---- safety: never let a customer point us at our own network -----------------------------

def check_host(host: str) -> None:
    if not host or not re.fullmatch(r"[A-Za-z0-9.-]+", host):
        raise MailError("Enter a valid server name, for example smtp.yourprovider.com")
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        raise MailError(f"Couldn't find the server {host}. Check the spelling.")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            raise MailError("That server address isn't allowed.")


# ---- building messages --------------------------------------------------------------------

def build_message(mailbox: dict, to: list[str], subject: str, body: str, cc: list[str] | None = None,
                  attachments: list[tuple[str, bytes, str]] | None = None, button: tuple[str, str] | None = None,
                  reply_to: str | None = None) -> EmailMessage:
    msg = EmailMessage()
    msg["From"] = formataddr((clean_header(mailbox.get("from_name") or ""), mailbox["from_email"]))
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    if reply_to:
        msg["Reply-To"] = reply_to
    msg["Subject"] = clean_header(subject)[:250]
    msg["Message-ID"] = make_msgid(domain=mailbox["from_email"].split("@")[-1])
    text = body
    if button:
        text += f"\n\n{button[0]}: {button[1]}\n"
    msg.set_content(text)
    html_body = "<br>".join(escape(line) for line in body.splitlines())
    if button:
        html_body += (f'<p style="margin:24px 0"><a href="{escape(button[1])}" style="background:#24427c;color:#fff;'
                      f'padding:12px 20px;border-radius:6px;text-decoration:none;font-weight:600">{escape(button[0])}</a></p>'
                      f'<p style="color:#5c6a80;font-size:12px">Or open this link: {escape(button[1])}</p>')
    msg.add_alternative(f'<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.5;color:#1d2636">'
                        f'{html_body}</div>', subtype="html")
    total = 0
    for name, content, ctype in attachments or []:
        total += len(content)
        if total > MAX_ATTACH:
            raise MailError("Attachments are larger than 20 MB in total.")
        maintype, _, subtype = (ctype or "application/octet-stream").partition("/")
        msg.add_attachment(content, maintype=maintype, subtype=subtype or "octet-stream", filename=name)
    return msg


# ---- sending -------------------------------------------------------------------------------

def _smtp_send(settings: dict, msg: EmailMessage) -> None:
    check_host(settings["smtp_host"])
    host, port, sec = settings["smtp_host"], int(settings.get("smtp_port") or 587), settings.get("security", "starttls")
    ctx = ssl.create_default_context()
    try:
        if sec == "ssl":
            server = smtplib.SMTP_SSL(host, port, context=ctx, timeout=30)
        else:
            server = smtplib.SMTP(host, port, timeout=30)
            if sec == "starttls":
                server.starttls(context=ctx)
        with server:
            if settings.get("username"):
                server.login(settings["username"], settings.get("password", ""))
            server.send_message(msg)
    except smtplib.SMTPAuthenticationError:
        raise MailError("The mail server rejected the username or password. Some providers need an app password.")
    except (smtplib.SMTPException, OSError) as exc:
        raise MailError(f"Couldn't send through {host}: {exc}")
    if settings.get("imap_host"):
        try:
            _imap_save_sent(settings, msg)
        except Exception:
            pass  # sending worked; a missing Sent copy shouldn't fail it


def _imap_save_sent(settings: dict, msg: EmailMessage) -> None:
    check_host(settings["imap_host"])
    with imaplib.IMAP4_SSL(settings["imap_host"], 993, ssl_context=ssl.create_default_context(), timeout=30) as imap:
        imap.login(settings.get("username", ""), settings.get("password", ""))
        folder = "Sent"
        typ, boxes = imap.list()
        for line in boxes or []:
            text = line.decode(errors="ignore")
            if "\\Sent" in text:
                folder = text.rsplit(' "', 1)[-1].strip('"') if ' "' in text else text.split()[-1]
                break
        imap.append(f'"{folder}"', "\\Seen", imaplib.Time2Internaldate(time.time()), msg.as_bytes())


def _http_json(method: str, url: str, headers: dict, body: bytes | None = None) -> dict:
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        raise MailError(f"{urllib.parse.urlparse(url).netloc} said {exc.code}: {exc.read()[:300].decode(errors='replace')}")


def _refresh_oauth(mailbox: dict, settings: dict) -> dict:
    if time.time() < settings.get("expires_at", 0) - 60:
        return settings
    prov = OAUTH[mailbox["kind"]]
    data = urllib.parse.urlencode({"grant_type": "refresh_token", "refresh_token": settings.get("refresh_token", ""),
                                   "client_id": prov["client_id"](), "client_secret": prov["client_secret"]()}).encode()
    tok = _http_json("POST", prov["token_url"], {"Content-Type": "application/x-www-form-urlencoded"}, data)
    settings["access_token"] = tok["access_token"]
    settings["expires_at"] = time.time() + int(tok.get("expires_in", 3600))
    if tok.get("refresh_token"):
        settings["refresh_token"] = tok["refresh_token"]
    db.ex("UPDATE mailboxes SET config_enc = ? WHERE id = ?", (crypto.seal(settings), mailbox["id"]))
    return settings


def _oauth_send(mailbox: dict, settings: dict, msg: EmailMessage) -> None:
    settings = _refresh_oauth(mailbox, settings)
    auth = {"Authorization": f"Bearer {settings['access_token']}"}
    if mailbox["kind"] == "google":
        raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
        _http_json("POST", "https://gmail.googleapis.com/gmail/v1/users/me/messages/send",
                   {**auth, "Content-Type": "application/json"}, json.dumps({"raw": raw}).encode())
    else:
        _http_json("POST", "https://graph.microsoft.com/v1.0/me/sendMail",
                   {**auth, "Content-Type": "text/plain"}, base64.b64encode(msg.as_bytes()))


def send(mailbox: dict, msg: EmailMessage) -> None:
    settings = crypto.unseal(mailbox.get("config_enc"))
    if not settings:
        raise MailError("This mailbox needs reconnecting.")
    try:
        if mailbox["kind"] == "smtp":
            _smtp_send(settings, msg)
        else:
            _oauth_send(mailbox, settings, msg)
    except MailError as exc:
        db.ex("UPDATE mailboxes SET last_error = ? WHERE id = ?", (str(exc)[:500], mailbox["id"]))
        raise
    db.ex("UPDATE mailboxes SET last_used = ?, last_error = NULL WHERE id = ?", (db.now(), mailbox["id"]))


def send_and_log(tenant_id: int, business_id: int | None, mailbox: dict, who: str, to: list[str], subject: str,
                 body: str, cc: list[str] | None = None, attachments: list[tuple[str, bytes, str]] | None = None,
                 button: tuple[str, str] | None = None, related: str | None = None) -> tuple[bool, str]:
    if sent_today(tenant_id) >= DAILY_LIMIT:
        return False, f"Daily sending limit of {DAILY_LIMIT} emails reached. Try again tomorrow."
    status, error = "sent", None
    try:
        msg = build_message(mailbox, to, subject, body, cc, attachments, button)
        send(mailbox, msg)
    except MailError as exc:
        status, error = "failed", str(exc)
    db.ex("""INSERT INTO emails (tenant_id, business_id, mailbox_id, sent_by, from_addr, to_addrs, cc_addrs, subject, body,
             attachments, status, error, related, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
          (tenant_id, business_id, mailbox["id"], who, mailbox["from_email"], ", ".join(to), ", ".join(cc or []),
           clean_header(subject), body, json.dumps([a[0] for a in attachments or []]), status, error, related, db.now()))
    return status == "sent", error or "Sent"


def test_settings(settings: dict) -> None:
    """Connect and log in without sending anything."""
    check_host(settings["smtp_host"])
    port, sec = int(settings.get("smtp_port") or 587), settings.get("security", "starttls")
    ctx = ssl.create_default_context()
    try:
        server = (smtplib.SMTP_SSL(settings["smtp_host"], port, context=ctx, timeout=20) if sec == "ssl"
                  else smtplib.SMTP(settings["smtp_host"], port, timeout=20))
        with server:
            if sec == "starttls":
                server.starttls(context=ctx)
            if settings.get("username"):
                server.login(settings["username"], settings.get("password", ""))
    except smtplib.SMTPAuthenticationError:
        raise MailError("The mail server rejected the username or password. Some providers need an app password.")
    except (smtplib.SMTPException, OSError) as exc:
        raise MailError(f"Couldn't connect to {settings['smtp_host']}:{port}: {exc}")


# ---- Google / Microsoft sign-in --------------------------------------------------------------

OAUTH = {
    "google": {
        "name": "Google",
        "client_id": lambda: config.GOOGLE_CLIENT_ID, "client_secret": lambda: config.GOOGLE_CLIENT_SECRET,
        "auth_url": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url": "https://oauth2.googleapis.com/token",
        "scope": "openid email profile https://www.googleapis.com/auth/gmail.send",
        "extra": {"access_type": "offline", "prompt": "consent"},
        "me_url": "https://openidconnect.googleapis.com/v1/userinfo",
    },
    "microsoft": {
        "name": "Microsoft",
        "client_id": lambda: config.MICROSOFT_CLIENT_ID, "client_secret": lambda: config.MICROSOFT_CLIENT_SECRET,
        "auth_url": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
        "token_url": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        "scope": "openid email profile offline_access User.Read Mail.Send",
        "extra": {"prompt": "select_account"},
        "me_url": "https://graph.microsoft.com/v1.0/me",
    },
}


def oauth_enabled(kind: str) -> bool:
    p = OAUTH.get(kind)
    return bool(p and p["client_id"]() and p["client_secret"]())


def redirect_uri(kind: str) -> str:
    return f"{config.BASE_URL.rstrip('/')}/mail/oauth/{kind}/callback"


def oauth_start(kind: str) -> tuple[str, str]:
    p = OAUTH[kind]
    state = secrets.token_urlsafe(24)
    url = p["auth_url"] + "?" + urllib.parse.urlencode({
        "client_id": p["client_id"](), "redirect_uri": redirect_uri(kind), "response_type": "code",
        "scope": p["scope"], "state": state, **p["extra"]})
    return url, state


def oauth_finish(kind: str, code: str) -> tuple[str, str, dict]:
    p = OAUTH[kind]
    data = urllib.parse.urlencode({"grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri(kind),
                                   "client_id": p["client_id"](), "client_secret": p["client_secret"]()}).encode()
    tok = _http_json("POST", p["token_url"], {"Content-Type": "application/x-www-form-urlencoded"}, data)
    if not tok.get("refresh_token"):
        raise MailError(f"{p['name']} didn't allow ongoing access. Try again and accept all permissions.")
    me = _http_json("GET", p["me_url"], {"Authorization": f"Bearer {tok['access_token']}"})
    email = me.get("email") or me.get("mail") or me.get("userPrincipalName") or ""
    name = me.get("name") or me.get("displayName") or ""
    if not EMAIL_RE.match(email):
        raise MailError(f"Couldn't read the email address from {p['name']}.")
    settings = {"access_token": tok["access_token"], "refresh_token": tok["refresh_token"],
                "expires_at": time.time() + int(tok.get("expires_in", 3600))}
    return email, name, settings
