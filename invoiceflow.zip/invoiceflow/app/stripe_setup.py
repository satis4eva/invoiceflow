"""One-off Stripe setup: creates the four packages (monthly + yearly GBP prices), the webhook
endpoint and a customer portal configuration, then prints the .env lines to save.

Safe to run again: existing prices are found by lookup key and reused.
    STRIPE_SECRET_KEY=sk_... DOMAIN=app.example.com python -m app.stripe_setup
"""
import sys

from . import billing, config, plans

EVENTS = ["checkout.session.completed", "customer.subscription.created", "customer.subscription.updated",
          "customer.subscription.deleted", "invoice.paid", "invoice.payment_failed", "invoice.created"]


def log(msg: str) -> None:
    print(msg, file=sys.stderr)


def ensure_prices() -> dict[str, str]:
    out, products = {}, {}
    for key in plans.ORDER:
        p = plans.get(key)
        for interval, amount, unit in (("monthly", p["monthly"], "month"), ("yearly", p["yearly"], "year")):
            lookup = f"invoiceflow_{key}_{interval}"
            found = billing._call("GET", f"/prices?lookup_keys[]={lookup}&active=true&limit=1")["data"]
            if found and found[0]["unit_amount"] == amount * 100:
                price = found[0]
                products[key] = price["product"]
                log(f"  found {p['name']} {interval}: {price['id']}")
            else:
                if key not in products:
                    products[key] = billing._call("POST", "/products", {
                        "name": f"{config.APP_NAME} {p['name']}",
                        "description": f"{p['invoices']:,} invoices a month, {p['businesses']} business(es)",
                        "metadata": {"plan": key, "app": "invoiceflow"},
                    })["id"]
                price = billing._call("POST", "/prices", {
                    "product": products[key], "currency": "gbp", "unit_amount": amount * 100,
                    "recurring": {"interval": unit}, "lookup_key": lookup, "transfer_lookup_key": True,
                    "tax_behavior": "exclusive", "nickname": f"{p['name']} {interval}",
                })
                log(f"  created {p['name']} {interval}: {price['id']}")
            out[f"STRIPE_PRICE_{key.upper()}_{interval.upper()}"] = price["id"]
    return out, products


def ensure_webhook() -> dict[str, str]:
    url = config.BASE_URL.rstrip("/") + "/stripe/webhook"
    existing = [w for w in billing._call("GET", "/webhook_endpoints?limit=100")["data"] if w["url"] == url]
    for w in existing:  # the signing secret is only shown at creation, so replace old endpoints
        billing._call("DELETE", f"/webhook_endpoints/{w['id']}")
        log(f"  replaced old webhook {w['id']}")
    hook = billing._call("POST", "/webhook_endpoints", {"url": url, "enabled_events": EVENTS,
                                                        "description": f"{config.APP_NAME} billing"})
    log(f"  webhook: {url}")
    return {"STRIPE_WEBHOOK_SECRET": hook["secret"]}


def ensure_portal(prices: dict[str, str], products: dict[str, str]) -> dict[str, str]:
    data = {
        "business_profile": {"headline": f"Manage your {config.APP_NAME} subscription"},
        "default_return_url": config.BASE_URL.rstrip("/") + "/account",
        "features": {
            "payment_method_update": {"enabled": True},
            "invoice_history": {"enabled": True},
            "customer_update": {"enabled": True, "allowed_updates": ["address", "tax_id", "email", "name"]},
            "subscription_cancel": {"enabled": True, "mode": "at_period_end"},
            "subscription_update": {
                "enabled": True, "default_allowed_updates": ["price"], "proration_behavior": "create_prorations",
                "products": [{"product": products[k], "prices": [prices[f"STRIPE_PRICE_{k.upper()}_MONTHLY"],
                                                                 prices[f"STRIPE_PRICE_{k.upper()}_YEARLY"]]}
                             for k in plans.ORDER],
            },
        },
    }
    conf = billing._call("POST", "/billing_portal/configurations", data)
    log(f"  customer portal: {conf['id']}")
    return {"STRIPE_PORTAL_CONFIG": conf["id"]}


def main() -> int:
    if not billing.enabled():
        log("STRIPE_SECRET_KEY is not set")
        return 1
    mode = "TEST" if config.STRIPE_SECRET_KEY.startswith(("sk_test", "rk_test")) else "LIVE"
    log(f"Setting up Stripe ({mode} mode) for {config.BASE_URL}")
    try:
        prices, products = ensure_prices()
        lines = {**prices, **ensure_webhook(), **ensure_portal(prices, products)}
    except billing.BillingError as exc:
        log(f"Stopped: {exc}")
        return 1
    for k, v in lines.items():
        print(f"{k}={v}")
    log("Done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
