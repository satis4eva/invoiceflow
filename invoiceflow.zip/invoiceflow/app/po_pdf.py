"""Purchase order PDF for sending to suppliers."""
import io
from datetime import date

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def _uk(d: str | None) -> str:
    try:
        return date.fromisoformat(d).strftime("%d/%m/%Y") if d else "-"
    except ValueError:
        return d


def build(po: dict, buyer_name: str, ack_link: str | None) -> bytes:
    buf = io.BytesIO()
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=18 * mm,
                            title=f"Purchase order {po['po_number']}")
    cur = {"GBP": "£", "EUR": "€", "USD": "$"}.get(po.get("currency") or "GBP", "")
    story = [Paragraph(f"<b>{buyer_name}</b>", styles["Title"]),
             Paragraph(f"<b>PURCHASE ORDER {po['po_number']}</b>", styles["Heading2"])]
    meta = [["To", po["supplier_name"]], ["Order date", _uk(po.get("order_date"))],
            ["Deliver by", _uk(po.get("delivery_date"))], ["Deliver to", po.get("delivery_address") or "-"],
            ["Reference", po.get("reference") or "-"]]
    t = Table(meta, colWidths=[35 * mm, 135 * mm])
    t.setStyle(TableStyle([("FONT", (0, 0), (0, -1), "Helvetica-Bold"), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [t, Spacer(1, 6 * mm)]
    rows = [["Line", "Code", "Description", "Qty", "Unit", "Unit price", "VAT %", "Net"]]
    for i, l in enumerate(po["lines"], 1):
        qty = l.get("qty") or 0
        price = l.get("unit_price") or 0
        rows.append([str(l.get("line", i)), l.get("code") or "", Paragraph(str(l.get("description") or ""), styles["BodyText"]),
                     f"{qty:g}", l.get("unit") or "", f"{cur}{price:,.2f}", f"{(l.get('vat_rate') or 0):g}%",
                     f"{cur}{qty * price:,.2f}"])
    lt = Table(rows, colWidths=[10 * mm, 22 * mm, 58 * mm, 13 * mm, 13 * mm, 21 * mm, 13 * mm, 22 * mm], repeatRows=1)
    lt.setStyle(TableStyle([("FONT", (0, 0), (-1, 0), "Helvetica-Bold"), ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.black),
                            ("GRID", (0, 0), (-1, -1), 0.25, colors.grey), ("ALIGN", (3, 1), (-1, -1), "RIGHT"),
                            ("VALIGN", (0, 0), (-1, -1), "TOP"), ("FONTSIZE", (0, 0), (-1, -1), 8.5)]))
    story += [lt, Spacer(1, 4 * mm)]
    tot = Table([["Net", f"{cur}{(po.get('net_total') or 0):,.2f}"], ["VAT", f"{cur}{(po.get('vat_total') or 0):,.2f}"],
                 ["Total", f"{cur}{(po.get('gross_total') or 0):,.2f}"]], colWidths=[30 * mm, 30 * mm], hAlign="RIGHT")
    tot.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "RIGHT"), ("FONT", (0, 2), (-1, 2), "Helvetica-Bold")]))
    story += [tot, Spacer(1, 8 * mm)]
    if po.get("notes"):
        story += [Paragraph(f"<b>Notes:</b> {po['notes']}", styles["BodyText"]), Spacer(1, 4 * mm)]
    story.append(Paragraph(f"Please quote <b>{po['po_number']}</b> on your delivery note and invoice. "
                           "Invoices without this order number may be delayed.", styles["BodyText"]))
    if ack_link:
        story.append(Paragraph(f"Confirm this order online: {ack_link}", styles["BodyText"]))
    doc.build(story)
    return buf.getvalue()
