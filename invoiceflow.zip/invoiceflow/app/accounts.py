"""Passwords, tokens, account status and package limits."""
import hashlib
import hmac
import re
import secrets
from datetime import datetime, timedelta, timezone

from . import db, plans

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
ROLES = {"owner": "Owner", "admin": "Admin", "reviewer": "Reviewer"}


# ---- passwords ----------------------------------------------------------------------

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return f"scrypt${salt.hex()}${digest.hex()}"


def check_password(password: str, stored: str | None) -> bool:
    if not stored or not stored.startswith("scrypt$"):
        return False
    _, salt_hex, digest_hex = stored.split("$")
    digest = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2 ** 14, r=8, p=1, dklen=32)
    return hmac.compare_digest(digest.hex(), digest_hex)


def password_problem(password: str) -> str | None:
    if len(password or "") < 10:
        return "Use at least 10 characters for the password."
    return None


def new_token(user_id: int, purpose: str, hours: int) -> str:
    token = secrets.token_urlsafe(32)
    expires = (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat(timespec="seconds")
    db.update_user(user_id, {"token": token, "token_purpose": purpose, "token_expires": expires})
    return token


def clear_token(user_id: int) -> None:
    db.update_user(user_id, {"token": None, "token_purpose": None, "token_expires": None})


# ---- simple login throttling (per email + IP, in memory) ----------------------------

_failures: dict[str, list[float]] = {}


def throttled(key: str) -> bool:
    import time
    recent = [t for t in _failures.get(key, []) if time.time() - t < 900]
    _failures[key] = recent
    return len(recent) >= 8


def record_failure(key: str) -> None:
    import time
    _failures.setdefault(key, []).append(time.time())


def clear_failures(key: str) -> None:
    _failures.pop(key, None)


# ---- account status and limits ------------------------------------------------------

def _today() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def days_left(iso: str | None) -> int | None:
    if not iso:
        return None
    end = datetime.fromisoformat(iso[:10]).date()
    return (end - datetime.now(timezone.utc).date()).days


def access(tenant: dict) -> dict:
    """Can this account use the app right now, and why (not)?"""
    status = tenant["status"]
    if tenant.get("comped_until") and tenant["comped_until"] >= _today():
        return {"ok": True, "state": "comped", "message": f"Free access until {tenant['comped_until']}"}
    if status == "active":
        return {"ok": True, "state": "active", "message": ""}
    if status == "past_due":
        return {"ok": True, "state": "past_due",
                "message": "Your last payment failed. Update your card to keep access."}
    if status == "trialing":
        left = days_left(tenant.get("trial_ends_at"))
        if left is not None and left >= 0:
            return {"ok": True, "state": "trialing",
                    "message": f"Free trial: {left} day{'s' if left != 1 else ''} left."}
        return {"ok": False, "state": "trial_ended",
                "message": "Your free trial has ended. Choose a package to carry on."}
    if status == "comped":
        return {"ok": False, "state": "comp_ended", "message": "Your free access has ended. Choose a package."}
    if status == "paused":
        return {"ok": False, "state": "paused", "message": "This account is paused. Contact support or update billing."}
    return {"ok": False, "state": "cancelled", "message": "This account's subscription has ended. Choose a package to restart."}


def usage_period_start(tenant: dict) -> str:
    if tenant["status"] == "active" and tenant.get("period_start"):
        return tenant["period_start"]
    if tenant["status"] == "trialing":
        return tenant["created_at"]
    d = datetime.now(timezone.utc).date().replace(day=1)
    return d.isoformat()


def usage(tenant: dict) -> dict:
    p = plans.get(tenant["plan"])
    used = db.count_invoices_since(tenant["id"], usage_period_start(tenant))
    return {"used": used, "limit": p["invoices"], "over": max(0, used - p["invoices"]),
            "percent": min(100, round(100 * used / p["invoices"])) if p["invoices"] else 0}


def upload_allowance(tenant: dict) -> tuple[int | None, str]:
    """How many more invoices may be uploaded now (None = no hard cap; extras are billed)."""
    a = access(tenant)
    if not a["ok"]:
        return 0, a["message"]
    u = usage(tenant)
    if a["state"] in ("trialing", "comped") or not tenant.get("stripe_subscription_id"):
        left = max(0, u["limit"] - u["used"])
        msg = "" if left else (f"You've used all {u['limit']} invoices in your package. "
                               "Upgrade or subscribe to read more.")
        return left, msg
    return None, ""


def can_add_user(tenant: dict) -> bool:
    limit = plans.get(tenant["plan"])["users"]
    return limit is None or len(db.list_users(tenant["id"])) < limit


def can_add_business(tenant: dict) -> bool:
    return len(db.list_businesses(tenant["id"])) < plans.get(tenant["plan"])["businesses"]


def has_feature(tenant: dict, feature: str) -> bool:
    return plans.has(tenant["plan"], feature)


# ---- creating accounts ----------------------------------------------------------------

def create_account(company: str, email: str, plan: str, password: str | None, owner_name: str = "",
                   verified: bool = False, status: str = "trialing", trial_days: int | None = None) -> tuple[int, int]:
    """Create account + first business + owner user. Returns (tenant_id, user_id)."""
    if plan not in plans.PLANS:
        plan = "basic"
    days = plans.TRIAL_DAYS if trial_days is None else trial_days
    trial_end = (datetime.now(timezone.utc) + timedelta(days=days)).date().isoformat()
    tenant_id = db.create_tenant(company.strip() or email, plan, status, trial_end)
    db.create_business(tenant_id, company.strip() or "My business")
    user_id = db.create_user(email, tenant_id, "owner", owner_name,
                             hash_password(password) if password else None, verified)
    return tenant_id, user_id
