"""Bank details checks and bulk payment files the customer uploads to their own bank."""
import csv
import io
import re
import uuid
from datetime import date, datetime, timezone
from xml.sax.saxutils import escape


def clean(s: str | None) -> str:
    return re.sub(r"[\s-]", "", s or "").upper()


def valid_sort_code(v: str | None) -> bool:
    return bool(re.fullmatch(r"\d{6}", clean(v)))


def valid_account(v: str | None) -> bool:
    return bool(re.fullmatch(r"\d{8}", clean(v)))


def valid_iban(v: str | None) -> bool:
    s = clean(v)
    if not re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]{10,30}", s):
        return False
    moved = s[4:] + s[:4]
    digits = "".join(str(int(ch, 36)) for ch in moved)
    return int(digits) % 97 == 1


def valid_bic(v: str | None) -> bool:
    return bool(re.fullmatch(r"[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?", clean(v)))


def check_details(d: dict) -> str | None:
    """Return a problem, or None if the bank details look complete and valid."""
    if not (d.get("account_name") or "").strip():
        return "Enter the name on the supplier's bank account."
    if d.get("iban"):
        if not valid_iban(d["iban"]):
            return "That IBAN fails its check digits."
        if d.get("bic") and not valid_bic(d["bic"]):
            return "That BIC / SWIFT code doesn't look right."
        return None
    if not valid_sort_code(d.get("sort_code")):
        return "UK sort codes have 6 digits."
    if not valid_account(d.get("account_number")):
        return "UK account numbers have 8 digits."
    return None


def masked(d: dict | None) -> str:
    if not d:
        return "-"
    if d.get("iban"):
        s = clean(d["iban"])
        return f"{d.get('account_name', '')}, IBAN {s[:4]}…{s[-4:]}"
    sc = clean(d.get("sort_code"))
    return f"{d.get('account_name', '')}, {sc[:2]}-{sc[2:4]}-{sc[4:]} ****{clean(d.get('account_number'))[-4:]}"


def _ref(s: str, n: int = 18) -> str:
    """Bank references: letters, digits, spaces, a few symbols; 18 characters for UK Faster Payments/BACS."""
    return re.sub(r"[^A-Za-z0-9 ./-]", "", s or "")[:n].strip()


def uk_csv(items: list[dict]) -> str:
    """Generic UK bulk payment CSV accepted by most UK business banking upload templates (map columns if asked)."""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Payee name", "Sort code", "Account number", "Amount", "Reference", "Payment date"])
    for it in items:
        b = it["bank"]
        w.writerow([_ref(b.get("account_name"), 35), clean(b.get("sort_code")), clean(b.get("account_number")),
                    f"{it['amount']:.2f}", _ref(it.get("reference") or ""), it.get("pay_date") or ""])
    return buf.getvalue()


def pain001(items: list[dict], debtor: dict, run_ref: str) -> bytes:
    """ISO 20022 pain.001.001.03 credit transfer initiation, grouped by payment date and currency."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
    msg_id = f"{_ref(run_ref, 20)}-{uuid.uuid4().hex[:8]}".replace(" ", "")
    groups: dict[tuple[str, str], list[dict]] = {}
    for it in items:
        groups.setdefault((it.get("pay_date") or date.today().isoformat(), it.get("currency") or "GBP"), []).append(it)
    total = sum(it["amount"] for it in items)
    dbtr_acct = (f"<IBAN>{escape(clean(debtor.get('iban')))}</IBAN>" if debtor.get("iban") else
                 f"<Othr><Id>{escape(clean(debtor.get('sort_code')) + clean(debtor.get('account_number')))}</Id>"
                 f"<SchmeNm><Prtry>SortCodeAccountNumber</Prtry></SchmeNm></Othr>")
    blocks = []
    for n, ((pay_date, cur), group) in enumerate(sorted(groups.items()), 1):
        txs = []
        for i, it in enumerate(group, 1):
            b = it["bank"]
            if b.get("iban"):
                cdtr_acct = f"<Id><IBAN>{escape(clean(b['iban']))}</IBAN></Id>"
                agt = f"<CdtrAgt><FinInstnId><BIC>{escape(clean(b['bic']))}</BIC></FinInstnId></CdtrAgt>" if b.get("bic") else ""
            else:
                cdtr_acct = (f"<Id><Othr><Id>{escape(clean(b.get('sort_code')) + clean(b.get('account_number')))}</Id>"
                             f"<SchmeNm><Prtry>SortCodeAccountNumber</Prtry></SchmeNm></Othr></Id>")
                agt = ""
            txs.append(f"""      <CdtTrfTxInf>
        <PmtId><EndToEndId>{escape(_ref(f"P{it['id']}", 35))}</EndToEndId></PmtId>
        <Amt><InstdAmt Ccy="{escape(cur)}">{it['amount']:.2f}</InstdAmt></Amt>
        {agt}
        <Cdtr><Nm>{escape(_ref(b.get('account_name'), 70))}</Nm></Cdtr>
        <CdtrAcct>{cdtr_acct}</CdtrAcct>
        <RmtInf><Ustrd>{escape(_ref(it.get('reference') or '', 140))}</Ustrd></RmtInf>
      </CdtTrfTxInf>""")
        blocks.append(f"""    <PmtInf>
      <PmtInfId>{escape(msg_id)}-{n}</PmtInfId>
      <PmtMtd>TRF</PmtMtd>
      <NbOfTxs>{len(group)}</NbOfTxs>
      <CtrlSum>{sum(i['amount'] for i in group):.2f}</CtrlSum>
      <ReqdExctnDt>{escape(pay_date)}</ReqdExctnDt>
      <Dbtr><Nm>{escape(_ref(debtor.get('account_name') or debtor.get('name') or 'Payer', 70))}</Nm></Dbtr>
      <DbtrAcct><Id>{dbtr_acct}</Id><Ccy>{escape(cur)}</Ccy></DbtrAcct>
      <DbtrAgt><FinInstnId>{f"<BIC>{escape(clean(debtor['bic']))}</BIC>" if debtor.get('bic') else "<Othr><Id>NOTPROVIDED</Id></Othr>"}</FinInstnId></DbtrAgt>
      <ChrgBr>SLEV</ChrgBr>
{chr(10).join(txs)}
    </PmtInf>""")
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03">
  <CstmrCdtTrfInitn>
    <GrpHdr>
      <MsgId>{escape(msg_id)}</MsgId>
      <CreDtTm>{now}</CreDtTm>
      <NbOfTxs>{len(items)}</NbOfTxs>
      <CtrlSum>{total:.2f}</CtrlSum>
      <InitgPty><Nm>{escape(_ref(debtor.get('name') or 'Payer', 70))}</Nm></InitgPty>
    </GrpHdr>
{chr(10).join(blocks)}
  </CstmrCdtTrfInitn>
</Document>
"""
    return xml.encode()
