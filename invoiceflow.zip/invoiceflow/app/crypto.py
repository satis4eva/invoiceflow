"""Encrypt secrets (mailbox passwords, OAuth tokens) at rest with a key derived from SECRET_KEY.
If SECRET_KEY changes, stored mailboxes must be reconnected."""
import base64
import hashlib
import json

from cryptography.fernet import Fernet, InvalidToken

from . import config


def _fernet() -> Fernet:
    key = base64.urlsafe_b64encode(hashlib.sha256(("mailbox:" + config.SECRET_KEY).encode()).digest())
    return Fernet(key)


def seal(data: dict) -> str:
    return _fernet().encrypt(json.dumps(data).encode()).decode()


def unseal(token: str | None) -> dict:
    if not token:
        return {}
    try:
        return json.loads(_fernet().decrypt(token.encode()))
    except (InvalidToken, ValueError):
        return {}
