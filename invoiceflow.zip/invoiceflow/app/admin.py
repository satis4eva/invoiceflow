"""Master control panel (superadmins only): every account, plans, access, users, revenue."""
import secrets
from datetime import datetime, timedelta, timezone

from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Route

from . import accounts, billing, db, mailer, plans
from .web import Ctx, back, flash, form_checked, guarded, render


def _metrics() -> dict:
    tenants = db.list_tenants()
    by_status: dict[str, int] = {}
    mrr = 0.0
    soon = []
    today = datetime.now(timezone.utc).date()
    for t in tenants:
        state = accounts.access(t)["state"]
        by_status[state] = by_status.get(state, 0) + 1
        if t["status"] in ("active", "past_due") and t.get("stripe_subscription_id"):
            mrr += plans.monthly_value(t["plan"], t["billing_interval"])
        left = accounts.days_left(t.get("trial_ends_at"))
        if t["status"] == "trialing" and left is not None and 0 <= left <= 3:
            soon.append(t)
    month_start = today.replace(day=1).isoformat()
    since30 = (today - timedelta(days=30)).isoformat()
    return {
        "accounts": len(tenants),
        "by_status": by_status,
        "mrr": mrr,
        "trials_ending": soon,
        "invoices_month": db.q1("SELECT COUNT(*) c FROM invoices WHERE created_at >= ?", (month_start,))["c"],
        "signups_30": db.q1("SELECT COUNT(*) c FROM tenants WHERE created_at >= ?", (since30,))["c"],
        "by_plan": {k: sum(1 for t in tenants if t["plan"] == k and accounts.access(t)["ok"]) for k in plans.ORDER},
    }


@guarded("super")
async def dashboard(request: Request, c: Ctx):
    return render(request, "admin/dashboard.html", c, m=_metrics(), log=db.get_admin_log(None, 25),
                  mail_enabled=mailer.enabled())


@guarded("super")
async def account_list(request: Request, c: Ctx):
    search = request.query_params.get("q", "").strip()
    status = request.query_params.get("status", "")
    rows = db.list_tenants(search, status)
    for t in rows:
        t["access"] = accounts.access(t)
        t["usage"] = accounts.usage(t)
    return render(request, "admin/accounts.html", c, rows=rows, search=search, status=status)


@guarded("super")
async def account_new(request: Request, c: Ctx):
    if request.method == "GET":
        return render(request, "admin/new_account.html", c, values={"plan": "standard", "access": "trial"}, error=None)
    form = await form_checked(request)
    values = {k: str(form.get(k, "")).strip() for k in ("company", "name", "email", "plan", "access", "days")}
    plan = values["plan"] if values["plan"] in plans.PLANS else "standard"
    error = None
    if not values["company"]:
        error = "Enter the company name."
    elif not accounts.EMAIL_RE.match(values["email"]):
        error = "Enter a valid email address for the owner."
    elif db.user_by_email(values["email"]):
        error = "That email already has an account."
    if error:
        return render(request, "admin/new_account.html", c, values=values, error=error)

    days = int(values["days"] or plans.TRIAL_DAYS) if values["days"].isdigit() else plans.TRIAL_DAYS
    tenant_id, user_id = accounts.create_account(values["company"], values["email"], plan, None, values["name"],
                                                 verified=True, trial_days=days)
    if values["access"] == "free":
        until = (datetime.now(timezone.utc) + timedelta(days=days)).date().isoformat()
        db.update_tenant(tenant_id, {"status": "comped", "comped_until": until})
    token = accounts.new_token(user_id, "invite", 24 * 7)
    sent = mailer.invite(values["email"], token, values["company"], "The team")
    db.admin_log(tenant_id, "created_by_admin", f"{plans.get(plan)['name']}, {values['access']} {days} days", c.who)
    link = mailer.link("/invite/" + token)
    flash(request, f"Account created. {'Invitation emailed to the owner.' if sent else 'Send the owner this link to set their password: ' + link}",
          "ok" if sent else "warn")
    return back(f"/admin/accounts/{tenant_id}")


@guarded("super")
async def account_detail(request: Request, c: Ctx):
    t = db.get_tenant(int(request.path_params["id"]))
    if not t:
        return Response("Account not found", status_code=404)
    return render(request, "admin/account.html", c, t=t, access=accounts.access(t), usage=accounts.usage(t),
                  users=db.list_users(t["id"]), biz=db.list_businesses(t["id"]), log=db.get_admin_log(t["id"], 40),
                  invoice_total=db.q1("SELECT COUNT(*) c FROM invoices WHERE tenant_id = ?", (t["id"],))["c"])


@guarded("super")
async def account_update(request: Request, c: Ctx):
    t = db.get_tenant(int(request.path_params["id"]))
    if not t:
        return Response(status_code=404)
    form = await form_checked(request)
    action = form.get("action")
    changes, note = {}, ""
    if action == "details":
        changes = {"name": str(form.get("name", t["name"])).strip()[:120] or t["name"],
                   "notes": str(form.get("notes", ""))[:4000]}
        plan = str(form.get("plan", t["plan"]))
        if plan in plans.PLANS and plan != t["plan"]:
            changes["plan"] = plan
            note = f"plan {t['plan']} to {plan}"
            if t.get("stripe_subscription_id"):
                flash(request, "This account pays through Stripe - also change the plan in Stripe, "
                               "or the next renewal will switch it back.", "warn")
        interval = str(form.get("interval", t["billing_interval"]))
        if interval in ("monthly", "yearly"):
            changes["billing_interval"] = interval
    elif action == "extend_trial":
        days = max(1, min(365, int(form.get("days") or 14)))
        base = max(t.get("trial_ends_at") or "", datetime.now(timezone.utc).date().isoformat())
        new_end = (datetime.fromisoformat(base[:10]) + timedelta(days=days)).date().isoformat()
        changes = {"trial_ends_at": new_end, "status": "trialing" if not t.get("stripe_subscription_id") else t["status"]}
        note = f"trial extended {days} days to {new_end}"
    elif action == "comp":
        months = max(1, min(36, int(form.get("months") or 1)))
        start = max(t.get("comped_until") or "", datetime.now(timezone.utc).date().isoformat())
        until = (datetime.fromisoformat(start[:10]) + timedelta(days=30 * months)).date().isoformat()
        changes = {"comped_until": until}
        if t["status"] not in ("active", "past_due"):
            changes["status"] = "comped"
        note = f"{months} free month(s) until {until}"
    elif action == "end_comp":
        changes = {"comped_until": None}
        if t["status"] == "comped":
            changes["status"] = "paused"
        note = "free access ended"
    elif action == "pause":
        changes, note = {"status": "paused"}, "paused"
        if t.get("stripe_subscription_id"):
            flash(request, "Paused here. Billing continues in Stripe until you pause or cancel it there.", "warn")
    elif action == "activate":
        changes = {"status": "active" if t.get("stripe_subscription_id") else "comped"}
        if changes["status"] == "comped" and not t.get("comped_until"):
            changes["comped_until"] = (datetime.now(timezone.utc) + timedelta(days=30)).date().isoformat()
        note = "re-activated"
    elif action == "close":
        changes, note = {"status": "cancelled"}, "closed"
        for u in db.list_users(t["id"]):
            db.update_user(u["id"], {"active": 0})
    elif action == "reopen":
        changes, note = {"status": "paused"}, "reopened (paused until billing or free access)"
        for u in db.list_users(t["id"]):
            db.update_user(u["id"], {"active": 1})
    if changes:
        db.update_tenant(t["id"], changes)
        db.admin_log(t["id"], action or "update", note, c.who)
        flash(request, "Saved." if not note else f"Done: {note}.")
    return back(f"/admin/accounts/{t['id']}")


@guarded("super")
async def view_as(request: Request, c: Ctx):
    t = db.get_tenant(int(request.path_params["id"]))
    if not t:
        return Response(status_code=404)
    await form_checked(request)
    request.session["view_tenant"] = t["id"]
    request.session.pop("bid", None)
    db.admin_log(t["id"], "viewed_as", "support view started", c.who)
    flash(request, f"You're viewing {t['name']} as its owner. Changes you make are real.", "warn")
    return back("/app" if accounts.access(t)["ok"] else "/account")


@guarded("login")
async def exit_view(request: Request, c: Ctx):
    await form_checked(request)
    tid = request.session.pop("view_tenant", None)
    request.session.pop("bid", None)
    return back(f"/admin/accounts/{tid}" if tid and c.is_super else "/")


@guarded("super")
async def user_action(request: Request, c: Ctx):
    u = db.get_user(int(request.path_params["id"]))
    if not u or u["role"] == "superadmin":
        return Response(status_code=404)
    form = await form_checked(request)
    action = form.get("action")
    if action == "reset":
        temp = secrets.token_urlsafe(9)
        db.update_user(u["id"], {"password_hash": accounts.hash_password(temp), "active": 1})
        db.admin_log(u["tenant_id"], "password_reset", u["email"], c.who)
        flash(request, f"Temporary password for {u['email']}: {temp}  (shown once - ask them to change it after signing in)", "warn")
    elif action == "send_reset":
        sent = mailer.reset_password(u["email"], accounts.new_token(u["id"], "reset", 2))
        flash(request, "Reset email sent." if sent else "Email isn't set up - use 'Set temporary password' instead.",
              "ok" if sent else "warn")
    elif action == "disable":
        db.update_user(u["id"], {"active": 0})
        db.admin_log(u["tenant_id"], "user_disabled", u["email"], c.who)
        flash(request, f"{u['email']} can no longer sign in.")
    elif action == "enable":
        db.update_user(u["id"], {"active": 1})
        flash(request, f"{u['email']} can sign in again.")
    elif action == "make_owner":
        for other in db.list_users(u["tenant_id"]):
            if other["role"] == "owner":
                db.update_user(other["id"], {"role": "admin"})
        db.update_user(u["id"], {"role": "owner"})
        db.admin_log(u["tenant_id"], "owner_changed", u["email"], c.who)
        flash(request, f"{u['email']} is now the owner.")
    return back(f"/admin/accounts/{u['tenant_id']}")


@guarded("super")
async def admin_profile(request: Request, c: Ctx):
    admins = db.q("SELECT id, email, name, last_login FROM users WHERE role = 'superadmin' ORDER BY id")
    return render(request, "admin/profile.html", c, admins=admins)


@guarded("super")
async def add_admin(request: Request, c: Ctx):
    form = await form_checked(request)
    email = str(form.get("email", "")).strip().lower()
    pw = str(form.get("password", ""))
    if not accounts.EMAIL_RE.match(email):
        flash(request, "Enter a valid email.", "error")
    elif db.user_by_email(email):
        flash(request, "That email already has an account.", "error")
    elif accounts.password_problem(pw):
        flash(request, accounts.password_problem(pw), "error")
    else:
        db.create_user(email, None, "superadmin", "", accounts.hash_password(pw), verified=True)
        db.admin_log(None, "admin_added", email, c.who)
        flash(request, f"{email} can now open master control.")
    return back("/admin/profile")


routes = [
    Route("/admin", dashboard),
    Route("/admin/accounts", account_list),
    Route("/admin/accounts/new", account_new, methods=["GET", "POST"]),
    Route("/admin/accounts/{id:int}", account_detail),
    Route("/admin/accounts/{id:int}/update", account_update, methods=["POST"]),
    Route("/admin/accounts/{id:int}/view-as", view_as, methods=["POST"]),
    Route("/admin/exit-view", exit_view, methods=["POST"]),
    Route("/admin/users/{id:int}", user_action, methods=["POST"]),
    Route("/admin/profile", admin_profile),
    Route("/admin/admins", add_admin, methods=["POST"]),
]
