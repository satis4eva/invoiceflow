"""CSV exports in the import formats of Xero, QuickBooks Online and Sage 50 (UK)."""
import csv
import io
import os
import re
from datetime import date

from . import config

SAGE_DEFAULT_NOMINAL = os.getenv("SAGE_DEFAULT_NOMINAL", "5000")
QBO_DEFAULT_ACCOUNT = os.getenv("QBO_DEFAULT_ACCOUNT", "Purchases")


def _uk(d: str | None) -> str:
    return date.fromisoformat(d).strftime("%d/%m/%Y") if d else ""


def _sign(inv: dict) -> int:
    return -1 if inv.get("document_type") == "credit_note" else 1


def _rate(li: dict) -> float:
    r = li.get("vat_rate")
    return float(r) if r is not None else 0.0


def xero_tax_type(rate: float, inv: dict) -> str:
    if not inv.get("vat_total") and not rate:
        return "No VAT"
    return {20.0: "20% (VAT on Expenses)", 5.0: "5% (VAT on Expenses)", 0.0: "Zero Rated Expenses"}.get(rate, "20% (VAT on Expenses)")


def sage_tax_code(rate: float, inv: dict) -> str:
    if not inv.get("vat_total") and not rate:
        return "T9"
    return {20.0: "T1", 5.0: "T5", 0.0: "T0"}.get(rate, "T1")


def qbo_tax_code(rate: float, inv: dict) -> str:
    if not inv.get("vat_total") and not rate:
        return "No VAT"
    return {20.0: "20.0% S", 5.0: "5.0% R", 0.0: "0.0% Z"}.get(rate, "20.0% S")


def sage_account_ref(name: str) -> str:
    return (re.sub(r"[^A-Za-z0-9]", "", name or "").upper() or "SUPPLIER")[:8]


def _write(header: list[str], rows: list[list]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(header)
    w.writerows(rows)
    return buf.getvalue()


def xero_csv(invoices: list[dict]) -> str:
    header = ["*ContactName", "EmailAddress", "POAddressLine1", "POAddressLine2", "POAddressLine3", "POAddressLine4",
              "POCity", "PORegion", "POPostalCode", "POCountry", "*InvoiceNumber", "*InvoiceDate", "*DueDate",
              "Total", "InventoryItemCode", "Description", "*Quantity", "*UnitAmount", "*AccountCode", "*TaxType",
              "TaxAmount", "TrackingName1", "TrackingOption1", "TrackingName2", "TrackingOption2", "Currency"]
    rows = []
    for inv in invoices:
        s = _sign(inv)
        for li in inv["line_items"]:
            qty = li.get("quantity") or 1
            unit = li.get("unit_price") if li.get("unit_price") is not None else (li.get("net_amount") or 0) / qty
            rows.append([
                inv["supplier_name"], inv.get("supplier_email") or "", inv.get("supplier_address") or "",
                "", "", "", "", "", "", "",
                inv["invoice_number"], _uk(inv["invoice_date"]), _uk(inv["due_date"]),
                "", "", li["description"], qty, round(s * unit, 4),
                li.get("account_code") or config.DEFAULT_EXPENSE_ACCOUNT,
                xero_tax_type(_rate(li), inv),
                "" if li.get("vat_amount") is None else round(s * li["vat_amount"], 2),
                "", "", "", "", inv.get("currency") or config.DEFAULT_CURRENCY,
            ])
    return _write(header, rows)


def quickbooks_csv(invoices: list[dict]) -> str:
    header = ["Bill No", "Supplier", "Bill Date", "Due Date", "Memo", "Expense Account",
              "Expense Description", "Expense Line Amount", "Expense Tax Code", "Expense Tax Amount", "Currency"]
    rows = []
    for inv in invoices:
        s = _sign(inv)
        memo = f"PO {inv['po_number']}" if inv.get("po_number") else ""
        if s < 0:
            memo = ("Supplier credit. " + memo).strip()
        for li in inv["line_items"]:
            rows.append([
                inv["invoice_number"], inv["supplier_name"], _uk(inv["invoice_date"]), _uk(inv["due_date"]),
                memo, li.get("account_code") or QBO_DEFAULT_ACCOUNT, li["description"],
                round(s * (li.get("net_amount") or 0), 2), qbo_tax_code(_rate(li), inv),
                round(s * (li.get("vat_amount") or 0), 2), inv.get("currency") or config.DEFAULT_CURRENCY,
            ])
    return _write(header, rows)


def sage50_csv(invoices: list[dict]) -> str:
    """Sage 50 Accounts 'Audit Trail Transactions' import (PI = purchase invoice, PC = purchase credit)."""
    header = ["Type", "Account Reference", "Nominal A/C Ref", "Department Code", "Date", "Reference",
              "Details", "Net Amount", "Tax Code", "Tax Amount", "Exchange Rate", "Extra Reference"]
    rows = []
    for inv in invoices:
        t = "PC" if inv.get("document_type") == "credit_note" else "PI"
        for li in inv["line_items"]:
            li_code = li.get("account_code")
            nominal = li_code if li_code and li_code.isdigit() and len(li_code) == 4 else SAGE_DEFAULT_NOMINAL
            rows.append([
                t, sage_account_ref(inv["supplier_name"]), nominal, "", _uk(inv["invoice_date"]),
                (inv["invoice_number"] or "")[:30], li["description"][:60],
                f"{li.get('net_amount') or 0:.2f}", sage_tax_code(_rate(li), inv),
                f"{li.get('vat_amount') or 0:.2f}", "", (inv.get("po_number") or "")[:30],
            ])
    return _write(header, rows)


def summary_csv(invoices: list[dict]) -> str:
    header = ["ID", "Status", "Type", "Supplier", "VAT No", "Invoice No", "Invoice Date", "Due Date",
              "PO", "Currency", "Net", "VAT", "Gross", "Posted To", "External ID"]
    rows = [[i["id"], i["status"], i.get("document_type"), i.get("supplier_name"), i.get("supplier_vat_number"),
             i.get("invoice_number"), i.get("invoice_date"), i.get("due_date"), i.get("po_number"), i.get("currency"),
             i.get("net_total"), i.get("vat_total"), i.get("gross_total"), i.get("posted_to"), i.get("external_id")]
            for i in invoices]
    return _write(header, rows)


EXPORTERS = {
    "xero": ("Xero bills import", xero_csv),
    "quickbooks": ("QuickBooks Online bills import", quickbooks_csv),
    "sage50": ("Sage 50 audit trail import", sage50_csv),
    "summary": ("Summary register", summary_csv),
}
