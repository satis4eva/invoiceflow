"""Email pages: connect work mailboxes, send from a business, see what was sent."""
from starlette.requests import Request
from starlette.responses import RedirectResponse, Response
from starlette.routing import Route

from . import db, mailboxes
from .mailboxes import MailError
from .web import Ctx, back, flash, form_checked, guarded, render


def _gate(request: Request, c: Ctx):
    if not c.can("email"):
        return render(request, "upgrade.html", c, feature="Email from each business",
                      blurb="Connect your work mailbox and email clients from inside each business, with every message "
                            "kept on that client's record.")
    return None


def _recipients(business_id: int) -> list[str]:
    seen, out = set(), []
    for r in db.q("SELECT to_addrs FROM emails WHERE business_id = ? ORDER BY id DESC LIMIT 200", (business_id,)):
        for a in (r["to_addrs"] or "").split(","):
            a = a.strip()
            if a and a not in seen:
                seen.add(a)
                out.append(a)
    for r in db.q("""SELECT DISTINCT s.email FROM sign_signers s JOIN sign_requests q ON q.id = s.request_id
                     WHERE q.business_id = ? AND s.email IS NOT NULL""", (business_id,)):
        if r["email"] not in seen:
            seen.add(r["email"])
            out.append(r["email"])
    return out[:50]


@guarded("app")
async def email_page(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    boxes = mailboxes.usable(c.tenant["id"], c.user, c.impersonating)
    default = mailboxes.default_for(c.business, c.tenant["id"], c.user, c.impersonating)
    history = db.q("SELECT * FROM emails WHERE business_id = ? ORDER BY id DESC LIMIT 100", (c.business["id"],))
    return render(request, "email.html", c, boxes=boxes, default=default, history=history,
                  recipients=_recipients(c.business["id"]), to=request.query_params.get("to", ""))


@guarded("app")
async def email_send(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    form = await form_checked(request)
    box = mailboxes.get(int(form.get("mailbox_id") or 0), c.tenant["id"])
    if not box or box not in mailboxes.usable(c.tenant["id"], c.user, c.impersonating):
        flash(request, "Choose a mailbox to send from. You can connect one first.", "error")
        return back("/email")
    try:
        to = mailboxes.parse_addresses(str(form.get("to", "")))
        cc = mailboxes.parse_addresses(str(form.get("cc", "")))
    except MailError as exc:
        flash(request, str(exc), "error")
        return back("/email")
    subject, body = str(form.get("subject", "")).strip(), str(form.get("body", "")).strip()
    if not to or not subject or not body:
        flash(request, "Add who it's to, a subject and a message.", "error")
        return back("/email")
    if len(to) + len(cc) > 50:
        flash(request, "Send to 50 people or fewer at a time.", "error")
        return back("/email")
    attachments = []
    for f in form.getlist("files"):
        if getattr(f, "filename", ""):
            attachments.append((f.filename, await f.read(), f.content_type or "application/octet-stream"))
    ok, msg = mailboxes.send_and_log(c.tenant["id"], c.business["id"], box, c.who, to, subject, body, cc, attachments)
    flash(request, f"Sent to {', '.join(to)}." if ok else f"Not sent: {msg}", "ok" if ok else "error")
    return back("/email")


@guarded("app")
async def set_default(request: Request, c: Ctx):
    form = await form_checked(request)
    box = mailboxes.get(int(form.get("mailbox_id") or 0), c.tenant["id"])
    db.ex("UPDATE businesses SET mailbox_id = ? WHERE id = ?", (box["id"] if box else None, c.business["id"]))
    flash(request, f"Emails for {c.business['name']} will be sent from {box['from_email']}." if box else "Default cleared.")
    return back("/email")


@guarded("app")
async def mailbox_page(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    boxes = db.q("SELECT * FROM mailboxes WHERE tenant_id = ? ORDER BY from_email", (c.tenant["id"],))
    owners = {u["id"]: u["email"] for u in db.list_users(c.tenant["id"])}
    return render(request, "mailboxes.html", c, boxes=boxes, owners=owners, presets=mailboxes.PRESETS,
                  google=mailboxes.oauth_enabled("google"), microsoft=mailboxes.oauth_enabled("microsoft"),
                  values={"preset": "hostinger", "shared": "1"}, error=None)


@guarded("app")
async def mailbox_add(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    form = await form_checked(request)
    v = {k: str(form.get(k, "")).strip() for k in ("preset", "from_name", "from_email", "smtp_host", "smtp_port",
                                                     "security", "username", "imap_host", "shared")}
    password = str(form.get("password", ""))
    preset = mailboxes.PRESETS.get(v["preset"], mailboxes.PRESETS["other"])
    settings = {
        "smtp_host": v["smtp_host"] or preset["smtp_host"],
        "smtp_port": int(v["smtp_port"] or preset["smtp_port"]) if (v["smtp_port"] or str(preset["smtp_port"])).isdigit() else 587,
        "security": v["security"] if v["security"] in ("ssl", "starttls", "none") else preset["security"],
        "username": v["username"] or v["from_email"],
        "password": password,
        "imap_host": v["imap_host"] if v["imap_host"] or v["preset"] == "other" else preset["imap_host"],
    }
    error = None
    if not mailboxes.EMAIL_RE.match(v["from_email"]):
        error = "Enter the email address you send from."
    elif not password:
        error = "Enter the mailbox password (or app password)."
    else:
        try:
            mailboxes.test_settings(settings)
        except MailError as exc:
            error = str(exc)
    if error:
        boxes = db.q("SELECT * FROM mailboxes WHERE tenant_id = ? ORDER BY from_email", (c.tenant["id"],))
        owners = {u["id"]: u["email"] for u in db.list_users(c.tenant["id"])}
        v.pop("password", None)
        return render(request, "mailboxes.html", c, boxes=boxes, owners=owners, presets=mailboxes.PRESETS,
                      google=mailboxes.oauth_enabled("google"), microsoft=mailboxes.oauth_enabled("microsoft"),
                      values=v, error=error)
    shared = v["shared"] == "1" and c.is_manager()
    mailboxes.create(c.tenant["id"], None if c.impersonating else c.user["id"], "smtp", v["from_email"],
                     v["from_name"], settings, shared)
    db.admin_log(c.tenant["id"], "mailbox_connected", v["from_email"], c.who)
    flash(request, f"Connected {v['from_email']}. It signed in successfully.")
    return back("/email/mailboxes")


@guarded("app")
async def mailbox_action(request: Request, c: Ctx):
    form = await form_checked(request)
    box = mailboxes.get(int(request.path_params["id"]), c.tenant["id"])
    if not box:
        return Response(status_code=404)
    mine = c.user and box["user_id"] == c.user["id"]
    if not (mine or c.is_manager()):
        flash(request, "Only the person who connected this mailbox, or an admin, can change it.", "error")
        return back("/email/mailboxes")
    action = form.get("action")
    if action == "remove":
        mailboxes.remove(box["id"], c.tenant["id"])
        db.admin_log(c.tenant["id"], "mailbox_removed", box["from_email"], c.who)
        flash(request, f"Disconnected {box['from_email']}.")
    elif action in ("share", "private") and c.is_manager():
        db.ex("UPDATE mailboxes SET shared = ? WHERE id = ?", (int(action == "share"), box["id"]))
        flash(request, "Shared with the team." if action == "share" else "Now only its owner can send from it.")
    elif action == "test":
        ok, msg = mailboxes.send_and_log(c.tenant["id"], None, box, c.who, [box["from_email"]],
                                         "Test email", "This test confirms your mailbox is connected.")
        flash(request, f"Test email sent to {box['from_email']}." if ok else f"Test failed: {msg}", "ok" if ok else "error")
    return back("/email/mailboxes")


@guarded("app")
async def oauth_start(request: Request, c: Ctx):
    kind = request.path_params["kind"]
    if kind not in mailboxes.OAUTH or not mailboxes.oauth_enabled(kind) or not c.can("email"):
        flash(request, "That sign-in option isn't switched on yet.", "warn")
        return back("/email/mailboxes")
    url, state = mailboxes.oauth_start(kind)
    request.session["mail_oauth"] = {"state": state, "kind": kind}
    return RedirectResponse(url)


@guarded("app")
async def oauth_callback(request: Request, c: Ctx):
    kind = request.path_params["kind"]
    saved = request.session.pop("mail_oauth", {}) or {}
    q = request.query_params
    if q.get("error"):
        flash(request, f"Sign-in was cancelled: {q.get('error_description') or q['error']}", "warn")
        return back("/email/mailboxes")
    if kind not in mailboxes.OAUTH or saved.get("kind") != kind or saved.get("state") != q.get("state"):
        flash(request, "That sign-in expired. Please try again.", "error")
        return back("/email/mailboxes")
    try:
        email, name, settings = mailboxes.oauth_finish(kind, q.get("code", ""))
    except MailError as exc:
        flash(request, str(exc), "error")
        return back("/email/mailboxes")
    existing = db.q1("SELECT id FROM mailboxes WHERE tenant_id = ? AND from_email = ? AND kind = ?",
                     (c.tenant["id"], email.lower(), kind))
    if existing:
        from . import crypto
        db.ex("UPDATE mailboxes SET config_enc = ?, last_error = NULL WHERE id = ?", (crypto.seal(settings), existing["id"]))
    else:
        mailboxes.create(c.tenant["id"], None if c.impersonating else c.user["id"], kind, email, name, settings,
                         shared=c.is_manager())
    db.admin_log(c.tenant["id"], "mailbox_connected", f"{email} via {kind}", c.who)
    flash(request, f"Connected {email}.")
    return back("/email/mailboxes")


routes = [
    Route("/email", email_page),
    Route("/email/send", email_send, methods=["POST"]),
    Route("/email/default", set_default, methods=["POST"]),
    Route("/email/mailboxes", mailbox_page),
    Route("/email/mailboxes", mailbox_add, methods=["POST"]),
    Route("/email/mailboxes/{id:int}", mailbox_action, methods=["POST"]),
    Route("/mail/oauth/{kind}/start", oauth_start),
    Route("/mail/oauth/{kind}/callback", oauth_callback),
]
