"""The four packages: prices, limits and which features each one unlocks.

Stripe price IDs come from the environment (create the products in Stripe,
then paste each price ID into .env). Prices here are what the pricing page shows.
"""
import os

# Feature keys used by the app to switch things on per package
FEATURES = {
    "phone_capture": "Phone photo link for clients and staff",
    "ai_reading": "AI reading with line items",
    "vat_checks": "UK VAT checks and duplicate detection",
    "csv_export": "Xero, QuickBooks and Sage CSV export",
    "direct_posting": "Direct posting to Xero",
    "approvals": "Approval before posting",
    "supplier_memory": "Supplier coding memory",
    "api": "API access",
    "multi_business": "Several businesses in one account",
    "priority_support": "Priority support",
}

PLANS = {
    "basic": {
        "name": "Basic",
        "monthly": 19, "yearly": 190,
        "for": "Sole traders and micro businesses",
        "businesses": 1, "invoices": 150, "users": 2, "overage_pence": 15,
        "features": ["phone_capture", "ai_reading", "vat_checks", "csv_export"],
        "support": "Email support",
    },
    "standard": {
        "name": "Standard",
        "monthly": 49, "yearly": 490,
        "for": "Small businesses",
        "businesses": 1, "invoices": 600, "users": 5, "overage_pence": 12,
        "features": ["phone_capture", "ai_reading", "vat_checks", "csv_export", "direct_posting", "approvals", "supplier_memory"],
        "support": "Email support",
    },
    "advanced": {
        "name": "Advanced",
        "monthly": 129, "yearly": 1290,
        "for": "Growing businesses and groups",
        "businesses": 10, "invoices": 2000, "users": None, "overage_pence": 10,
        "features": ["phone_capture", "ai_reading", "vat_checks", "csv_export", "direct_posting", "approvals", "supplier_memory",
                     "api", "multi_business", "priority_support"],
        "support": "Priority email support",
    },
    "practice": {
        "name": "Practice",
        "monthly": 299, "yearly": 2990,
        "for": "Accounting firms",
        "businesses": 50, "invoices": 6000, "users": None, "overage_pence": 8,
        "features": ["phone_capture", "ai_reading", "vat_checks", "csv_export", "direct_posting", "approvals", "supplier_memory",
                     "api", "multi_business", "priority_support"],
        "support": "Named contact and onboarding call",
    },
}

ORDER = ["basic", "standard", "advanced", "practice"]

# Shown on the pricing page as coming soon, so nothing is promised that isn't built
COMING_SOON = {
    "basic": ["Email-in address for forwarding invoices"],
    "standard": ["Direct posting to QuickBooks"],
    "advanced": ["Multi-step approvals with spending limits", "PO matching", "Bank and supplier statement reading"],
    "practice": ["Client logins and messaging", "Your own branding and domain"],
}

TRIAL_DAYS = int(os.getenv("TRIAL_DAYS", "14"))


def get(plan_key: str) -> dict:
    return PLANS.get(plan_key) or PLANS["basic"]


def has(plan_key: str, feature: str) -> bool:
    return feature in get(plan_key)["features"]


def stripe_price_id(plan_key: str, interval: str) -> str:
    """e.g. STRIPE_PRICE_STANDARD_MONTHLY"""
    return os.getenv(f"STRIPE_PRICE_{plan_key.upper()}_{interval.upper()}", "")


def plan_for_price(price_id: str) -> tuple[str, str] | None:
    for key in ORDER:
        for interval in ("monthly", "yearly"):
            if price_id and stripe_price_id(key, interval) == price_id:
                return key, interval
    return None


def monthly_value(plan_key: str, interval: str) -> float:
    p = get(plan_key)
    return p["yearly"] / 12 if interval == "yearly" else p["monthly"]
