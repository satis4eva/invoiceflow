"""Peppol network connection through an accredited access point provider.

The app can't join Peppol directly - that needs an accredited access point (for example Storecove,
Tickstar, Pagero or a UK provider). Connect one by setting PEPPOL_API_URL, PEPPOL_API_KEY and
PEPPOL_WEBHOOK_SECRET. Inbound documents arrive at /peppol/inbound as JSON:
    {"recipient": "0088:5012345678900", "document": "<base64 UBL XML>"}
with the header X-Peppol-Secret: <PEPPOL_WEBHOOK_SECRET>.
Outbound documents are POSTed to PEPPOL_API_URL as JSON with a bearer key:
    {"sender": "...", "recipient": "...", "document_type": "order" | "invoice", "document": "<base64 XML>"}
Adjust _send() to your provider's exact API when you sign up."""
import base64
import json
import os
import re
import urllib.error
import urllib.request

PEPPOL_ID = re.compile(r"^\d{4}:[A-Za-z0-9.\-_]{1,50}$")


def configured() -> bool:
    return bool(os.getenv("PEPPOL_API_URL") and os.getenv("PEPPOL_API_KEY"))


def webhook_secret() -> str:
    return os.getenv("PEPPOL_WEBHOOK_SECRET", "")


def valid_id(pid: str | None) -> bool:
    return bool(pid and PEPPOL_ID.match(pid.strip()))


def send(sender: str, recipient: str, document_type: str, xml: bytes) -> tuple[bool, str]:
    if not configured():
        return False, "Peppol isn't connected yet"
    body = json.dumps({"sender": sender, "recipient": recipient, "document_type": document_type,
                       "document": base64.b64encode(xml).decode()}).encode()
    req = urllib.request.Request(os.getenv("PEPPOL_API_URL"), data=body, method="POST", headers={
        "Authorization": f"Bearer {os.getenv('PEPPOL_API_KEY')}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return 200 <= resp.status < 300, "Sent over Peppol"
    except urllib.error.HTTPError as exc:
        return False, f"Peppol provider said {exc.code}"
    except OSError as exc:
        return False, f"Couldn't reach the Peppol provider: {exc}"
