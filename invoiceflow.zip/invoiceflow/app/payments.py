"""Supplier payments: bulk payment runs, due-date scheduling, four-eyes approval with segregation of duties,
second-person verification of supplier bank details, payment rails, remittance advice and reconciliation."""
import json
import logging
import os
import secrets
import threading
import time
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone

from starlette.requests import Request
from starlette.responses import JSONResponse, RedirectResponse, Response
from starlette.routing import Route

from . import bankfiles, config, crypto, db, industry, pay_providers, rules, xero
from .esign import _deliver
from .web import Ctx, back, flash, form_checked, guarded, render

log = logging.getLogger("invoiceflow.payments")
RUN_STATUS = {"draft": "Draft", "submitted": "Waiting for approval", "approved": "Approved", "rejected": "Rejected",
              "processing": "Paying", "sent": "Sent to bank", "paid": "Paid", "cancelled": "Cancelled"}
STAMP = {"draft": "posted", "submitted": "ready", "approved": "ready", "rejected": "needs_review", "processing": "ready",
         "sent": "posted", "paid": "approved", "cancelled": "rejected"}
ITEM_STATUS = {"pending": "Waiting", "scheduled": "Scheduled", "sent": "Sent", "paid": "Paid", "failed": "Failed",
               "removed": "Removed"}
METHODS = {"file": "Bank payment file", "wise": "Wise Business", "airwallex": "Airwallex", "openbanking": "Open Banking"}


def _today() -> str:
    return date.today().isoformat()


# ---- settings and people ------------------------------------------------------------------------

def pay_settings(business_id: int) -> dict:
    s = rules.settings_for(business_id)
    return {"dual_limit": float(s.get("pay_dual_limit") or 0), "xero_bank_code": s.get("pay_xero_bank_code") or "",
            "remittance": s.get("pay_remittance", True), "debtor": crypto.unseal(s.get("pay_debtor_enc")) if s.get("pay_debtor_enc") else {},
            "default_method": s.get("pay_default_method") or "file"}


def managers(tenant_id: int) -> list[dict]:
    return [u for u in db.list_users(tenant_id) if u["role"] in ("owner", "admin") and u["active"] and u["password_hash"]]


def four_eyes_possible(tenant_id: int) -> bool:
    return len(managers(tenant_id)) >= 2


# ---- supplier bank details with second-person verification -------------------------------------------

def supplier_bank(business_id: int, name: str) -> dict:
    s = db.get_supplier(business_id, name or "") or {}
    return {"approved": crypto.unseal(s.get("bank_enc")) if s.get("bank_enc") else None,
            "pending": crypto.unseal(s.get("bank_pending_enc")) if s.get("bank_pending_enc") else None,
            "pending_by": s.get("bank_pending_by"), "pending_by_id": s.get("bank_pending_by_id"),
            "changed_at": s.get("bank_changed_at"), "approved_by": s.get("bank_approved_by")}


def propose_bank(c: Ctx, supplier: str, details: dict) -> tuple[bool, str]:
    problem = bankfiles.check_details(details)
    if problem:
        return False, problem
    db.save_supplier(c.business["id"], supplier, {
        "bank_pending_enc": crypto.seal(details), "bank_pending_by": c.who,
        "bank_pending_by_id": None if c.impersonating else c.user["id"]})
    db.admin_log(c.tenant["id"], "bank_details_proposed", supplier, c.who)
    if not four_eyes_possible(c.tenant["id"]) and c.is_manager():
        return approve_bank(c, supplier, solo=True)
    return True, f"Bank details for {supplier} saved. A second person (owner or admin) must verify them before they're used."


def approve_bank(c: Ctx, supplier: str, solo: bool = False) -> tuple[bool, str]:
    info = supplier_bank(c.business["id"], supplier)
    if not info["pending"]:
        return False, "Nothing waiting to verify."
    if not c.is_manager():
        return False, "Only an owner or admin can verify bank details."
    if not solo and info["pending_by_id"] and c.user and info["pending_by_id"] == c.user["id"] and four_eyes_possible(c.tenant["id"]):
        return False, "Someone other than the person who entered the bank details must verify them."
    db.save_supplier(c.business["id"], supplier, {
        "bank_enc": crypto.seal(info["pending"]), "bank_pending_enc": None, "bank_pending_by": None, "bank_pending_by_id": None,
        "bank_changed_at": db.now(), "bank_approved_by": c.who + (" (sole approver)" if solo else "")})
    db.admin_log(c.tenant["id"], "bank_details_verified", supplier, c.who)
    return True, f"Bank details for {supplier} verified{' (you are the only owner or admin, so no second person was needed)' if solo else ''}."


# ---- what is owed ---------------------------------------------------------------------------------------

def _in_active_runs(business_id: int) -> set[int]:
    ids = set()
    for r in db.q("""SELECT i.invoice_ids FROM payment_items i JOIN payment_runs r ON r.id = i.run_id
                     WHERE r.business_id = ? AND r.status NOT IN ('cancelled', 'rejected') AND i.status != 'removed'""",
                  (business_id,)):
        ids.update(json.loads(r["invoice_ids"] or "[]"))
    return ids


def outstanding(business_id: int) -> list[dict]:
    busy = _in_active_runs(business_id)
    rows = []
    for inv in db.list_invoices(business_id):
        if inv["status"] not in ("approved", "posted") or inv.get("payment_status") == "paid" or inv["id"] in busy:
            continue
        if inv.get("document_type") not in ("invoice", "credit_note", None) or inv.get("gross_total") is None:
            continue
        payable = industry.amount_payable(inv)
        inv["deducted"] = payable is not None
        inv["owed"] = -abs(inv["gross_total"]) if inv.get("document_type") == "credit_note" else (payable if payable is not None else inv["gross_total"])
        try:
            inv["overdue"] = bool(inv.get("due_date")) and inv["due_date"] < _today()
            inv["due_soon"] = bool(inv.get("due_date")) and _today() <= inv["due_date"] <= (date.today() + timedelta(days=7)).isoformat()
        except TypeError:
            inv["overdue"] = inv["due_soon"] = False
        rows.append(inv)
    rows.sort(key=lambda i: (i.get("due_date") or "9999", i.get("supplier_name") or ""))
    return rows


# ---- runs -----------------------------------------------------------------------------------------------

def load_run(run_id: int, business_id: int) -> dict | None:
    run = db.q1("SELECT * FROM payment_runs WHERE id = ? AND business_id = ?", (run_id, business_id))
    if run:
        run["approvals"] = json.loads(run["approvals"] or "[]")
        run["currency_totals"] = json.loads(run["currency_totals"] or "{}")
    return run


def items_of(run_id: int) -> list[dict]:
    rows = db.q("SELECT * FROM payment_items WHERE run_id = ? AND status != 'removed' ORDER BY pay_date, supplier_name", (run_id,))
    for r in rows:
        r["invoice_ids"] = json.loads(r["invoice_ids"] or "[]")
    return rows


def _retotal(run_id: int) -> None:
    totals = defaultdict(float)
    for it in items_of(run_id):
        totals[it["currency"]] += it["amount"]
    db.ex("UPDATE payment_runs SET total = ?, currency_totals = ? WHERE id = ?",
          (round(sum(totals.values()), 2), json.dumps({k: round(v, 2) for k, v in totals.items()}), run_id))


def create_run(c: Ctx, invoice_ids: list[int], method: str, schedule: str, pay_date: str | None) -> tuple[int | None, list[str]]:
    owed = {i["id"]: i for i in outstanding(c.business["id"])}
    chosen = [owed[i] for i in invoice_ids if i in owed]
    notes = []
    if not chosen:
        return None, ["Choose at least one approved invoice that isn't already being paid."]
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for inv in chosen:
        when = pay_date if schedule == "date" else max(inv.get("due_date") or _today(), _today())
        groups[(inv["supplier_name"], inv.get("currency") or "GBP", when)].append(inv)
    run_id = db.ex("""INSERT INTO payment_runs (tenant_id, business_id, name, status, method, schedule, pay_date, created_by,
                      created_by_id, approvals, created_at) VALUES (?, ?, ?, 'draft', ?, ?, ?, ?, ?, '[]', ?)""",
                   (c.tenant["id"], c.business["id"], f"Payment run {date.today().strftime('%d %b %Y')}", method, schedule,
                    pay_date if schedule == "date" else None, c.who, None if c.impersonating else c.user["id"], db.now()))
    # one payment per supplier, currency and date; credit notes reduce that supplier's earliest payment
    groups: dict[tuple, list[dict]] = defaultdict(list)
    credits: dict[tuple, list[dict]] = defaultdict(list)
    for inv in chosen:
        cur = inv.get("currency") or "GBP"
        if inv["owed"] < 0:
            credits[(inv["supplier_name"], cur)].append(inv)
            continue
        when = pay_date if schedule == "date" else max(inv.get("due_date") or _today(), _today())
        groups[(inv["supplier_name"], cur, when)].append(inv)
    for (supplier, cur), cns in credits.items():
        keys = sorted(k for k in groups if k[0] == supplier and k[1] == cur)
        if keys:
            groups[keys[0]].extend(cns)
        else:
            notes.append(f"{supplier}: credit note left out because there's no invoice from them in this run")
    for (supplier, cur, when), invs in sorted(groups.items()):
        amount = round(sum(i["owed"] for i in invs), 2)
        if amount <= 0:
            notes.append(f"{supplier}: credit notes cover the invoices, so nothing is due")
            continue
        refs = [i.get("invoice_number") or f"#{i['id']}" for i in invs if i["owed"] > 0]
        reference = refs[0] if len(refs) == 1 else f"{len(refs)} INVOICES"
        db.ex("""INSERT INTO payment_items (run_id, invoice_id, invoice_ids, supplier_name, reference, amount, currency, pay_date, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')""",
              (run_id, invs[0]["id"], json.dumps([i["id"] for i in invs]), supplier, reference[:35], amount, cur, when))
    _retotal(run_id)
    return run_id, notes


def checks(run: dict, items: list[dict]) -> list[dict]:
    """Things to look at before approving. level: error (blocks) or warning."""
    out = []
    recent = (datetime.now(timezone.utc) - timedelta(days=14)).isoformat()
    for it in items:
        b = supplier_bank(run["business_id"], it["supplier_name"])
        if not b["approved"]:
            out.append({"level": "error", "item": it["id"],
                        "message": f"{it['supplier_name']}: no verified bank details" + (" (new details waiting for a second person to verify)" if b["pending"] else "")})
        elif b["pending"]:
            out.append({"level": "warning", "item": it["id"],
                        "message": f"{it['supplier_name']}: new bank details are waiting to be verified; the current verified details will be used"})
        if b["approved"] and b["changed_at"] and b["changed_at"] > recent:
            out.append({"level": "warning", "item": it["id"],
                        "message": f"{it['supplier_name']}: bank details changed in the last 14 days - confirm by phone on a number you already hold"})
        if run["method"] == "file" and b["approved"] and b["approved"].get("iban") and not pay_settings(run["business_id"])["debtor"]:
            out.append({"level": "error", "item": it["id"], "message": "Add your own bank account under Payment settings to create the payment file"})
        if run["method"] in ("file", "openbanking") and it["currency"] != "GBP" and run["method"] == "openbanking":
            out.append({"level": "error", "item": it["id"], "message": f"{it['supplier_name']}: Open Banking pays in GBP only - use Wise or Airwallex for {it['currency']}"})
        for inv_id in it["invoice_ids"]:
            inv = db.get_invoice(inv_id)
            if inv and inv.get("payment_status") == "paid":
                out.append({"level": "error", "item": it["id"], "message": f"{it['reference']}: already marked as paid"})
    if run["method"] in ("wise", "airwallex") and not pay_providers.get_conn(run["tenant_id"], run["method"]):
        out.append({"level": "error", "item": None, "message": f"Connect {METHODS[run['method']]} under Payment settings first"})
    if run["method"] == "openbanking" and not pay_providers.ob_configured():
        out.append({"level": "error", "item": None, "message": "Open Banking isn't switched on yet - choose another way to pay"})
    return out


def approvals_needed(run: dict) -> int:
    limit = pay_settings(run["business_id"])["dual_limit"]
    if limit and (run["total"] or 0) > limit and len(managers(run["tenant_id"])) >= 3:
        return 2
    return 1


def can_approve(c: Ctx, run: dict) -> tuple[bool, str]:
    if not c.is_manager():
        return False, "Only an owner or admin can approve payments."
    uid = None if c.impersonating else c.user["id"]
    if uid and any(a.get("user_id") == uid for a in run["approvals"]):
        return False, "You've already approved this run. A different person must give the next approval."
    if uid and run["created_by_id"] == uid and four_eyes_possible(c.tenant["id"]):
        return False, "Four-eyes rule: the person who prepared a payment run can't approve it."
    if c.impersonating:
        return False, "Support staff can't approve customers' payments."
    return True, ""


def _freeze_bank(run_id: int, business_id: int) -> None:
    for it in items_of(run_id):
        b = supplier_bank(business_id, it["supplier_name"])["approved"]
        db.ex("UPDATE payment_items SET bank_enc = ? WHERE id = ?", (crypto.seal(b) if b else None, it["id"]))


def _items_with_bank(run_id: int) -> list[dict]:
    out = []
    for it in items_of(run_id):
        it["bank"] = crypto.unseal(it["bank_enc"]) if it["bank_enc"] else {}
        out.append(it)
    return out


# ---- execution, scheduling and reconciliation ----------------------------------------------------------

def execute_item(run: dict, it: dict) -> None:
    conn = pay_providers.get_conn(run["tenant_id"], run["method"])
    try:
        if run["method"] == "wise":
            ok, ref = pay_providers.wise_pay(conn, it, it["bank"])
        elif run["method"] == "airwallex":
            ok, ref = pay_providers.airwallex_pay(conn, it, it["bank"])
        else:
            return
        db.ex("UPDATE payment_items SET status = 'sent', external_id = ?, error = NULL WHERE id = ?", (ref, it["id"]))
        _mark_invoices(it["invoice_ids"], "scheduled")
    except pay_providers.PayError as exc:
        db.ex("UPDATE payment_items SET status = 'failed', error = ? WHERE id = ?", (str(exc)[:500], it["id"]))


def _mark_invoices(ids: list[int], status: str, paid_at: str | None = None) -> None:
    for i in ids:
        db.update_invoice(i, {"payment_status": status, **({"paid_at": paid_at} if paid_at else {})})


def mark_item_paid(run: dict, it: dict, who: str) -> None:
    paid_on = _today()
    db.ex("UPDATE payment_items SET status = 'paid', paid_at = ? WHERE id = ?", (db.now(), it["id"]))
    _mark_invoices(it["invoice_ids"], "paid", paid_on)
    business = db.get_business(run["business_id"])
    ps = pay_settings(run["business_id"])
    for inv_id in it["invoice_ids"]:
        inv = db.get_invoice(inv_id)
        db.audit(inv_id, "paid", f"{METHODS[run['method']]} run #{run['id']}", who)
        if inv and inv.get("posted_to") == "xero" and inv.get("external_id") and ps["xero_bank_code"] \
                and inv.get("document_type") != "credit_note":
            if len(it["invoice_ids"]) > 1 and any((db.get_invoice(x) or {}).get("document_type") == "credit_note" for x in it["invoice_ids"]) \
                    or industry.amount_payable(inv) is not None:
                db.audit(inv_id, "payment_post_skipped", "Paid net of a credit note or deduction - allocate it in Xero", "system")
                continue
            try:
                xero.post_payment(run["business_id"], inv["external_id"], inv["gross_total"], paid_on, ps["xero_bank_code"],
                                  f"Run {run['id']}")
                db.audit(inv_id, "payment_posted", "Payment recorded in Xero", "system")
            except Exception as exc:
                db.audit(inv_id, "payment_post_failed", str(exc)[:300], "system")
    supplier = db.get_supplier(run["business_id"], it["supplier_name"]) or {}
    if ps["remittance"] and supplier.get("email"):
        lines = []
        for inv_id in it["invoice_ids"]:
            inv = db.get_invoice(inv_id)
            if inv:
                sign = -1 if inv.get("document_type") == "credit_note" else 1
                lines.append(f"- {'Credit note' if sign < 0 else 'Invoice'} {inv.get('invoice_number') or '#' + str(inv_id)}: "
                             f"{sign * abs(inv.get('gross_total') or 0):,.2f}")
        _deliver(business, "payments", supplier["email"], f"Remittance advice from {business['name']}",
                 f"Hello,\n\nWe've paid {it['currency']} {it['amount']:,.2f} on {paid_on} with reference {it['reference']}.\n\n"
                 + "\n".join(lines) + f"\n\nThank you,\n{business['name']}", related=f"payment:{it['id']}")


def _finish_if_done(run_id: int) -> None:
    items = items_of(run_id)
    if items and all(i["status"] == "paid" for i in items):
        db.ex("UPDATE payment_runs SET status = 'paid', paid_at = ? WHERE id = ?", (db.now(), run_id))


def process_due() -> int:
    """Send scheduled API payments that are due, and check sent ones. Called every few minutes."""
    done = 0
    for run in db.q("SELECT * FROM payment_runs WHERE status IN ('approved', 'processing') AND method IN ('wise', 'airwallex')"):
        run["approvals"] = json.loads(run["approvals"] or "[]")
        conn = pay_providers.get_conn(run["tenant_id"], run["method"])
        if not conn:
            continue
        for it in _items_with_bank(run["id"]):
            if it["status"] in ("pending", "scheduled") and (it["pay_date"] or _today()) <= _today():
                execute_item(run, it)
                done += 1
            elif it["status"] == "sent" and it["external_id"]:
                try:
                    state = (pay_providers.wise_status if run["method"] == "wise" else pay_providers.airwallex_status)(conn, it["external_id"])
                except pay_providers.PayError:
                    continue
                if state == "paid":
                    mark_item_paid(run, it, METHODS[run["method"]])
                    done += 1
                elif state == "failed":
                    db.ex("UPDATE payment_items SET status = 'failed', error = 'Returned or cancelled by the provider' WHERE id = ?", (it["id"],))
        if run["status"] == "approved":
            db.ex("UPDATE payment_runs SET status = 'processing' WHERE id = ?", (run["id"],))
        _finish_if_done(run["id"])
    return done


def start_scheduler(interval: int = 600) -> None:
    if os.getenv("PAYMENTS_SCHEDULER", "1") != "1":
        return

    def loop():
        while True:
            time.sleep(interval)
            try:
                process_due()
            except Exception:
                log.exception("Payment scheduler failed")
    threading.Thread(target=loop, daemon=True, name="payments").start()


# ---- pages ---------------------------------------------------------------------------------------------

def _gate(request: Request, c: Ctx):
    if not c.can("payments"):
        return render(request, "upgrade.html", c, feature="Supplier payments",
                      blurb="Pay many suppliers in one approved payment run, each on its due date, with four-eyes approval "
                            "and invoices marked paid automatically.", packages=["Standard", "Advanced", "Practice"])
    return None


@guarded("app")
async def payments_page(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    rows = outstanding(c.business["id"])
    for r in rows:
        b = supplier_bank(c.business["id"], r["supplier_name"])
        r["bank_ok"] = bool(b["approved"])
    runs = db.q("SELECT * FROM payment_runs WHERE business_id = ? ORDER BY id DESC LIMIT 100", (c.business["id"],))
    conn = pay_providers.connected(c.tenant["id"])
    methods = {"file": True, "wise": c.can("payments_api") and conn["wise"], "airwallex": c.can("payments_api") and conn["airwallex"],
               "openbanking": c.can("payments_api") and conn["openbanking"]}
    totals = defaultdict(float)
    for r in rows:
        totals[r.get("currency") or "GBP"] += r["owed"]
    return render(request, "payments.html", c, rows=rows, runs=runs, RUN_STATUS=RUN_STATUS, STAMP=STAMP, METHODS=METHODS,
                  methods=methods, default_method=pay_settings(c.business["id"])["default_method"], today=_today(),
                  totals=dict(totals))


@guarded("app")
async def create(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    form = await form_checked(request)
    ids = [int(x) for x in form.getlist("invoice") if str(x).isdigit()]
    method = form.get("method") if form.get("method") in METHODS else "file"
    if method != "file" and not c.can("payments_api"):
        method = "file"
    schedule = "date" if form.get("schedule") == "date" else "due"
    pay_date = form.get("pay_date") or _today()
    if schedule == "date" and pay_date < _today():
        pay_date = _today()
    run_id, notes = create_run(c, ids, method, schedule, pay_date)
    for n in notes:
        flash(request, n, "warn")
    if not run_id:
        return back("/payments")
    return back(f"/payments/runs/{run_id}")


@guarded("app")
async def run_page(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    run = load_run(int(request.path_params["id"]), c.business["id"])
    if not run:
        return Response(status_code=404)
    items = items_of(run["id"])
    for it in items:
        b = supplier_bank(c.business["id"], it["supplier_name"])
        frozen = crypto.unseal(it["bank_enc"]) if it["bank_enc"] else None
        it["bank_masked"] = bankfiles.masked(frozen or b["approved"])
    ok, why = can_approve(c, run)
    return render(request, "payment_run.html", c, run=run, items=items, warnings=checks(run, items) if run["status"] in ("draft", "submitted") else [],
                  RUN_STATUS=RUN_STATUS, STAMP=STAMP, ITEM_STATUS=ITEM_STATUS, METHODS=METHODS,
                  needed=approvals_needed(run), can_approve=ok, why_not=why, solo=not four_eyes_possible(c.tenant["id"]))


@guarded("app")
async def run_action(request: Request, c: Ctx):
    run = load_run(int(request.path_params["id"]), c.business["id"])
    if not run:
        return Response(status_code=404)
    form = await form_checked(request)
    act = form.get("action")
    items = items_of(run["id"])
    if act == "remove_item" and run["status"] == "draft":
        db.ex("UPDATE payment_items SET status = 'removed' WHERE id = ? AND run_id = ?", (int(form.get("item_id") or 0), run["id"]))
        _retotal(run["id"])
    elif act == "submit" and run["status"] in ("draft", "rejected"):
        errors = [w for w in checks(run, items) if w["level"] == "error"]
        if errors:
            flash(request, "Fix these first: " + "; ".join(e["message"] for e in errors), "error")
        elif not items:
            flash(request, "The run is empty.", "error")
        else:
            db.ex("UPDATE payment_runs SET status = 'submitted', submitted_at = ?, approvals = '[]', rejected_reason = NULL WHERE id = ?",
                  (db.now(), run["id"]))
            db.admin_log(c.tenant["id"], "payment_run_submitted", f"#{run['id']} {run['total']:.2f}", c.who)
            flash(request, "Sent for approval." + ("" if four_eyes_possible(c.tenant["id"]) else
                                                  " You're the only owner or admin, so you can approve it yourself."))
    elif act == "approve" and run["status"] == "submitted":
        ok, why = can_approve(c, run)
        errors = [w for w in checks(run, items) if w["level"] == "error"]
        if not ok:
            flash(request, why, "error")
        elif errors:
            flash(request, "Can't approve: " + "; ".join(e["message"] for e in errors), "error")
        else:
            approvals = run["approvals"] + [{"user_id": c.user["id"], "who": c.who, "at": db.now()}]
            db.ex("UPDATE payment_runs SET approvals = ? WHERE id = ?", (json.dumps(approvals), run["id"]))
            db.admin_log(c.tenant["id"], "payment_run_approved", f"#{run['id']} by {c.who}", c.who)
            if len(approvals) >= approvals_needed(run):
                _freeze_bank(run["id"], c.business["id"])
                db.ex("UPDATE payment_runs SET status = 'approved', approved_at = ? WHERE id = ?", (db.now(), run["id"]))
                db.ex("UPDATE payment_items SET status = 'scheduled' WHERE run_id = ? AND status = 'pending'", (run["id"],))
                for it in items:
                    _mark_invoices(it["invoice_ids"], "scheduled")
                flash(request, "Approved." + (
                    " Download the payment file and upload it to your bank." if run["method"] == "file" else
                    " Authorise the payments at your bank to finish." if run["method"] == "openbanking" else
                    " Payments go out on their dates automatically."))
                if run["method"] in ("wise", "airwallex"):
                    process_due()
            else:
                flash(request, f"Approval recorded. {approvals_needed(run) - len(approvals)} more approval needed from a different person.")
    elif act == "reject" and run["status"] == "submitted" and c.is_manager():
        db.ex("UPDATE payment_runs SET status = 'rejected', rejected_reason = ? WHERE id = ?",
              (str(form.get("reason", ""))[:300], run["id"]))
        flash(request, "Run rejected and sent back.")
    elif act == "mark_sent" and run["status"] == "approved" and run["method"] == "file":
        db.ex("UPDATE payment_runs SET status = 'sent', sent_at = ? WHERE id = ?", (db.now(), run["id"]))
        db.ex("UPDATE payment_items SET status = 'sent' WHERE run_id = ? AND status = 'scheduled'", (run["id"],))
        flash(request, "Marked as sent to the bank. Mark payments as paid once they leave your account.")
    elif act in ("mark_paid", "mark_item_paid") and run["status"] in ("approved", "sent", "processing"):
        targets = [i for i in _items_with_bank(run["id"]) if i["status"] in ("scheduled", "sent", "failed") and
                   (act == "mark_paid" or i["id"] == int(form.get("item_id") or 0))]
        for it in targets:
            mark_item_paid(run, it, c.who)
        _finish_if_done(run["id"])
        flash(request, f"{len(targets)} payment(s) marked as paid. Invoices updated" +
              (" and remittance advice sent." if pay_settings(c.business["id"])["remittance"] else "."))
    elif act == "retry_item" and run["status"] in ("approved", "processing"):
        db.ex("UPDATE payment_items SET status = 'scheduled', error = NULL WHERE id = ? AND run_id = ? AND status = 'failed'",
              (int(form.get("item_id") or 0), run["id"]))
        process_due()
    elif act == "cancel" and run["status"] in ("draft", "submitted", "rejected", "approved"):
        if run["status"] == "approved" and any(i["status"] in ("sent", "paid") for i in items):
            flash(request, "Some payments have already gone out. Cancel those with the bank or provider.", "error")
        else:
            db.ex("UPDATE payment_runs SET status = 'cancelled' WHERE id = ?", (run["id"],))
            for it in items:
                _mark_invoices(it["invoice_ids"], None)
            flash(request, "Payment run cancelled.")
    return back(f"/payments/runs/{run['id']}")


@guarded("app")
async def run_file(request: Request, c: Ctx):
    run = load_run(int(request.path_params["id"]), c.business["id"])
    if not run or run["status"] not in ("approved", "sent", "paid") or run["method"] != "file":
        return Response("The payment file is available once the run is approved.", status_code=404)
    items = [i for i in _items_with_bank(run["id"]) if i["status"] != "removed"]
    kind = request.path_params["kind"]
    db.admin_log(c.tenant["id"], "payment_file_downloaded", f"#{run['id']} {kind}", c.who)
    if kind == "pain001":
        debtor = {**pay_settings(c.business["id"])["debtor"], "name": c.business["name"]}
        body = bankfiles.pain001(items, debtor, f"RUN{run['id']}")
        return Response(body, media_type="application/xml",
                        headers={"Content-Disposition": f'attachment; filename="payment-run-{run["id"]}.xml"'})
    if any(i["bank"].get("iban") or i["currency"] != "GBP" for i in items):
        return Response("This run includes international payments. Use the ISO 20022 file instead.", status_code=400)
    return Response(bankfiles.uk_csv(items), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="payment-run-{run["id"]}.csv"'})


@guarded("app")
async def ob_start(request: Request, c: Ctx):
    run = load_run(int(request.path_params["id"]), c.business["id"])
    if not run or run["status"] != "approved" or run["method"] != "openbanking":
        return Response(status_code=404)
    await form_checked(request)
    try:
        ref, url = pay_providers.ob_create(run, _items_with_bank(run["id"]),
                                           f"{config.BASE_URL.rstrip('/')}/payments/runs/{run['id']}?authorised=1")
    except pay_providers.PayError as exc:
        flash(request, str(exc), "error")
        return back(f"/payments/runs/{run['id']}")
    db.ex("UPDATE payment_runs SET status = 'processing', notes = ? WHERE id = ?", (f"ob:{ref}", run["id"]))
    db.ex("UPDATE payment_items SET status = 'sent', external_id = ? WHERE run_id = ? AND status = 'scheduled'", (ref, run["id"]))
    return RedirectResponse(url, status_code=303)


async def ob_webhook(request: Request):
    secret = os.getenv("OB_WEBHOOK_SECRET", "")
    if not secret or not secrets.compare_digest(request.headers.get("x-webhook-secret", ""), secret):
        return JSONResponse({"error": "unauthorised"}, status_code=401)
    try:
        ev = json.loads(await request.body())
    except ValueError:
        return JSONResponse({"error": "bad payload"}, status_code=400)
    item = db.q1("SELECT * FROM payment_items WHERE id = ?", (int(ev.get("payment_id") or 0),))
    if not item:
        return JSONResponse({"error": "unknown payment"}, status_code=404)
    run = db.q1("SELECT * FROM payment_runs WHERE id = ?", (item["run_id"],))
    item["invoice_ids"] = json.loads(item["invoice_ids"] or "[]")
    if ev.get("status") in ("executed", "settled", "paid"):
        mark_item_paid(run, item, "Open Banking")
        _finish_if_done(run["id"])
    elif ev.get("status") in ("failed", "rejected", "cancelled"):
        db.ex("UPDATE payment_items SET status = 'failed', error = ? WHERE id = ?", (str(ev.get("reason", "Failed"))[:300], item["id"]))
    return JSONResponse({"ok": True})


@guarded("app")
async def settings_page(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    if request.method == "POST":
        if not c.is_manager():
            flash(request, "Only an owner or admin can change payment settings.", "error")
            return back("/payments/settings")
        form = await form_checked(request)
        act = form.get("action")
        stored = db.business_settings(c.business["id"])
        if act == "general":
            debtor = {k: str(form.get(f"d_{k}", "")).strip() for k in ("account_name", "sort_code", "account_number", "iban", "bic")}
            if any(debtor.values()):
                problem = bankfiles.check_details(debtor)
                if problem:
                    flash(request, f"Your bank account: {problem}", "error")
                    return back("/payments/settings")
                stored["pay_debtor_enc"] = crypto.seal(debtor)
            stored["pay_dual_limit"] = float(str(form.get("dual_limit") or 0).replace(",", "") or 0)
            stored["pay_xero_bank_code"] = str(form.get("xero_bank_code", "")).strip()[:20]
            stored["pay_remittance"] = form.get("remittance") == "1"
            stored["pay_default_method"] = form.get("default_method") if form.get("default_method") in METHODS else "file"
            db.save_business_settings(c.business["id"], stored)
            flash(request, "Payment settings saved.")
        elif act == "wise" and c.can("payments_api"):
            token, sandbox = str(form.get("token", "")).strip(), form.get("sandbox") == "1"
            try:
                profiles = [p for p in pay_providers.wise_profiles(token, sandbox) if p["type"] in ("business", "BUSINESS")] or \
                    pay_providers.wise_profiles(token, sandbox)
            except pay_providers.PayError as exc:
                flash(request, f"Wise didn't accept that token: {exc}", "error")
                return back("/payments/settings")
            if not profiles:
                flash(request, "No Wise profile found for that token.", "error")
                return back("/payments/settings")
            pay_providers.save_conn(c.tenant["id"], "wise", {"token": token, "sandbox": sandbox, "profile_id": profiles[0]["id"],
                                                            "profile_name": profiles[0]["name"], "source_currency": "GBP"})
            db.admin_log(c.tenant["id"], "wise_connected", profiles[0]["name"], c.who)
            flash(request, f"Wise connected ({profiles[0]['name']}).")
        elif act == "airwallex" and c.can("payments_api"):
            conn = {"client_id": str(form.get("client_id", "")).strip(), "api_key": str(form.get("api_key", "")).strip(),
                    "sandbox": form.get("sandbox") == "1", "source_currency": "GBP"}
            try:
                pay_providers.airwallex_check(conn)
            except pay_providers.PayError as exc:
                flash(request, f"Airwallex didn't accept those details: {exc}", "error")
                return back("/payments/settings")
            pay_providers.save_conn(c.tenant["id"], "airwallex", conn)
            db.admin_log(c.tenant["id"], "airwallex_connected", "", c.who)
            flash(request, "Airwallex connected.")
        elif act in ("disconnect_wise", "disconnect_airwallex"):
            pay_providers.save_conn(c.tenant["id"], act.split("_")[1], None)
            flash(request, "Disconnected.")
        return back("/payments/settings")
    ps = pay_settings(c.business["id"])
    return render(request, "payment_settings.html", c, ps=ps, debtor_masked=bankfiles.masked(ps["debtor"]) if ps["debtor"] else "",
                  wise=pay_providers.get_conn(c.tenant["id"], "wise"), awx=pay_providers.get_conn(c.tenant["id"], "airwallex"),
                  ob=pay_providers.ob_configured(), api=c.can("payments_api"), METHODS=METHODS,
                  four_eyes=four_eyes_possible(c.tenant["id"]))


@guarded("app")
async def supplier_bank_action(request: Request, c: Ctx):
    form = await form_checked(request)
    supplier = str(form.get("supplier", "")).strip()[:200]
    if not supplier:
        return back("/suppliers")
    if form.get("action") == "verify":
        ok, msg = approve_bank(c, supplier)
    elif form.get("action") == "discard":
        db.save_supplier(c.business["id"], supplier, {"bank_pending_enc": None, "bank_pending_by": None, "bank_pending_by_id": None})
        ok, msg = True, "Pending bank details discarded."
    else:
        details = {k: str(form.get(k, "")).strip()[:70] for k in ("account_name", "sort_code", "account_number", "iban", "bic", "country")}
        ok, msg = propose_bank(c, supplier, {k: v for k, v in details.items() if v})
    flash(request, msg, "ok" if ok else "error")
    return back("/suppliers")


routes = [
    Route("/payments", payments_page),
    Route("/payments/runs", create, methods=["POST"]),
    Route("/payments/runs/{id:int}", run_page),
    Route("/payments/runs/{id:int}/action", run_action, methods=["POST"]),
    Route("/payments/runs/{id:int}/file/{kind}", run_file),
    Route("/payments/runs/{id:int}/openbanking", ob_start, methods=["POST"]),
    Route("/payments/ob/webhook", ob_webhook, methods=["POST"]),
    Route("/payments/settings", settings_page, methods=["GET", "POST"]),
    Route("/suppliers/bank", supplier_bank_action, methods=["POST"]),
]
