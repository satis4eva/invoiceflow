"""E-signing: the accountant uploads a PDF, places signature boxes, sends it; clients sign on any device;
the signed PDF with a certificate and audit trail comes back to the accountant."""
import hashlib
import json
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from starlette.requests import Request
from starlette.responses import FileResponse, Response
from starlette.routing import Route

from . import accounts, config, db, mailboxes, mailer
from .esign_pdf import PdfProblem, build_final, decode_signature, page_png, page_ratios, prepare_upload, sha256
from .web import Ctx, back, csrf_token, flash, form_checked, guarded, render, templates

STATUS = {"draft": "Draft", "sent": "Waiting for signatures", "completed": "Signed", "declined": "Declined",
          "voided": "Cancelled", "expired": "Expired"}
SIGNER_STATUS = {"pending": "Not sent", "sent": "Sent", "viewed": "Opened", "signed": "Signed", "declined": "Declined"}
COLOURS = ["#24427c", "#2c7a4d", "#9a5c00", "#7a2c6e", "#b02a22"]
MAX_SIGNERS = 5


# ---- data ----------------------------------------------------------------------------------

def _now() -> str:
    return db.now()


def docs_dir(business_id: int) -> Path:
    d = config.DATA_DIR / config.DOCS_DIR_NAME / f"b{business_id}"
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_request(request_id: int, business_id: int | None = None) -> dict | None:
    if business_id is None:
        return db.q1("SELECT * FROM sign_requests WHERE id = ?", (request_id,))
    return db.q1("SELECT * FROM sign_requests WHERE id = ? AND business_id = ?", (request_id, business_id))


def signers_of(request_id: int) -> list[dict]:
    rows = db.q("SELECT * FROM sign_signers WHERE request_id = ? ORDER BY position, id", (request_id,))
    for r in rows:
        r["fields"] = json.loads(r["fields"]) if r["fields"] else []
    return rows


def signer_by_token(token: str) -> dict | None:
    if not token or len(token) < 20:
        return None
    s = db.q1("SELECT * FROM sign_signers WHERE token = ?", (token,))
    if s:
        s["fields"] = json.loads(s["fields"]) if s["fields"] else []
    return s


def event(request_id: int, name: str, detail: str = "", signer_id: int | None = None, req: Request | None = None) -> None:
    ip = req.client.host if req and req.client else None
    ua = req.headers.get("user-agent", "")[:300] if req else None
    db.ex("INSERT INTO sign_events (request_id, signer_id, event, detail, ip, user_agent, at) VALUES (?, ?, ?, ?, ?, ?, ?)",
          (request_id, signer_id, name, detail[:500], ip, ua, _now()))


def events_of(request_id: int) -> list[dict]:
    return db.q("""SELECT e.*, s.name signer_name FROM sign_events e LEFT JOIN sign_signers s ON s.id = e.signer_id
                   WHERE e.request_id = ? ORDER BY e.id""", (request_id,))


def refresh_expiry(r: dict) -> dict:
    if r["status"] == "sent" and r.get("expires_at") and r["expires_at"] < _now():
        db.ex("UPDATE sign_requests SET status = 'expired' WHERE id = ?", (r["id"],))
        event(r["id"], "expired")
        r["status"] = "expired"
    return r


def _client_ip(req: Request) -> str:
    return req.client.host if req.client else ""


# ---- sending emails for a request ---------------------------------------------------------

def _sender_mailbox(business: dict) -> dict | None:
    boxes = db.q("SELECT * FROM mailboxes WHERE tenant_id = ? ORDER BY shared DESC, id", (business["tenant_id"],))
    return next((m for m in boxes if m["id"] == business.get("mailbox_id")), None) or \
        next((m for m in boxes if m["shared"]), None)


def _deliver(business: dict, who: str, to: str, subject: str, body: str, button=None, attachments=None,
             related: str | None = None) -> bool:
    box = _sender_mailbox(business)
    if box:
        ok, _ = mailboxes.send_and_log(business["tenant_id"], business["id"], box, who, [to], subject, body,
                                       attachments=attachments, button=button, related=related)
        return ok
    text = body + (f"\n\n{button[0]}: {button[1]}" if button else "")
    return mailer.send(to, subject, text, attachments)


def sign_link(signer: dict) -> str:
    return f"{config.BASE_URL.rstrip('/')}/sign/{signer['token']}"


def send_to_signer(r: dict, signer: dict, business: dict, tenant: dict, who: str, reminder: bool = False) -> bool:
    if not signer["email"]:
        return False
    intro = "Reminder: " if reminder else ""
    body = (f"Hello {signer['name']},\n\n{tenant['name']} has sent you \"{r['title']}\" to sign electronically."
            + (f"\n\n{r['message']}" if r.get("message") else "")
            + "\n\nIt takes about a minute and works on your phone. "
              f"The link is personal to you and works until {r['expires_at'][:10]}.")
    if r.get("access_code"):
        body += "\n\nYou'll need the access code your accountant gave you."
    ok = _deliver(business, who, signer["email"], f"{intro}Please sign: {r['title']}", body,
                  button=("Review and sign", sign_link(signer)), related=f"sign:{r['id']}")
    if ok and signer["status"] == "pending":
        db.ex("UPDATE sign_signers SET status = 'sent' WHERE id = ?", (signer["id"],))
    event(r["id"], "reminder_sent" if reminder else "sent", f"to {signer['email']}" if ok else
          f"email to {signer['email']} failed", signer["id"])
    return ok


def finalize(r: dict, req: Request | None = None) -> None:
    business = db.get_business(r["business_id"])
    tenant = db.get_tenant(r["tenant_id"])
    db.ex("UPDATE sign_requests SET status = 'completed', completed_at = ? WHERE id = ?", (_now(), r["id"]))
    event(r["id"], "completed", "all parties signed")
    r = get_request(r["id"])
    signers = signers_of(r["id"])
    final = docs_dir(r["business_id"]) / f"{uuid.uuid4().hex}_signed.pdf"
    build_final(Path(r["original_path"]), final, r, signers, events_of(r["id"]), tenant["name"])
    db.ex("UPDATE sign_requests SET final_path = ?, final_hash = ? WHERE id = ?", (str(final), sha256(final), r["id"]))
    name = f"{r['title'][:80]} - signed.pdf"
    attach = [(name, final.read_bytes(), "application/pdf")]
    for s in signers:
        if s["email"]:
            _deliver(business, "e-signing", s["email"], f"Signed: {r['title']}",
                     f"Hello {s['name']},\n\nEveryone has signed \"{r['title']}\". Your copy is attached.\n\n{tenant['name']}",
                     attachments=attach, related=f"sign:{r['id']}")
    box = _sender_mailbox(business)
    notify = box["from_email"] if box else next((u["email"] for u in db.list_users(tenant["id"]) if u["role"] == "owner"), None)
    if notify:
        _deliver(business, "e-signing", notify, f"Signed and returned: {r['title']} ({business['name']})",
                 f"\"{r['title']}\" for {business['name']} has been signed by everyone. The signed copy with its "
                 f"certificate is attached and saved in {config.APP_NAME}.",
                 button=("Open in " + config.APP_NAME, f"{config.BASE_URL.rstrip('/')}/esign/{r['id']}"),
                 attachments=attach, related=f"sign:{r['id']}")


# ---- accountant side -------------------------------------------------------------------------

def _gate(request: Request, c: Ctx):
    if not c.can("esign"):
        return render(request, "upgrade.html", c, feature="E-signing",
                      blurb="Send engagement letters, accounts and returns to clients to sign on their phone. "
                            "The signed PDF, with a certificate and audit trail, comes straight back to you.")
    return None


def _mine(request: Request, c: Ctx) -> dict | None:
    r = get_request(int(request.path_params["id"]), c.business["id"])
    return refresh_expiry(r) if r else None


@guarded("app")
async def list_page(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    rows = db.q("SELECT * FROM sign_requests WHERE business_id = ? ORDER BY id DESC", (c.business["id"],))
    for r in rows:
        refresh_expiry(r)
        r["signers"] = signers_of(r["id"])
    return render(request, "esign_list.html", c, rows=rows, STATUS=STATUS)


@guarded("app")
async def new_page(request: Request, c: Ctx):
    gate = _gate(request, c)
    if gate:
        return gate
    if request.method == "GET":
        return render(request, "esign_new.html", c, values={}, error=None, MAX_SIGNERS=MAX_SIGNERS)
    form = await form_checked(request)
    values = {k: str(form.get(k, "")).strip() for k in ("title", "message", "access_code", "days")}
    signers = []
    for i in range(MAX_SIGNERS):
        name, email = str(form.get(f"name_{i}", "")).strip(), str(form.get(f"email_{i}", "")).strip().lower()
        if name or email:
            signers.append((name, email))
        values[f"name_{i}"], values[f"email_{i}"] = name, email
    upload = form.get("file")
    error = None
    if not values["title"]:
        error = "Give the document a name, for example Engagement letter 2026."
    elif not getattr(upload, "filename", ""):
        error = "Choose the PDF to be signed."
    elif not signers:
        error = "Add at least one person to sign."
    elif any(not n or not mailboxes.EMAIL_RE.match(e) for n, e in signers):
        error = "Each signer needs a name and a valid email address."
    if not error:
        dest = docs_dir(c.business["id"]) / f"{uuid.uuid4().hex}.pdf"
        try:
            pages = prepare_upload(await upload.read(), dest)
        except PdfProblem as exc:
            error = str(exc)
    if error:
        return render(request, "esign_new.html", c, values=values, error=error, MAX_SIGNERS=MAX_SIGNERS)

    days = int(values["days"]) if values["days"].isdigit() and 1 <= int(values["days"]) <= 90 else 30
    code = values["access_code"]
    rid = db.ex("""INSERT INTO sign_requests (tenant_id, business_id, title, message, status, filename, original_path,
                   original_hash, page_count, access_code, created_by, created_at, expires_at)
                   VALUES (?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?)""",
                (c.tenant["id"], c.business["id"], values["title"][:200], values["message"][:2000],
                 upload.filename[:200], str(dest), sha256(dest), pages,
                 hashlib.sha256(code.encode()).hexdigest() if code else None, c.who, _now(),
                 (datetime.now(timezone.utc) + timedelta(days=days)).isoformat(timespec="seconds")))
    for pos, (name, email) in enumerate(signers):
        db.ex("INSERT INTO sign_signers (request_id, name, email, token, position) VALUES (?, ?, ?, ?, ?)",
              (rid, name[:120], email, secrets.token_urlsafe(24), pos))
    event(rid, "created", f"by {c.who}")
    return back(f"/esign/{rid}/prepare")


@guarded("app")
async def prepare_page(request: Request, c: Ctx):
    r = _mine(request, c)
    if not r:
        return Response(status_code=404)
    if r["status"] != "draft":
        return back(f"/esign/{r['id']}")
    signers = signers_of(r["id"])
    for i, s in enumerate(signers):
        s["colour"] = COLOURS[i % len(COLOURS)]
    return render(request, "esign_prepare.html", c, r=r, signers=signers,
                  ratios=page_ratios(Path(r["original_path"])), has_mailbox=bool(_sender_mailbox(c.business)),
                  mail_enabled=mailer.enabled())


def _clean_fields(raw: str, signer_ids: list[int], pages: int) -> dict[int, list[dict]]:
    out: dict[int, list[dict]] = {sid: [] for sid in signer_ids}
    try:
        data = json.loads(raw or "{}")
    except ValueError:
        return out
    for sid_str, fields in (data or {}).items():
        sid = int(sid_str) if str(sid_str).isdigit() else None
        if sid not in out or not isinstance(fields, list):
            continue
        for f in fields[:20]:
            try:
                page, x, y, w, h = int(f["page"]), float(f["x"]), float(f["y"]), float(f["w"]), float(f["h"])
            except (KeyError, TypeError, ValueError):
                continue
            if 0 <= page < pages and 0 <= x <= 1 and 0 <= y <= 1 and 0.02 <= w <= 1 and 0.01 <= h <= 1:
                out[sid].append({"page": page, "x": round(min(x, 1 - w), 4), "y": round(min(y, 1 - h), 4),
                                 "w": round(w, 4), "h": round(h, 4)})
    return out


@guarded("app")
async def send_request(request: Request, c: Ctx):
    r = _mine(request, c)
    if not r or r["status"] != "draft":
        return Response(status_code=404)
    form = await form_checked(request)
    signers = signers_of(r["id"])
    fields = _clean_fields(str(form.get("fields", "")), [s["id"] for s in signers], r["page_count"])
    for s in signers:
        db.ex("UPDATE sign_signers SET fields = ? WHERE id = ?", (json.dumps(fields[s["id"]]), s["id"]))
    db.ex("UPDATE sign_requests SET status = 'sent', sent_at = ? WHERE id = ?", (_now(), r["id"]))
    r = get_request(r["id"])
    sent = 0
    if form.get("by_email") == "1":
        for s in signers_of(r["id"]):
            sent += send_to_signer(r, s, c.business, c.tenant, c.who)
    if sent == len(signers):
        flash(request, f"Sent to {sent} signer{'s' if sent != 1 else ''}. You'll be emailed the signed copy.")
    else:
        flash(request, "Ready to sign. Copy each person's signing link below and send it to them"
                       + (" - some emails couldn't be sent." if form.get("by_email") == "1" else "."), "warn")
    return back(f"/esign/{r['id']}")


@guarded("app")
async def detail_page(request: Request, c: Ctx):
    r = _mine(request, c)
    if not r:
        return Response(status_code=404)
    signers = signers_of(r["id"])
    for s in signers:
        s["link"] = sign_link(s)
    return render(request, "esign_detail.html", c, r=r, signers=signers, events=events_of(r["id"]),
                  STATUS=STATUS, SIGNER_STATUS=SIGNER_STATUS)


@guarded("app")
async def action(request: Request, c: Ctx):
    r = _mine(request, c)
    if not r:
        return Response(status_code=404)
    form = await form_checked(request)
    act = form.get("action")
    if act == "remind" and r["status"] == "sent":
        s = next((x for x in signers_of(r["id"]) if x["id"] == int(form.get("signer_id") or 0)), None)
        if s and s["status"] not in ("signed", "declined"):
            ok = send_to_signer(r, s, c.business, c.tenant, c.who, reminder=True)
            flash(request, f"Reminder sent to {s['email']}." if ok else "The reminder couldn't be emailed. Copy the link instead.",
                  "ok" if ok else "warn")
    elif act == "void" and r["status"] in ("sent", "draft"):
        db.ex("UPDATE sign_requests SET status = 'voided' WHERE id = ?", (r["id"],))
        event(r["id"], "voided", f"by {c.who}")
        flash(request, "Cancelled. The signing links no longer work.")
    elif act == "delete" and r["status"] in ("draft", "voided", "expired"):
        for p in (r["original_path"], r["final_path"]):
            if p:
                Path(p).unlink(missing_ok=True)
        db.ex("DELETE FROM sign_events WHERE request_id = ?", (r["id"],))
        db.ex("DELETE FROM sign_signers WHERE request_id = ?", (r["id"],))
        db.ex("DELETE FROM sign_requests WHERE id = ?", (r["id"],))
        flash(request, "Deleted.")
        return back("/esign")
    return back(f"/esign/{r['id']}")


@guarded("app")
async def page_image(request: Request, c: Ctx):
    r = _mine(request, c)
    if not r:
        return Response(status_code=404)
    try:
        png = page_png(Path(r["original_path"]), int(request.path_params["n"]))
    except PdfProblem:
        return Response(status_code=404)
    return Response(png, media_type="image/png", headers={"Cache-Control": "private, max-age=3600"})


@guarded("app")
async def download(request: Request, c: Ctx):
    r = _mine(request, c)
    if not r:
        return Response(status_code=404)
    which = request.path_params["which"]
    path = r["final_path"] if which == "signed" else r["original_path"]
    if not path:
        return Response(status_code=404)
    suffix = " - signed" if which == "signed" else ""
    return FileResponse(path, filename=f"{r['title'][:80]}{suffix}.pdf", media_type="application/pdf")


# ---- signer side (public, by personal link) ---------------------------------------------------

def _load(token: str):
    s = signer_by_token(token)
    if not s:
        return None, None
    r = refresh_expiry(get_request(s["request_id"]))
    return s, r


def _code_ok(request: Request, r: dict, token: str) -> bool:
    return not r.get("access_code") or request.session.get(f"sign_ok_{token}") is True


def _signer_page(request: Request, s: dict, r: dict, token: str, **extra):
    tenant = db.get_tenant(r["tenant_id"])
    business = db.get_business(r["business_id"])
    ctx = {"request": request, "s": s, "r": r, "tenant": tenant, "business": business, "token": token,
           "csrf": csrf_token(request), "ratios": page_ratios(Path(r["original_path"])),
           "needs_code": not _code_ok(request, r, token), "error": None, "APP_NAME": config.APP_NAME}
    ctx.update(extra)
    return templates.TemplateResponse(request, "sign.html", ctx)


def _not_found(request: Request):
    return templates.TemplateResponse(request, "sign.html", {
        "request": request, "s": None, "r": None, "tenant": None, "token": "", "csrf": "", "ratios": [],
        "needs_code": False, "error": "This signing link isn't valid. Ask the sender for a new one.",
        "APP_NAME": config.APP_NAME}, status_code=404)


async def sign_page(request: Request):
    token = request.path_params["token"]
    s, r = _load(token)
    if not s:
        return _not_found(request)
    if r["status"] == "sent" and _code_ok(request, r, token) and s["status"] in ("pending", "sent"):
        db.ex("UPDATE sign_signers SET status = 'viewed' WHERE id = ?", (s["id"],))
        event(r["id"], "viewed", "", s["id"], request)
        s["status"] = "viewed"
    return _signer_page(request, s, r, token)


async def sign_code(request: Request):
    token = request.path_params["token"]
    s, r = _load(token)
    if not s:
        return _not_found(request)
    form = await form_checked(request)
    key = f"code|{token}|{_client_ip(request)}"
    if accounts.throttled(key):
        return _signer_page(request, s, r, token, error="Too many tries. Wait 15 minutes and try again.")
    code = str(form.get("code", "")).strip()
    if r.get("access_code") and secrets.compare_digest(hashlib.sha256(code.encode()).hexdigest(), r["access_code"]):
        request.session[f"sign_ok_{token}"] = True
        accounts.clear_failures(key)
        return back(f"/sign/{token}")
    accounts.record_failure(key)
    return _signer_page(request, s, r, token, error="That code isn't right. Check with the person who sent it.")


async def sign_submit(request: Request):
    token = request.path_params["token"]
    s, r = _load(token)
    if not s:
        return _not_found(request)
    try:
        form = await form_checked(request)
    except PermissionError:
        return _signer_page(request, s, r, token, error="The page was open too long. Reload it and sign again.")
    if not _code_ok(request, r, token):
        return back(f"/sign/{token}")
    if r["status"] != "sent" or s["status"] in ("signed", "declined"):
        return back(f"/sign/{token}")
    name = str(form.get("signed_name", "")).strip()[:120]
    kind = "typed" if form.get("kind") == "typed" else "drawn"
    data = str(form.get("typed", "")).strip()[:120] if kind == "typed" else str(form.get("drawing", ""))
    if len(name) < 2:
        return _signer_page(request, s, r, token, error="Type your full name.")
    if not form.get("consent"):
        return _signer_page(request, s, r, token, error="Tick the box to agree to sign electronically.")
    try:
        if kind == "drawn":
            decode_signature(data)
        elif len(data) < 2:
            raise PdfProblem("Type your signature.")
    except PdfProblem as exc:
        return _signer_page(request, s, r, token, error=str(exc))
    db.ex("""UPDATE sign_signers SET status = 'signed', signature_type = ?, signature_data = ?, signed_name = ?,
             signed_at = ?, ip = ?, user_agent = ? WHERE id = ? AND status != 'signed'""",
          (kind, data, name, _now(), _client_ip(request), request.headers.get("user-agent", "")[:300], s["id"]))
    event(r["id"], "signed", f"as {name} ({kind})", s["id"], request)
    remaining = [x for x in signers_of(r["id"]) if x["status"] != "signed"]
    if not remaining:
        finalize(r, request)
    return back(f"/sign/{token}")


async def sign_decline(request: Request):
    token = request.path_params["token"]
    s, r = _load(token)
    if not s:
        return _not_found(request)
    form = await form_checked(request)
    if not _code_ok(request, r, token) or r["status"] != "sent" or s["status"] == "signed":
        return back(f"/sign/{token}")
    reason = str(form.get("reason", "")).strip()[:500]
    db.ex("UPDATE sign_signers SET status = 'declined', decline_reason = ? WHERE id = ?", (reason, s["id"]))
    db.ex("UPDATE sign_requests SET status = 'declined' WHERE id = ?", (r["id"],))
    event(r["id"], "declined", reason, s["id"], request)
    business = db.get_business(r["business_id"])
    box = _sender_mailbox(business)
    notify = box["from_email"] if box else next((u["email"] for u in db.list_users(r["tenant_id"]) if u["role"] == "owner"), None)
    if notify:
        _deliver(business, "e-signing", notify, f"Declined: {r['title']} ({business['name']})",
                 f"{s['name']} declined to sign \"{r['title']}\".\n\nReason: {reason or 'none given'}",
                 related=f"sign:{r['id']}")
    return back(f"/sign/{token}")


async def sign_page_image(request: Request):
    token = request.path_params["token"]
    s, r = _load(token)
    if not s or not _code_ok(request, r, token) or r["status"] in ("voided",):
        return Response(status_code=404)
    try:
        png = page_png(Path(r["original_path"]), int(request.path_params["n"]))
    except PdfProblem:
        return Response(status_code=404)
    return Response(png, media_type="image/png", headers={"Cache-Control": "private, max-age=3600"})


async def sign_download(request: Request):
    token = request.path_params["token"]
    s, r = _load(token)
    if not s or not _code_ok(request, r, token) or r["status"] == "voided":
        return Response(status_code=404)
    path = r["final_path"] if r["status"] == "completed" and r["final_path"] else r["original_path"]
    suffix = " - signed" if r["status"] == "completed" else ""
    return FileResponse(path, filename=f"{r['title'][:80]}{suffix}.pdf", media_type="application/pdf")


routes = [
    Route("/esign", list_page),
    Route("/esign/new", new_page, methods=["GET", "POST"]),
    Route("/esign/{id:int}", detail_page),
    Route("/esign/{id:int}/prepare", prepare_page),
    Route("/esign/{id:int}/send", send_request, methods=["POST"]),
    Route("/esign/{id:int}/action", action, methods=["POST"]),
    Route("/esign/{id:int}/page/{n:int}.png", page_image),
    Route("/esign/{id:int}/file/{which}", download),
    Route("/sign/{token}", sign_page),
    Route("/sign/{token}", sign_submit, methods=["POST"]),
    Route("/sign/{token}/code", sign_code, methods=["POST"]),
    Route("/sign/{token}/decline", sign_decline, methods=["POST"]),
    Route("/sign/{token}/page/{n:int}.png", sign_page_image),
    Route("/sign/{token}/download", sign_download),
]
