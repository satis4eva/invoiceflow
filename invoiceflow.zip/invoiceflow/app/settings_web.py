"""Business settings: industry, matching tolerances, business rules, Peppol ID, API keys; plus the
e-invoicing API and the Peppol inbound webhook."""
import base64
import hashlib
import json
import secrets

from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from . import db, einvoice, industry, peppol, pipeline, rules
from .web import Ctx, back, flash, form_checked, guarded, render


def _f(v, default=0.0):
    try:
        return round(float(str(v).replace(",", "").replace("£", "").replace("%", "").strip()), 2)
    except (TypeError, ValueError):
        return default


@guarded("app")
async def rules_page(request: Request, c: Ctx):
    settings = rules.settings_for(c.business["id"])
    profile = industry.get(settings["industry"])
    fields = dict(rules.FIELDS)
    fields.update({f"extras.{k}": v for k, v in profile["header"].items()})
    return render(request, "rules.html", c, s=settings, profile=profile, PROFILES=industry.PROFILES,
                  ORDER=industry.ORDER, FIELDS=fields, OPS=rules.OPS, ACTIONS=rules.ACTIONS,
                  can_rules=c.can("rules"), can_match=c.can("matching"))


@guarded("manager")
async def rules_save(request: Request, c: Ctx):
    form = await form_checked(request)
    stored = db.business_settings(c.business["id"])
    action = form.get("action")
    if action == "industry":
        key = str(form.get("industry", "general"))
        if key in industry.PROFILES:
            stored["industry"] = key
            if form.get("starter") == "1":
                profile = industry.get(key)
                stored.update(profile["settings"])
                stored["rules"] = [dict(r, id=secrets.token_hex(4), enabled=True) for r in profile["rules"]]
            flash(request, f"{c.business['name']} is set up for {industry.get(key)['label']}."
                  + (" Starter rules and tolerances applied." if form.get("starter") == "1" else ""))
    elif action == "matching":
        stored.update({
            "match_type": "three_way" if form.get("match_type") == "three_way" else "two_way",
            "price_tol_pct": max(0.0, min(50.0, _f(form.get("price_tol_pct")))),
            "qty_tol_pct": max(0.0, min(50.0, _f(form.get("qty_tol_pct")))),
            "total_tol": max(0.0, _f(form.get("total_tol"), 1.0)),
            "carriage_allowance": max(0.0, _f(form.get("carriage_allowance"))),
            "require_po": form.get("require_po") == "1",
            "auto_approve_matched": form.get("auto_approve_matched") == "1",
            "po_approval_limit": max(0.0, _f(form.get("po_approval_limit"))),
            "po_prefix": (str(form.get("po_prefix", "PO-")).strip() or "PO-")[:10],
        })
        flash(request, "Matching and approval settings saved.")
    elif action == "add_rule":
        if not c.can("rules"):
            flash(request, "Business rules are part of Standard and above.", "warn")
            return back("/settings/rules")
        conds = []
        for i in range(3):
            field, op = str(form.get(f"field_{i}", "")), str(form.get(f"op_{i}", ""))
            if field and op in rules.OPS:
                conds.append({"field": field[:60], "op": op, "value": str(form.get(f"value_{i}", ""))[:100]})
        act = str(form.get("rule_action", ""))
        if not conds or act not in rules.ACTIONS:
            flash(request, "A rule needs at least one condition and an action.", "error")
            return back("/settings/rules")
        current = rules.settings_for(c.business["id"])["rules"]
        current.append({"id": secrets.token_hex(4), "name": str(form.get("name", "")).strip()[:120] or "Rule",
                        "when": conds, "action": act, "value": str(form.get("rule_value", "")).strip()[:40],
                        "message": str(form.get("message", "")).strip()[:200], "enabled": True})
        stored["rules"] = current[:50]
        flash(request, "Rule added. It applies to new invoices and when you re-check one.")
    elif action in ("toggle_rule", "delete_rule"):
        current = rules.settings_for(c.business["id"])["rules"]
        rid = str(form.get("rule_id", ""))
        if action == "delete_rule":
            current = [r for r in current if r.get("id", r.get("name")) != rid]
        else:
            for r in current:
                if r.get("id", r.get("name")) == rid:
                    r["enabled"] = not r.get("enabled", True)
        stored["rules"] = current
        flash(request, "Rules updated.")
    db.save_business_settings(c.business["id"], stored)
    return back("/settings/rules")


@guarded("manager")
async def recheck_all(request: Request, c: Ctx):
    await form_checked(request)
    n = 0
    for inv in db.list_invoices(c.business["id"]):
        if inv["status"] in ("needs_review", "ready"):
            data = {k: inv.get(k) for k in pipeline.FIELDS}
            data["source"] = inv.get("source")
            db.update_invoice(inv["id"], pipeline.assess(data, c.business["id"], inv["id"], inv["file_hash"],
                                                         **pipeline._features(c.tenant)))
            n += 1
    flash(request, f"Re-checked {n} invoice(s) waiting for review.")
    return back("/settings/rules")


# ---- Peppol ID and API keys --------------------------------------------------------------------

@guarded("manager")
async def peppol_save(request: Request, c: Ctx):
    form = await form_checked(request)
    pid = str(form.get("peppol_id", "")).strip()
    if pid and not peppol.valid_id(pid):
        flash(request, "A Peppol ID looks like 0088:5012345678900 (GLN) or 9932:GB123456789 (UK VAT).", "error")
        return back("/settings")
    if pid and db.q1("SELECT id FROM businesses WHERE peppol_id = ? AND id != ?", (pid, c.business["id"])):
        flash(request, "That Peppol ID is already used by another business.", "error")
        return back("/settings")
    db.ex("UPDATE businesses SET peppol_id = ? WHERE id = ?", (pid or None, c.business["id"]))
    flash(request, "Peppol ID saved." if pid else "Peppol ID removed.")
    return back("/settings")


@guarded("manager")
async def api_key_action(request: Request, c: Ctx):
    form = await form_checked(request)
    if not c.can("api"):
        flash(request, "API access is part of Advanced and Practice.", "warn")
        return back("/settings")
    if form.get("action") == "create":
        raw = "ifk_" + secrets.token_urlsafe(32)
        db.ex("INSERT INTO api_keys (tenant_id, business_id, label, key_hash, prefix, created_by, created_at) "
              "VALUES (?, ?, ?, ?, ?, ?, ?)", (c.tenant["id"], c.business["id"], str(form.get("label", "")).strip()[:60] or "API key",
                                                hashlib.sha256(raw.encode()).hexdigest(), raw[:10], c.who, db.now()))
        flash(request, f"New API key (copy it now, it won't be shown again): {raw}", "warn")
    elif form.get("action") == "revoke":
        db.ex("DELETE FROM api_keys WHERE id = ? AND business_id = ?", (int(form.get("key_id") or 0), c.business["id"]))
        flash(request, "API key revoked.")
    return back("/settings")


def _api_business(request: Request) -> dict | None:
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        return None
    key = db.q1("SELECT * FROM api_keys WHERE key_hash = ?", (hashlib.sha256(auth[7:].strip().encode()).hexdigest(),))
    if not key:
        return None
    from . import accounts
    tenant = db.get_tenant(key["tenant_id"])
    if not tenant or not accounts.access(tenant)["ok"] or not accounts.has_feature(tenant, "api"):
        return None
    db.ex("UPDATE api_keys SET last_used = ? WHERE id = ?", (db.now(), key["id"]))
    return db.get_business(key["business_id"])


async def api_invoices(request: Request):
    """GET: list invoices. POST: send an invoice (multipart 'file', or raw XML/PDF body with a filename header)."""
    business = _api_business(request)
    if not business:
        return JSONResponse({"error": "Invalid or missing API key"}, status_code=401)
    if request.method == "GET":
        status = request.query_params.get("status")
        invs = db.list_invoices(business["id"], status)
        keep = ("id", "status", "supplier_name", "invoice_number", "invoice_date", "due_date", "po_number", "currency",
                "net_total", "vat_total", "gross_total", "match_status", "line_items", "extras", "created_at")
        return JSONResponse([{k: i.get(k) for k in keep} for i in invs[:500]])
    ctype = request.headers.get("content-type", "")
    if ctype.startswith("multipart/form-data"):
        form = await request.form()
        f = form.get("file")
        if not getattr(f, "filename", ""):
            return JSONResponse({"error": "Send the document in a 'file' field"}, status_code=400)
        name, content = f.filename, await f.read()
    else:
        content = await request.body()
        name = request.headers.get("x-filename") or ("invoice.xml" if b"<" in content[:10] else "invoice.pdf")
    try:
        inv_id = pipeline.process_upload(business, name, content, "API", source="api")
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)
    inv = db.get_invoice(inv_id)
    return JSONResponse({"id": inv_id, "status": inv["status"], "match_status": inv.get("match_status"),
                         "issues": inv["issues"]}, status_code=201)


async def peppol_inbound(request: Request):
    secret = peppol.webhook_secret()
    if not secret or not secrets.compare_digest(request.headers.get("x-peppol-secret", ""), secret):
        return JSONResponse({"error": "unauthorised"}, status_code=401)
    try:
        payload = json.loads(await request.body())
        recipient = str(payload.get("recipient", "")).strip()
        xml = base64.b64decode(payload.get("document", ""))
    except (ValueError, TypeError):
        return JSONResponse({"error": "bad payload"}, status_code=400)
    business = db.q1("SELECT * FROM businesses WHERE peppol_id = ?", (recipient,))
    if not business:
        return JSONResponse({"error": "unknown recipient"}, status_code=404)
    if not einvoice.is_einvoice(xml):
        return JSONResponse({"error": "not an invoice document"}, status_code=422)
    inv_id = pipeline.process_upload(business, f"peppol-{payload.get('id') or db.now()[:19]}.xml".replace(":", ""),
                                     xml, "Peppol network", source="peppol")
    return JSONResponse({"received": True, "invoice_id": inv_id})


routes = [
    Route("/settings/rules", rules_page),
    Route("/settings/rules", rules_save, methods=["POST"]),
    Route("/settings/recheck", recheck_all, methods=["POST"]),
    Route("/settings/peppol", peppol_save, methods=["POST"]),
    Route("/settings/api-keys", api_key_action, methods=["POST"]),
    Route("/api/v1/invoices", api_invoices, methods=["GET", "POST"]),
    Route("/peppol/inbound", peppol_inbound, methods=["POST"]),
]
