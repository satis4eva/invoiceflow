"""Invoice data extraction.

Primary engine: Claude (reads PDFs and photos/scans directly, so no separate
OCR step is needed). Fallback engine: a rule-based parser over the PDF text
layer, used when no API key is configured or the API call fails.
"""
import base64
import json
import re
import ssl
import urllib.error
import urllib.request
from datetime import date, datetime
from pathlib import Path

from . import config

SUPPORTED = {
    ".pdf": "application/pdf",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
}

# JSON schema the model must fill in (forced tool call = structured output)
INVOICE_TOOL = {
    "name": "record_invoice",
    "description": "Record the data extracted from a supplier invoice, credit note or receipt.",
    "input_schema": {
        "type": "object",
        "properties": {
            "document_type": {"type": "string", "enum": ["invoice", "credit_note", "receipt", "statement", "other"]},
            "supplier_name": {"type": "string", "description": "Company that issued the document (the seller)"},
            "supplier_vat_number": {"type": ["string", "null"], "description": "Seller VAT registration number, e.g. GB123456789"},
            "supplier_email": {"type": ["string", "null"]},
            "supplier_address": {"type": ["string", "null"]},
            "invoice_number": {"type": ["string", "null"]},
            "invoice_date": {"type": ["string", "null"], "description": "ISO format YYYY-MM-DD. UK documents use day/month order."},
            "due_date": {"type": ["string", "null"], "description": "ISO format YYYY-MM-DD"},
            "po_number": {"type": ["string", "null"], "description": "Purchase order reference if shown"},
            "currency": {"type": "string", "description": "ISO 4217 code, e.g. GBP, EUR"},
            "net_total": {"type": ["number", "null"], "description": "Total before VAT"},
            "vat_total": {"type": ["number", "null"]},
            "gross_total": {"type": ["number", "null"], "description": "Amount payable including VAT"},
            "line_items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "description": {"type": "string"},
                        "quantity": {"type": ["number", "null"]},
                        "unit_price": {"type": ["number", "null"], "description": "Net unit price"},
                        "net_amount": {"type": ["number", "null"]},
                        "vat_rate": {"type": ["number", "null"], "description": "Percent, e.g. 20, 5, 0"},
                        "vat_amount": {"type": ["number", "null"]},
                    },
                    "required": ["description"],
                },
            },
            "confidence": {"type": "number", "description": "0-1, how confident you are the extraction is complete and correct"},
            "notes": {"type": ["string", "null"], "description": "Anything unclear, illegible or unusual"},
        },
        "required": ["document_type", "supplier_name", "currency", "line_items", "confidence"],
    },
}

PROMPT = """Extract the data from this supplier document for an accounts payable system in the UK.
Rules:
- The supplier is the company issuing the document, not the customer it is addressed to.
- Use day/month/year when reading UK dates; return dates as YYYY-MM-DD.
- Amounts are plain numbers without currency symbols. Credit notes use positive numbers (document_type marks them).
- If there are no itemised lines, create one line item with the overall description and net amount.
- Never invent values; use null when something is not on the document.
Call the record_invoice tool with the result."""


class ExtractionError(Exception):
    pass


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def extract(path: Path) -> dict:
    """Return a normalised invoice dict plus 'extraction_method'."""
    suffix = path.suffix.lower()
    if suffix not in SUPPORTED:
        raise ExtractionError(f"Unsupported file type {suffix}")

    errors = []
    if config.ANTHROPIC_API_KEY:
        try:
            data = _extract_with_claude(path, SUPPORTED[suffix])
            data["extraction_method"] = f"ai:{config.EXTRACTION_MODEL}"
            return normalise(data)
        except Exception as exc:  # fall through to the rule-based parser
            errors.append(f"AI extraction failed: {exc}")

    if suffix == ".pdf":
        data = _extract_from_pdf_text(path)
        data["extraction_method"] = "text-parser"
        if errors:
            data["notes"] = "; ".join(filter(None, [data.get("notes"), *errors]))
        return normalise(data)

    raise ExtractionError(
        "; ".join(errors) or "Images and scanned documents need AI extraction - set ANTHROPIC_API_KEY."
    )


# ---------------------------------------------------------------------------
# Claude extraction
# ---------------------------------------------------------------------------

def _extract_with_claude(path: Path, media_type: str) -> dict:
    b64 = base64.standard_b64encode(path.read_bytes()).decode()
    block_type = "document" if media_type == "application/pdf" else "image"
    body = {
        "model": config.EXTRACTION_MODEL,
        "max_tokens": 4096,
        "tools": [INVOICE_TOOL],
        "tool_choice": {"type": "tool", "name": "record_invoice"},
        "messages": [{
            "role": "user",
            "content": [
                {"type": block_type, "source": {"type": "base64", "media_type": media_type, "data": b64}},
                {"type": "text", "text": PROMPT},
            ],
        }],
    }
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps(body).encode(),
        headers={
            "x-api-key": config.ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120, context=ssl.create_default_context()) as resp:
            payload = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raise ExtractionError(f"API {exc.code}: {exc.read()[:300]!r}") from exc

    for block in payload.get("content", []):
        if block.get("type") == "tool_use" and block.get("name") == "record_invoice":
            return block["input"]
    raise ExtractionError("Model did not return structured data")


# ---------------------------------------------------------------------------
# Rule-based fallback for digital PDFs
# ---------------------------------------------------------------------------

DATE_PATTERNS = [
    (r"\d{1,2}/\d{1,2}/\d{4}", "%d/%m/%Y"),
    (r"\d{1,2}-\d{1,2}-\d{4}", "%d-%m-%Y"),
    (r"\d{1,2}\.\d{1,2}\.\d{4}", "%d.%m.%Y"),
    (r"\d{4}-\d{2}-\d{2}", "%Y-%m-%d"),
    (r"\d{1,2} [A-Za-z]{3,9} \d{4}", None),  # 3 March 2026 / 3 Mar 2026
]
MONEY = r"[£€$]?\s?(-?[\d,]+\.\d{2})"
HEADER_WORDS = {"invoice", "tax invoice", "vat invoice", "credit note", "receipt", "statement"}


def _parse_date(text: str | None) -> str | None:
    if not text:
        return None
    text = text.strip()
    for pattern, fmt in DATE_PATTERNS:
        m = re.search(pattern, text)
        if not m:
            continue
        s = m.group(0)
        fmts = [fmt] if fmt else ["%d %B %Y", "%d %b %Y"]
        for f in fmts:
            try:
                return datetime.strptime(s, f).date().isoformat()
            except ValueError:
                continue
    return None


def _money(s: str) -> float:
    return float(s.replace(",", ""))


def _find(text: str, pattern: str, flags=re.I) -> str | None:
    m = re.search(pattern, text, flags)
    return m.group(1).strip() if m else None


def _extract_from_pdf_text(path: Path) -> dict:
    import pdfplumber

    with pdfplumber.open(path) as pdf:
        text = "\n".join((p.extract_text() or "") for p in pdf.pages)
        tables = [t for p in pdf.pages for t in (p.extract_tables() or [])]

    if len(text.strip()) < 20:
        raise ExtractionError("No text layer found (scanned document) - AI extraction is required.")

    lines = [l.strip() for l in text.splitlines() if l.strip()]
    supplier = next((l for l in lines if l.lower() not in HEADER_WORDS), "")

    lowered = text.lower()
    doc_type = "credit_note" if "credit note" in lowered else "receipt" if "receipt" in lowered[:200] else "invoice"

    vat_no = _find(text, r"VAT\s*(?:Reg(?:istration)?\.?)?\s*(?:No\.?|Number)?\s*[:#]?\s*((?:GB)?\s?\d{3}\s?\d{4}\s?\d{2}(?:\s?\d{3})?)")
    data = {
        "document_type": doc_type,
        "supplier_name": supplier,
        "supplier_vat_number": vat_no,
        "supplier_email": _find(text, r"([\w.+-]+@[\w-]+\.[\w.]+)"),
        "supplier_address": None,
        "invoice_number": _find(text, r"(?:Invoice|Credit Note|Document)\s*(?:No\.?|Number|#)\s*[:#]?\s*([A-Z0-9][A-Z0-9\-/]*)"),
        "invoice_date": _parse_date(_find(text, r"(?:Invoice|Tax Point|Issue)?\s*Date\s*[:]?\s*([^\n]+)")),
        "due_date": _parse_date(_find(text, r"(?:Due|Payment)\s*(?:Date|By)\s*[:]?\s*([^\n]+)")),
        "po_number": _find(text, r"(?:PO|Purchase Order)\s*(?:No\.?|Number|Ref\.?)?\s*[:#]?\s*([A-Z0-9\-/]+)"),
        "currency": "EUR" if "€" in text else "USD" if "$" in text and "£" not in text else config.DEFAULT_CURRENCY,
        "net_total": None,
        "vat_total": None,
        "gross_total": None,
        "line_items": [],
        "confidence": 0.6,
        "notes": "Extracted by rule-based parser; please check carefully.",
    }

    net = _find(text, r"(?:Sub\s?-?total|Net\s*(?:Total|Amount)?|Total\s*Net)\s*[:]?\s*" + MONEY)
    vat = _find(text, r"(?:Total\s*)?VAT(?:\s*@?\s*\d+%?)?\s*(?:Amount)?\s*[:]?\s*" + MONEY)
    gross = None
    for label in (r"(?:Total|Amount|Balance)\s*(?:Due|Payable)", r"(?<![A-Za-z])Total\s*(?:inc\.?\s*VAT|GBP|Amount)",
                  r"(?<![A-Za-z])Total"):
        gross = _find(text, label + r"\s*[:]?\s*" + MONEY)
        if gross:
            break
    data["net_total"] = _money(net) if net else None
    data["vat_total"] = _money(vat) if vat else None
    data["gross_total"] = _money(gross) if gross else None

    data["line_items"] = _lines_from_tables(tables)
    if not data["line_items"] and data["net_total"] is not None:
        data["line_items"] = [{
            "description": f"Invoice {data['invoice_number'] or ''}".strip(),
            "quantity": 1, "unit_price": data["net_total"], "net_amount": data["net_total"],
            "vat_rate": None, "vat_amount": data["vat_total"],
        }]
    return data


def _lines_from_tables(tables: list) -> list[dict]:
    """Find a table whose header looks like line items and map its columns."""
    for table in tables:
        if not table or len(table) < 2:
            continue
        header = [(c or "").strip().lower() for c in table[0]]

        def col(*names):
            for i, h in enumerate(header):
                if any(n in h for n in names):
                    return i
            return None

        i_desc = col("description", "item", "details", "product", "service")
        i_qty = col("qty", "quantity")
        i_unit = col("unit", "price", "rate")
        i_vat_rate = col("vat %", "vat rate", "tax %", "vat%")
        i_net = col("net", "amount", "total")
        if i_desc is None or i_net is None:
            continue
        items = []
        for row in table[1:]:
            cells = [(c or "").strip() for c in row]
            if not cells[i_desc] or cells[i_desc].lower().startswith(("sub", "total", "vat")):
                continue

            def num(i):
                if i is None or i >= len(cells):
                    return None
                m = re.search(r"-?[\d,]+(?:\.\d+)?", cells[i])
                return float(m.group(0).replace(",", "")) if m else None

            items.append({
                "description": cells[i_desc],
                "quantity": num(i_qty),
                "unit_price": num(i_unit) if i_unit != i_net else None,
                "net_amount": num(i_net),
                "vat_rate": num(i_vat_rate),
                "vat_amount": None,
            })
        if items:
            return items
    return []


# ---------------------------------------------------------------------------
# Normalisation shared by both engines
# ---------------------------------------------------------------------------

def _num(v):
    if v is None or v == "":
        return None
    try:
        return round(float(str(v).replace(",", "").replace("£", "").replace("€", "")), 2)
    except ValueError:
        return None


def _iso(v):
    if not v:
        return None
    try:
        return date.fromisoformat(str(v)[:10]).isoformat()
    except ValueError:
        return _parse_date(str(v))


def normalise(data: dict) -> dict:
    out = dict(data)
    for k in ("net_total", "vat_total", "gross_total"):
        out[k] = _num(out.get(k))
    for k in ("invoice_date", "due_date"):
        out[k] = _iso(out.get(k))
    out["currency"] = (out.get("currency") or config.DEFAULT_CURRENCY).upper()[:3]
    if out.get("supplier_vat_number"):
        out["supplier_vat_number"] = re.sub(r"\s", "", out["supplier_vat_number"]).upper()
    if out.get("invoice_number"):
        out["invoice_number"] = str(out["invoice_number"]).strip()

    items = []
    for li in out.get("line_items") or []:
        item = {
            "description": (li.get("description") or "").strip(),
            "quantity": _num(li.get("quantity")),
            "unit_price": _num(li.get("unit_price")),
            "net_amount": _num(li.get("net_amount")),
            "vat_rate": _num(li.get("vat_rate")),
            "vat_amount": _num(li.get("vat_amount")),
            "account_code": li.get("account_code"),
        }
        if item["net_amount"] is None and item["quantity"] is not None and item["unit_price"] is not None:
            item["net_amount"] = round(item["quantity"] * item["unit_price"], 2)
        if item["quantity"] is None:
            item["quantity"] = 1
        if item["unit_price"] is None and item["net_amount"] is not None and item["quantity"]:
            item["unit_price"] = round(item["net_amount"] / item["quantity"], 4)
        items.append(item)
    out["line_items"] = items

    # Derive missing totals
    nets = [i["net_amount"] for i in items if i["net_amount"] is not None]
    if out["net_total"] is None and nets:
        out["net_total"] = round(sum(nets), 2)
    if out["gross_total"] is None and out["net_total"] is not None and out["vat_total"] is not None:
        out["gross_total"] = round(out["net_total"] + out["vat_total"], 2)
    if out["vat_total"] is None and out["net_total"] is not None and out["gross_total"] is not None:
        out["vat_total"] = round(out["gross_total"] - out["net_total"], 2)
    if out["net_total"] is None and out["gross_total"] is not None and out["vat_total"] is not None:
        out["net_total"] = round(out["gross_total"] - out["vat_total"], 2)

    # Infer a single VAT rate for lines that don't state one
    if out["net_total"] and out["vat_total"] is not None:
        implied = round(out["vat_total"] / out["net_total"] * 100)
        rate = next((r for r in (20, 5, 0) if abs(implied - r) <= 1), None)
        for i in items:
            if i["vat_rate"] is None and rate is not None:
                i["vat_rate"] = float(rate)
    for i in items:
        if i["vat_amount"] is None and i["vat_rate"] is not None and i["net_amount"] is not None:
            i["vat_amount"] = round(i["net_amount"] * i["vat_rate"] / 100, 2)

    out["confidence"] = float(out.get("confidence") or 0.5)
    return out
