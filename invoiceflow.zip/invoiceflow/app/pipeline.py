"""Upload -> extract -> fill gaps -> validate -> industry checks -> match -> business rules -> status.
Everything is scoped to one business."""
import hashlib
import re
import uuid
from datetime import date, timedelta
from pathlib import Path

from . import config, db, extraction, industry, matching, rules, validation

FIELDS = ("document_type", "supplier_name", "supplier_vat_number", "supplier_email", "supplier_address",
          "invoice_number", "invoice_date", "due_date", "po_number", "currency",
          "net_total", "vat_total", "gross_total", "line_items", "confidence", "extras")
ACCEPTED = set(extraction.SUPPORTED) | {".xml"}


def _safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", Path(name).name)[:120] or "invoice"


def apply_defaults(data: dict, business_id: int, use_memory: bool = True) -> dict:
    """Fill gaps from the business's supplier record and company defaults."""
    supplier = db.get_supplier(business_id, data.get("supplier_name") or "") if use_memory else None
    for li in data.get("line_items") or []:
        if not li.get("account_code") and supplier and supplier.get("account_code"):
            li["account_code"] = supplier["account_code"]
    if supplier and not data.get("supplier_vat_number") and supplier.get("vat_number"):
        data["supplier_vat_number"] = supplier["vat_number"]
    if data.get("invoice_date") and not data.get("due_date"):
        terms = (supplier or {}).get("terms_days") or config.DEFAULT_PAYMENT_TERMS_DAYS
        try:
            data["due_date"] = (date.fromisoformat(data["invoice_date"]) + timedelta(days=int(terms))).isoformat()
        except ValueError:
            pass
    return data


def assess(data: dict, business_id: int, invoice_id: int | None, file_hash: str | None,
           use_memory: bool = True, matching_on: bool = True, rules_on: bool = True) -> dict:
    """Run every check. Returns values to store: issues, status, po_id, match_status, match_detail."""
    settings = rules.settings_for(business_id)
    supplier = db.get_supplier(business_id, data.get("supplier_name") or "") if use_memory else None
    po, detail, match_issues = (None, {"status": "off", "lines": []}, [])
    if matching_on:
        po = matching.find_po(business_id, data)
        filled = matching.fill_gaps(data, po, supplier)
    else:
        filled = []
    issues = validation.validate(data, invoice_id, file_hash, business_id)
    issues += industry.checks(data, settings["industry"])
    if matching_on:
        po, detail, match_issues = matching.run(data, business_id, settings, invoice_id)
        issues += match_issues
    if filled:
        issues.append(validation.issue("info", "filled", "Filled in from your records: " + ", ".join(filled)))
    auto = False
    if rules_on:
        data["match_status"] = detail.get("status")
        data["source"] = data.get("source")
        rule_issues, auto = rules.apply(data, settings)
        issues += rule_issues
        data.pop("match_status", None)
    blocking = any(i["level"] in ("error", "warning") for i in issues)
    status = validation.status_for(issues)
    auto_ok = (auto or (settings.get("auto_approve_matched") and detail.get("status") == "matched")) and not blocking \
        and not any(i["code"] == "needs_manager" for i in issues)
    if auto_ok:
        status = "approved"
        issues.append(validation.issue("info", "auto_approved", "Approved automatically by your business rules"))
    return {"issues": issues, "status": status, "po_id": po["id"] if po else None,
            "match_status": detail.get("status"), "match_detail": detail}


def _features(tenant: dict | None) -> dict:
    from . import accounts
    if not tenant:
        return {"use_memory": True, "matching_on": True, "rules_on": True}
    return {"use_memory": accounts.has_feature(tenant, "supplier_memory"),
            "matching_on": accounts.has_feature(tenant, "matching"),
            "rules_on": accounts.has_feature(tenant, "rules")}


def process_upload(business: dict, filename: str, content: bytes, user: str = "system",
                   use_memory: bool = True, source: str = "upload", note: str | None = None) -> int:
    suffix = Path(filename).suffix.lower()
    if suffix not in ACCEPTED:
        raise extraction.ExtractionError(f"{filename}: unsupported file type ({suffix})")
    if len(content) > 20 * 1024 * 1024:
        raise extraction.ExtractionError(f"{filename}: larger than 20 MB")
    file_hash = hashlib.sha256(content).hexdigest()
    folder = config.UPLOAD_DIR / f"b{business['id']}"
    folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"{uuid.uuid4().hex}_{_safe_name(filename)}"
    stored.write_bytes(content)
    tenant = db.get_tenant(business["tenant_id"])
    feats = _features(tenant)
    feats["use_memory"] = feats["use_memory"] and use_memory
    profile = industry.get(rules.settings_for(business["id"])["industry"])

    bid = business["id"]
    base = {"filename": filename, "stored_path": str(stored), "file_hash": file_hash,
            "business_id": bid, "tenant_id": business["tenant_id"], "source": source,
            "client_note": (note or "").strip()[:500] or None}
    try:
        data = extraction.extract(stored, profile)
        attachment = data.pop("_attachment", None)
        if attachment and suffix == ".xml":  # keep the supplier's PDF copy next to the e-invoice for viewing
            pdf = stored.with_suffix(".pdf")
            pdf.write_bytes(attachment)
            data.setdefault("extras", {})["visual_copy"] = pdf.name
        data = apply_defaults(data, bid, feats["use_memory"])
    except Exception as exc:
        inv_id = db.insert_invoice({
            **base, "status": "needs_review", "line_items": [],
            "issues": [validation.issue("error", "extraction_failed", str(exc))],
            "extraction_method": "failed",
        })
        db.audit(inv_id, "upload", f"Extraction failed: {exc}", user)
        return inv_id

    if data.get("document_type") == "delivery_note":
        data.setdefault("extras", {})
    data["source"] = source
    result = assess(data, bid, None, file_hash, **feats)
    values = {**base, **{k: data.get(k) for k in FIELDS}, **result,
              "raw": {k: v for k, v in data.items() if k not in FIELDS and not k.startswith("_")},
              "extraction_method": data.get("extraction_method")}
    inv_id = db.insert_invoice(values)
    db.audit(inv_id, "upload", f"Read via {data.get('extraction_method')}", user)
    if result["status"] == "approved":
        db.audit(inv_id, "approve", "automatically by business rules", "system")
    return inv_id


def reprocess(inv: dict, user: str = "system", use_memory: bool = True) -> None:
    business = db.get_business(inv["business_id"])
    feats = _features(db.get_tenant(business["tenant_id"]))
    feats["use_memory"] = feats["use_memory"] and use_memory
    profile = industry.get(rules.settings_for(business["id"])["industry"])
    data = extraction.extract(Path(inv["stored_path"]), profile)
    data.pop("_attachment", None)
    data = apply_defaults(data, inv["business_id"], feats["use_memory"])
    data["source"] = inv.get("source")
    result = assess(data, inv["business_id"], inv["id"], inv["file_hash"], **feats)
    db.update_invoice(inv["id"], {**{k: data.get(k) for k in FIELDS}, **result,
                                  "extraction_method": data.get("extraction_method")})
    db.audit(inv["id"], "reprocess", f"Re-read via {data.get('extraction_method')}", user)


def _f(v):
    v = (v or "").strip().replace(",", "").replace("£", "")
    try:
        return round(float(v), 4) if v else None
    except ValueError:
        return None


def save_edits(inv: dict, form: dict, user: str = "system", use_memory: bool = True) -> list[dict]:
    """Apply reviewer edits from the web form and re-run every check."""
    bid = inv["business_id"]
    settings = rules.settings_for(bid)
    profile = industry.get(settings["industry"])
    data = {
        "document_type": form.get("document_type") or "invoice",
        "supplier_name": (form.get("supplier_name") or "").strip(),
        "supplier_vat_number": re.sub(r"\s", "", form.get("supplier_vat_number") or "").upper() or None,
        "supplier_email": (form.get("supplier_email") or "").strip() or None,
        "invoice_number": (form.get("invoice_number") or "").strip() or None,
        "invoice_date": form.get("invoice_date") or None,
        "due_date": form.get("due_date") or None,
        "po_number": (form.get("po_number") or "").strip() or None,
        "currency": (form.get("currency") or config.DEFAULT_CURRENCY).upper()[:3],
        "net_total": _f(form.get("net_total")),
        "vat_total": _f(form.get("vat_total")),
        "gross_total": _f(form.get("gross_total")),
        "confidence": 1.0,  # a human has checked it
        "source": inv.get("source"),
    }
    extras = dict(inv.get("extras") or {})
    for key in profile["header"]:
        if f"x_{key}" in form:
            val = str(form.get(f"x_{key}") or "").strip()[:200]
            if val:
                extras[key] = val
            else:
                extras.pop(key, None)
    data["extras"] = extras
    lines = []
    n = min(int(form.get("line_count") or 0), 500)
    line_keys = [k for k in profile["line"] if k not in ("code", "unit")]
    for i in range(n):
        desc = (form.get(f"line_{i}_description") or "").strip()
        if not desc or form.get(f"line_{i}_delete"):
            continue
        lx = {k: str(form.get(f"line_{i}_x_{k}") or "").strip()[:100] for k in line_keys}
        lines.append({
            "description": desc,
            "code": (form.get(f"line_{i}_code") or "").strip() or None,
            "unit": (form.get(f"line_{i}_unit") or "").strip() or None,
            "quantity": _f(form.get(f"line_{i}_quantity")) or 1,
            "unit_price": _f(form.get(f"line_{i}_unit_price")),
            "net_amount": _f(form.get(f"line_{i}_net_amount")),
            "vat_rate": _f(form.get(f"line_{i}_vat_rate")),
            "vat_amount": _f(form.get(f"line_{i}_vat_amount")),
            "account_code": (form.get(f"line_{i}_account_code") or "").strip() or None,
            "extras": {k: v for k, v in lx.items() if v},
        })
    data["line_items"] = lines

    feats = _features(db.get_tenant(inv["tenant_id"]))
    feats["use_memory"] = feats["use_memory"] and use_memory
    result = assess(data, bid, inv["id"], inv["file_hash"], **feats)
    if inv["status"] == "posted":
        result["status"] = "posted"
    elif result["status"] == "approved":
        result["status"] = "ready"  # edits never approve on their own; the reviewer clicks Approve
        result["issues"] = [i for i in result["issues"] if i["code"] != "auto_approved"]
    data.pop("source", None)
    db.update_invoice(inv["id"], {**data, **result})
    db.audit(inv["id"], "edit", "Fields updated by reviewer", user)

    if feats["use_memory"]:  # learn the supplier's coding for next time
        codes = {l["account_code"] for l in lines if l.get("account_code")}
        if len(codes) == 1:
            db.upsert_supplier(bid, data["supplier_name"], codes.pop(), data["supplier_vat_number"])
        elif data["supplier_vat_number"]:
            db.upsert_supplier(bid, data["supplier_name"], None, data["supplier_vat_number"])
    return result["issues"]


def approve(inv: dict, user: str = "system", role: str = "owner") -> tuple[bool, str]:
    inv = db.get_invoice(inv["id"])
    feats = _features(db.get_tenant(inv["tenant_id"]))
    data = {k: inv.get(k) for k in FIELDS}
    data["source"] = inv.get("source")
    result = assess(data, inv["business_id"], inv["id"], inv["file_hash"], **feats)
    issues = [i for i in result["issues"] if i["code"] != "auto_approved"]
    errors = validation.blocking(issues)
    if errors:
        db.update_invoice(inv["id"], {"issues": issues, "status": "needs_review", "po_id": result["po_id"],
                                      "match_status": result["match_status"], "match_detail": result["match_detail"]})
        return False, "Fix the errors before approving: " + "; ".join(e["message"] for e in errors)
    if role not in ("owner", "admin") and any(i["code"] == "needs_manager" for i in issues):
        msg = next(i["message"] for i in issues if i["code"] == "needs_manager")
        return False, f"{msg}. Ask an owner or admin to approve it."
    db.update_invoice(inv["id"], {"issues": issues, "status": "approved", "po_id": result["po_id"],
                                  "match_status": result["match_status"], "match_detail": result["match_detail"]})
    db.audit(inv["id"], "approve", "", user)
    return True, "Approved"


def reject(inv: dict, reason: str, user: str = "system") -> None:
    db.update_invoice(inv["id"], {"status": "rejected"})
    db.audit(inv["id"], "reject", reason, user)
