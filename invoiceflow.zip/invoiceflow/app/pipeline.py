"""Glue between upload, extraction, validation and storage."""
import hashlib
import re
import uuid
from datetime import date, timedelta
from pathlib import Path

from . import config, db, extraction, validation

FIELDS = ("document_type", "supplier_name", "supplier_vat_number", "supplier_email", "supplier_address",
          "invoice_number", "invoice_date", "due_date", "po_number", "currency",
          "net_total", "vat_total", "gross_total", "line_items", "confidence")


def _safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", Path(name).name)[:120] or "invoice"


def apply_defaults(data: dict) -> dict:
    """Fill gaps from supplier history and company defaults."""
    supplier = db.get_supplier(data.get("supplier_name") or "")
    code = (supplier or {}).get("account_code") or config.DEFAULT_EXPENSE_ACCOUNT
    for li in data.get("line_items") or []:
        if not li.get("account_code"):
            li["account_code"] = code if supplier and supplier.get("account_code") else None
    if supplier and not data.get("supplier_vat_number") and supplier.get("vat_number"):
        data["supplier_vat_number"] = supplier["vat_number"]
    if data.get("invoice_date") and not data.get("due_date"):
        d = date.fromisoformat(data["invoice_date"]) + timedelta(days=config.DEFAULT_PAYMENT_TERMS_DAYS)
        data["due_date"] = d.isoformat()
    return data


def process_upload(filename: str, content: bytes, user: str = "system") -> int:
    suffix = Path(filename).suffix.lower()
    if suffix not in extraction.SUPPORTED:
        raise extraction.ExtractionError(f"{filename}: unsupported file type ({suffix})")
    file_hash = hashlib.sha256(content).hexdigest()
    stored = config.UPLOAD_DIR / f"{uuid.uuid4().hex}_{_safe_name(filename)}"
    stored.write_bytes(content)

    base = {"filename": filename, "stored_path": str(stored), "file_hash": file_hash}
    try:
        data = apply_defaults(extraction.extract(stored))
    except Exception as exc:
        inv_id = db.insert_invoice({
            **base, "status": "needs_review", "line_items": [],
            "issues": [validation.issue("error", "extraction_failed", str(exc))],
            "extraction_method": "failed",
        })
        db.audit(inv_id, "upload", f"Extraction failed: {exc}", user)
        return inv_id

    issues = validation.validate(data, None, file_hash)
    values = {**base, **{k: data.get(k) for k in FIELDS}}
    values.update({
        "status": validation.status_for(issues),
        "issues": issues,
        "raw": {k: v for k, v in data.items() if k not in FIELDS},
        "extraction_method": data.get("extraction_method"),
    })
    inv_id = db.insert_invoice(values)
    db.audit(inv_id, "upload", f"Extracted via {data.get('extraction_method')}", user)
    return inv_id


def reprocess(invoice_id: int, user: str = "system") -> None:
    inv = db.get_invoice(invoice_id)
    data = apply_defaults(extraction.extract(Path(inv["stored_path"])))
    issues = validation.validate(data, invoice_id, inv["file_hash"])
    db.update_invoice(invoice_id, {**{k: data.get(k) for k in FIELDS},
                                   "issues": issues, "status": validation.status_for(issues),
                                   "extraction_method": data.get("extraction_method")})
    db.audit(invoice_id, "reprocess", f"Re-extracted via {data.get('extraction_method')}", user)


def _f(v):
    v = (v or "").strip().replace(",", "").replace("£", "")
    try:
        return round(float(v), 2) if v else None
    except ValueError:
        return None


def save_edits(invoice_id: int, form: dict, user: str = "system") -> list[dict]:
    """Apply reviewer edits from the web form and re-run validation."""
    inv = db.get_invoice(invoice_id)
    data = {
        "document_type": form.get("document_type") or "invoice",
        "supplier_name": (form.get("supplier_name") or "").strip(),
        "supplier_vat_number": re.sub(r"\s", "", form.get("supplier_vat_number") or "").upper() or None,
        "supplier_email": (form.get("supplier_email") or "").strip() or None,
        "invoice_number": (form.get("invoice_number") or "").strip() or None,
        "invoice_date": form.get("invoice_date") or None,
        "due_date": form.get("due_date") or None,
        "po_number": (form.get("po_number") or "").strip() or None,
        "currency": (form.get("currency") or config.DEFAULT_CURRENCY).upper()[:3],
        "net_total": _f(form.get("net_total")),
        "vat_total": _f(form.get("vat_total")),
        "gross_total": _f(form.get("gross_total")),
        "confidence": 1.0,  # a human has checked it
    }
    lines = []
    n = int(form.get("line_count") or 0)
    for i in range(n):
        desc = (form.get(f"line_{i}_description") or "").strip()
        if not desc or form.get(f"line_{i}_delete"):
            continue
        lines.append({
            "description": desc,
            "quantity": _f(form.get(f"line_{i}_quantity")) or 1,
            "unit_price": _f(form.get(f"line_{i}_unit_price")),
            "net_amount": _f(form.get(f"line_{i}_net_amount")),
            "vat_rate": _f(form.get(f"line_{i}_vat_rate")),
            "vat_amount": _f(form.get(f"line_{i}_vat_amount")),
            "account_code": (form.get(f"line_{i}_account_code") or "").strip() or None,
        })
    data["line_items"] = lines

    issues = validation.validate(data, invoice_id, inv["file_hash"])
    status = inv["status"] if inv["status"] in ("posted",) else validation.status_for(issues)
    db.update_invoice(invoice_id, {**data, "issues": issues, "status": status})
    db.audit(invoice_id, "edit", "Fields updated by reviewer", user)

    # Learn the supplier's coding for next time
    codes = {l["account_code"] for l in lines if l.get("account_code")}
    if len(codes) == 1:
        db.upsert_supplier(data["supplier_name"], codes.pop(), data["supplier_vat_number"])
    elif data["supplier_vat_number"]:
        db.upsert_supplier(data["supplier_name"], None, data["supplier_vat_number"])
    return issues


def approve(invoice_id: int, user: str = "system") -> tuple[bool, str]:
    inv = db.get_invoice(invoice_id)
    issues = validation.validate(inv, invoice_id, inv["file_hash"])
    errors = validation.blocking(issues)
    if errors:
        db.update_invoice(invoice_id, {"issues": issues, "status": "needs_review"})
        return False, "Fix the errors before approving: " + "; ".join(e["message"] for e in errors)
    db.update_invoice(invoice_id, {"issues": issues, "status": "approved"})
    db.audit(invoice_id, "approve", "", user)
    return True, "Approved"


def reject(invoice_id: int, reason: str, user: str = "system") -> None:
    db.update_invoice(invoice_id, {"status": "rejected"})
    db.audit(invoice_id, "reject", reason, user)
