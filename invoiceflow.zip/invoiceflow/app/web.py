"""Shared web helpers: templates, sessions, the current user/account/business, guards."""
import secrets
from datetime import date
from functools import wraps
from pathlib import Path

from starlette.requests import Request
from starlette.responses import RedirectResponse
from starlette.templating import Jinja2Templates

from . import accounts, billing, config, db, plans

BASE = Path(__file__).parent
templates = Jinja2Templates(directory=str(BASE / "templates"))

STATUS_LABELS = {
    "needs_review": "Needs review",
    "ready": "Ready to approve",
    "approved": "Approved",
    "posted": "Posted",
    "rejected": "Rejected",
}
ACCOUNT_STATUS = {
    "trialing": "Trial", "active": "Active", "past_due": "Payment due", "paused": "Paused",
    "cancelled": "Cancelled", "comped": "Free access",
}


def money(v, cur="GBP"):
    if v is None:
        return "-"
    sym = {"GBP": "£", "EUR": "€", "USD": "$"}.get(cur or "GBP", "")
    return f"{'-' if v < 0 else ''}{sym}{abs(v):,.2f}" + ("" if sym else f" {cur}")


def uk_date(v):
    try:
        return date.fromisoformat(str(v)[:10]).strftime("%d %b %Y") if v else "-"
    except ValueError:
        return v


templates.env.filters.update(money=money, uk_date=uk_date)
templates.env.globals.update(APP_NAME=config.APP_NAME, STATUS_LABELS=STATUS_LABELS, ACCOUNT_STATUS=ACCOUNT_STATUS,
                             DEFAULT_ACCOUNT=config.DEFAULT_EXPENSE_ACCOUNT, PLANS=plans.PLANS,
                             PLAN_ORDER=plans.ORDER, FEATURES=plans.FEATURES, COMING_SOON=plans.COMING_SOON,
                             ROLES=accounts.ROLES, SUPPORT_EMAIL=config.SUPPORT_EMAIL,
                             TRIAL_DAYS=plans.TRIAL_DAYS)


class Ctx:
    """Who is asking, for which account and business."""

    def __init__(self, request: Request):
        self.request = request
        s = request.session
        self.user = db.get_user(s["uid"]) if s.get("uid") else None
        if self.user and not self.user["active"]:
            s.clear()
            self.user = None
        self.is_super = bool(self.user and self.user["role"] == "superadmin")
        self.impersonating = False
        self.tenant = None
        if self.user:
            if self.is_super and s.get("view_tenant"):
                self.tenant = db.get_tenant(s["view_tenant"])
                self.impersonating = bool(self.tenant)
            elif self.user["tenant_id"]:
                self.tenant = db.get_tenant(self.user["tenant_id"])
        self.businesses = db.list_businesses(self.tenant["id"]) if self.tenant else []
        self.business = None
        if self.businesses:
            wanted = s.get("bid")
            self.business = next((b for b in self.businesses if b["id"] == wanted), self.businesses[0])
            s["bid"] = self.business["id"]
        self.access = accounts.access(self.tenant) if self.tenant else {"ok": False, "state": "none", "message": ""}

    @property
    def role(self) -> str:
        if self.impersonating:
            return "owner"
        return self.user["role"] if self.user else ""

    @property
    def who(self) -> str:
        if not self.user:
            return "system"
        return f"{self.user['email']} (as support)" if self.impersonating else self.user["email"]

    def can(self, feature: str) -> bool:
        return bool(self.tenant) and accounts.has_feature(self.tenant, feature)

    def is_manager(self) -> bool:
        return self.role in ("owner", "admin")


def flash(request: Request, message: str, level: str = "ok") -> None:
    request.session.setdefault("flash", []).append({"level": level, "message": message})


def csrf_token(request: Request) -> str:
    if "csrf" not in request.session:
        request.session["csrf"] = secrets.token_urlsafe(24)
    return request.session["csrf"]


def render(request: Request, name: str, ctx: Ctx | None = None, **values):
    c = ctx or Ctx(request)
    values.update(request=request, ctx=c, user=c.user, tenant=c.tenant, business=c.business,
                  businesses=c.businesses, csrf=csrf_token(request), flashes=request.session.pop("flash", []),
                  counts=db.status_counts(c.business["id"]) if c.business else {},
                  billing_enabled=billing.enabled())
    return templates.TemplateResponse(request, name, values)


async def form_checked(request: Request) -> dict:
    form = await request.form()
    if not secrets.compare_digest(str(form.get("csrf", "")), request.session.get("csrf", "") or "x"):
        raise PermissionError("Form expired - reload the page and try again")
    return form


def back(url: str) -> RedirectResponse:
    return RedirectResponse(url, status_code=303)


def _safe_referer(request: Request, default: str) -> str:
    ref = request.headers.get("referer") or ""
    host = request.url.netloc
    if ref.startswith(f"{request.url.scheme}://{host}/"):
        return ref
    return default


def guarded(kind: str = "app"):
    """kind: 'login' (any signed-in user), 'app' (needs an active account), 'account' (account pages,
    allowed even when billing has lapsed), 'manager' (owner/admin), 'super' (master control)."""
    def deco(handler):
        @wraps(handler)
        async def wrapped(request: Request):
            c = Ctx(request)
            if not c.user:
                return back("/login?next=" + request.url.path)
            if kind == "super" and not c.is_super:
                return back("/")
            if kind in ("app", "account", "manager"):
                if not c.tenant:
                    return back("/admin" if c.is_super else "/login")
                if kind == "app" and not c.access["ok"]:
                    flash(request, c.access["message"], "warn")
                    return back("/account")
                if kind == "manager" and not c.is_manager():
                    flash(request, "Only the account owner or an admin can do that.", "error")
                    return back("/app")
            try:
                return await handler(request, c)
            except PermissionError as exc:
                flash(request, str(exc), "error")
                return back(_safe_referer(request, "/"))
        return wrapped
    return deco
