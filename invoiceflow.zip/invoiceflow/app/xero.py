"""Xero Accounting API integration: OAuth2 connection and posting bills.

Setup: create a "Web app" at https://developer.xero.com/app/manage, set the
redirect URI to XERO_REDIRECT_URI and put the client ID/secret in .env.
"""
import base64
import json
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from . import config, db

AUTH_URL = "https://login.xero.com/identity/connect/authorize"
TOKEN_URL = "https://identity.xero.com/connect/token"
CONNECTIONS_URL = "https://api.xero.com/connections"
API = "https://api.xero.com/api.xro/2.0"

TAX_TYPES = {20.0: "INPUT2", 5.0: "RRINPUT", 0.0: "ZERORATEDINPUT"}


class XeroError(Exception):
    pass


def configured() -> bool:
    return bool(config.XERO_CLIENT_ID and config.XERO_CLIENT_SECRET)


def _key(business_id: int) -> str:
    return f"b{business_id}:xero_connection"


def connection(business_id: int) -> dict | None:
    return db.get_setting(_key(business_id))


def authorize_url(business_id: int) -> str:
    state = f"{business_id}.{secrets.token_urlsafe(16)}"
    db.set_setting(f"xero_oauth_state:{business_id}", state)
    scopes = config.XERO_SCOPES
    if "accounting.attachments" not in scopes:
        scopes += " accounting.attachments"
    return AUTH_URL + "?" + urllib.parse.urlencode({
        "response_type": "code",
        "client_id": config.XERO_CLIENT_ID,
        "redirect_uri": config.XERO_REDIRECT_URI,
        "scope": scopes,
        "state": state,
    })


def _http(method: str, url: str, headers: dict, body: bytes | None = None) -> tuple[int, bytes]:
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()


def _token_request(params: dict) -> dict:
    basic = base64.b64encode(f"{config.XERO_CLIENT_ID}:{config.XERO_CLIENT_SECRET}".encode()).decode()
    status, body = _http("POST", TOKEN_URL, {
        "Authorization": f"Basic {basic}",
        "Content-Type": "application/x-www-form-urlencoded",
    }, urllib.parse.urlencode(params).encode())
    if status != 200:
        raise XeroError(f"Token request failed ({status}): {body[:300]!r}")
    tok = json.loads(body)
    tok["expires_at"] = time.time() + tok.get("expires_in", 1800) - 60
    return tok


def state_business(state: str) -> int | None:
    try:
        return int(state.split(".", 1)[0])
    except (ValueError, AttributeError):
        return None


def handle_callback(code: str, state: str, business_id: int) -> dict:
    if not state or state != db.get_setting(f"xero_oauth_state:{business_id}"):
        raise XeroError("OAuth state mismatch - please try connecting again")
    tok = _token_request({"grant_type": "authorization_code", "code": code,
                          "redirect_uri": config.XERO_REDIRECT_URI})
    status, body = _http("GET", CONNECTIONS_URL, {"Authorization": f"Bearer {tok['access_token']}"})
    if status != 200:
        raise XeroError(f"Could not list Xero organisations ({status})")
    tenants = json.loads(body)
    if not tenants:
        raise XeroError("No Xero organisation was authorised")
    conn = {"token": tok, "tenant_id": tenants[0]["tenantId"], "tenant_name": tenants[0].get("tenantName"),
            "tenants": [{"id": t["tenantId"], "name": t.get("tenantName")} for t in tenants]}
    db.set_setting(_key(business_id), conn)
    return conn


def disconnect(business_id: int) -> None:
    db.set_setting(_key(business_id), None)


def _access_token(business_id: int) -> tuple[str, str]:
    conn = connection(business_id)
    if not conn:
        raise XeroError("Xero is not connected")
    tok = conn["token"]
    if time.time() >= tok["expires_at"]:
        tok = _token_request({"grant_type": "refresh_token", "refresh_token": tok["refresh_token"]})
        conn["token"] = tok
        db.set_setting(_key(business_id), conn)
    return tok["access_token"], conn["tenant_id"]


def _api(business_id: int, method: str, path: str, payload: dict | None = None, raw: bytes | None = None,
         content_type: str = "application/json") -> dict:
    token, tenant = _access_token(business_id)
    headers = {"Authorization": f"Bearer {token}", "xero-tenant-id": tenant, "Accept": "application/json"}
    body = None
    if payload is not None:
        body = json.dumps(payload).encode()
        headers["Content-Type"] = "application/json"
    elif raw is not None:
        body = raw
        headers["Content-Type"] = content_type
    status, resp = _http(method, API + path, headers, body)
    if status >= 400:
        raise XeroError(f"Xero API {status}: {resp[:500].decode(errors='replace')}")
    return json.loads(resp) if resp else {}


def _line(li: dict, inv: dict) -> dict:
    rate = float(li["vat_rate"]) if li.get("vat_rate") is not None else None
    tax = TAX_TYPES.get(rate, "INPUT2") if (inv.get("vat_total") or rate) else "NONE"
    qty = li.get("quantity") or 1
    unit = li.get("unit_price") if li.get("unit_price") is not None else (li.get("net_amount") or 0) / qty
    return {
        "Description": li["description"][:4000],
        "Quantity": qty,
        "UnitAmount": round(unit, 4),
        "AccountCode": li.get("account_code") or config.DEFAULT_EXPENSE_ACCOUNT,
        "TaxType": tax,
    }


def build_payload(inv: dict, status: str = "DRAFT") -> tuple[str, dict]:
    contact = {"Name": inv["supplier_name"]}
    if inv.get("supplier_email"):
        contact["EmailAddress"] = inv["supplier_email"]
    if inv.get("supplier_vat_number"):
        contact["TaxNumber"] = inv["supplier_vat_number"]
    common = {
        "Contact": contact,
        "Date": inv["invoice_date"],
        "LineAmountTypes": "Exclusive",
        "CurrencyCode": inv.get("currency") or config.DEFAULT_CURRENCY,
        "Status": status,
        "LineItems": [_line(li, inv) for li in inv["line_items"]],
    }
    if inv.get("document_type") == "credit_note":
        return "CreditNotes", {"CreditNotes": [{**common, "Type": "ACCPAYCREDIT",
                                                "CreditNoteNumber": inv["invoice_number"]}]}
    return "Invoices", {"Invoices": [{**common, "Type": "ACCPAY", "InvoiceNumber": inv["invoice_number"],
                                      "DueDate": inv["due_date"], "Reference": inv.get("po_number") or ""}]}


def post_bill(inv: dict, status: str = "DRAFT") -> str:
    """Create the bill (or supplier credit) in Xero, attach the source file, return its Xero ID."""
    endpoint, payload = build_payload(inv, status)
    result = _api(inv["business_id"], "POST", f"/{endpoint}?summarizeErrors=false", payload)
    doc = result[endpoint][0]
    if doc.get("HasErrors") or doc.get("ValidationErrors"):
        msgs = "; ".join(e.get("Message", "") for e in doc.get("ValidationErrors", []))
        raise XeroError(f"Xero rejected the bill: {msgs}")
    xero_id = doc.get("InvoiceID") or doc.get("CreditNoteID")

    path = Path(inv["stored_path"])
    if path.exists():
        name = urllib.parse.quote(inv["filename"] or path.name)
        ctype = "application/pdf" if path.suffix.lower() == ".pdf" else f"image/{path.suffix.lower().lstrip('.')}"
        try:
            _api(inv["business_id"], "PUT", f"/{endpoint}/{xero_id}/Attachments/{name}", raw=path.read_bytes(), content_type=ctype)
        except XeroError:
            pass  # the bill exists; a failed attachment shouldn't fail the post
    return xero_id


def list_accounts(business_id: int) -> list[dict]:
    data = _api(business_id, "GET", "/Accounts?where=" + urllib.parse.quote('Status=="ACTIVE"'))
    return [{"code": a.get("Code"), "name": a.get("Name"), "type": a.get("Type")}
            for a in data.get("Accounts", []) if a.get("Code")]
