"""Payment rails that use the customer's own account, so money never passes through this platform.

- Wise Business: the customer pastes an API token from their Wise account. Transfers are created in
  their account; Wise asks them to approve and fund them (Wise requires its own strong authentication
  for UK/EEA payments), which also gives a second check in their banking app.
- Airwallex: the customer creates an API key in their Airwallex account. Transfers are paid from their
  Airwallex wallet, including future-dated transfers.
- Open Banking: payments from the customer's existing UK bank account, authorised by them at their bank,
  through an FCA-authorised payment initiation partner configured by the platform (OB_PARTNER_URL / OB_PARTNER_KEY).
Each adapter returns (ok, external_id or error). Test against each provider's sandbox first."""
import json
import os
import urllib.error
import urllib.parse
import urllib.request
import uuid

from . import bankfiles, crypto, db

KINDS = {"wise": "Wise Business", "airwallex": "Airwallex", "openbanking": "Open Banking"}


class PayError(Exception):
    pass


def _key(tenant_id: int, kind: str) -> str:
    return f"t{tenant_id}:pay:{kind}"


def get_conn(tenant_id: int, kind: str) -> dict:
    raw = db.get_setting(_key(tenant_id, kind))
    return crypto.unseal(raw) if raw else {}


def save_conn(tenant_id: int, kind: str, data: dict | None) -> None:
    db.set_setting(_key(tenant_id, kind), crypto.seal(data) if data else None)


def connected(tenant_id: int) -> dict:
    out = {k: bool(get_conn(tenant_id, k)) for k in ("wise", "airwallex")}
    out["openbanking"] = ob_configured()
    return out


def _http(method: str, url: str, headers: dict, body: dict | None = None) -> dict:
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method,
                                 headers={**headers, **({"Content-Type": "application/json"} if data else {})})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read()[:400].decode(errors="replace")
        raise PayError(f"{urllib.parse.urlparse(url).netloc} said {exc.code}: {detail}")
    except OSError as exc:
        raise PayError(f"Couldn't reach {urllib.parse.urlparse(url).netloc}: {exc}")


# ---- Wise -------------------------------------------------------------------------------------

def _wise_base(conn: dict) -> str:
    return "https://api.sandbox.transferwise.tech" if conn.get("sandbox") else "https://api.transferwise.com"


def wise_profiles(token: str, sandbox: bool) -> list[dict]:
    base = "https://api.sandbox.transferwise.tech" if sandbox else "https://api.transferwise.com"
    rows = _http("GET", f"{base}/v2/profiles", {"Authorization": f"Bearer {token}"})
    return [{"id": p["id"], "name": (p.get("businessName") or p.get("fullName") or p.get("details", {}).get("name") or str(p["id"])),
             "type": p.get("type")} for p in rows]


def wise_pay(conn: dict, item: dict, bank: dict) -> tuple[bool, str]:
    base, auth = _wise_base(conn), {"Authorization": f"Bearer {conn['token']}"}
    pid = conn["profile_id"]
    cur = item["currency"]
    quote = _http("POST", f"{base}/v3/profiles/{pid}/quotes", auth,
                  {"sourceCurrency": conn.get("source_currency") or cur, "targetCurrency": cur,
                   "targetAmount": round(item["amount"], 2), "payOut": "BANK_TRANSFER"})
    if bank.get("iban"):
        acct = {"currency": cur, "type": "iban", "profile": pid, "accountHolderName": bank["account_name"],
                "details": {"legalType": "BUSINESS", "IBAN": bankfiles.clean(bank["iban"]),
                            **({"BIC": bankfiles.clean(bank["bic"])} if bank.get("bic") else {})}}
    else:
        acct = {"currency": "GBP", "type": "sort_code", "profile": pid, "accountHolderName": bank["account_name"],
                "details": {"legalType": "BUSINESS", "sortCode": bankfiles.clean(bank["sort_code"]),
                            "accountNumber": bankfiles.clean(bank["account_number"])}}
    recipient = _http("POST", f"{base}/v1/accounts", auth, acct)
    transfer = _http("POST", f"{base}/v1/transfers", auth,
                     {"targetAccount": recipient["id"], "quoteUuid": quote["id"],
                      "customerTransactionId": str(uuid.uuid5(uuid.NAMESPACE_URL, f"invoiceflow-item-{item['id']}")),
                      "details": {"reference": (item.get("reference") or "")[:18]}})
    return True, str(transfer["id"])


def wise_status(conn: dict, external_id: str) -> str:
    t = _http("GET", f"{_wise_base(conn)}/v1/transfers/{external_id}", {"Authorization": f"Bearer {conn['token']}"})
    s = t.get("status", "")
    if s in ("outgoing_payment_sent", "funds_converted"):
        return "paid"
    if s in ("cancelled", "funds_refunded", "bounced_back", "charged_back"):
        return "failed"
    return "sent"


# ---- Airwallex --------------------------------------------------------------------------------

def _awx_base(conn: dict) -> str:
    return "https://api-demo.airwallex.com" if conn.get("sandbox") else "https://api.airwallex.com"


def _awx_token(conn: dict) -> str:
    r = _http("POST", f"{_awx_base(conn)}/api/v1/authentication/login",
              {"x-client-id": conn["client_id"], "x-api-key": conn["api_key"]}, {})
    if not r.get("token"):
        raise PayError("Airwallex didn't accept the client ID and API key.")
    return r["token"]


def airwallex_check(conn: dict) -> None:
    _awx_token(conn)


def airwallex_pay(conn: dict, item: dict, bank: dict) -> tuple[bool, str]:
    token = _awx_token(conn)
    cur = item["currency"]
    details = {"account_name": bank["account_name"], "account_currency": cur,
               "bank_country_code": (bank.get("country") or ("GB" if not bank.get("iban") else bankfiles.clean(bank["iban"])[:2]))}
    if bank.get("iban"):
        details.update({"iban": bankfiles.clean(bank["iban"])}, **({"swift_code": bankfiles.clean(bank["bic"])} if bank.get("bic") else {}))
        method = "LOCAL" if cur == "EUR" else "SWIFT"
    else:
        details.update({"account_number": bankfiles.clean(bank["account_number"]), "account_routing_type1": "sort_code",
                        "account_routing_value1": bankfiles.clean(bank["sort_code"])})
        method = "LOCAL"
    body = {"request_id": str(uuid.uuid5(uuid.NAMESPACE_URL, f"invoiceflow-item-{item['id']}")),
            "source_currency": conn.get("source_currency") or cur, "transfer_currency": cur,
            "transfer_amount": round(item["amount"], 2), "transfer_method": method,
            "reference": (item.get("reference") or "")[:18], "reason": "payment_to_supplier",
            "beneficiary": {"entity_type": "COMPANY", "company_name": item["supplier_name"][:100], "bank_details": details}}
    if item.get("pay_date"):
        body["transfer_date"] = item["pay_date"]
    r = _http("POST", f"{_awx_base(conn)}/api/v1/transfers/create", {"Authorization": f"Bearer {token}"}, body)
    return True, str(r.get("id") or r.get("request_id"))


def airwallex_status(conn: dict, external_id: str) -> str:
    token = _awx_token(conn)
    r = _http("GET", f"{_awx_base(conn)}/api/v1/transfers/{external_id}", {"Authorization": f"Bearer {token}"})
    s = (r.get("status") or "").upper()
    if s in ("PAID", "SENT"):
        return "paid"
    if s in ("FAILED", "CANCELLED", "REJECTED"):
        return "failed"
    return "sent"


# ---- Open Banking (platform partner) -----------------------------------------------------------

def ob_configured() -> bool:
    return bool(os.getenv("OB_PARTNER_URL") and os.getenv("OB_PARTNER_KEY"))


def ob_create(run: dict, items: list[dict], return_url: str) -> tuple[str, str]:
    """Create a bulk payment request with the partner. Returns (partner reference, URL where the customer authorises
    it at their bank). Adjust the body to your partner's API (TrueLayer, Yapily, Token and others differ)."""
    payments = [{"id": str(it["id"]), "amount_minor": int(round(it["amount"] * 100)), "currency": it["currency"],
                 "reference": (it.get("reference") or "")[:18], "execution_date": it.get("pay_date"),
                 "beneficiary": {"name": it["bank"]["account_name"], "sort_code": bankfiles.clean(it["bank"].get("sort_code")),
                                 "account_number": bankfiles.clean(it["bank"].get("account_number")),
                                 "iban": bankfiles.clean(it["bank"].get("iban"))}} for it in items]
    r = _http("POST", os.getenv("OB_PARTNER_URL").rstrip("/") + "/bulk-payments",
              {"Authorization": f"Bearer {os.getenv('OB_PARTNER_KEY')}"},
              {"reference": f"RUN-{run['id']}", "payments": payments, "redirect_url": return_url})
    if not r.get("authorisation_url"):
        raise PayError("The Open Banking partner didn't return an authorisation link.")
    return str(r.get("id")), r["authorisation_url"]
