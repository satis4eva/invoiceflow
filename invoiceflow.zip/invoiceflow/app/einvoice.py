"""Structured e-invoices: read Peppol BIS Billing 3.0 (UBL 2.1 Invoice / CreditNote) and UN/CEFACT CII
exactly, with no OCR; build Peppol BIS Order (UBL Order) XML for e-ordering."""
import base64
import re
import xml.etree.ElementTree as ET
from datetime import date
from xml.sax.saxutils import escape

NS = {
    "cbc": "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2",
    "cac": "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2",
    "rsm": "urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100",
    "ram": "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100",
    "udt": "urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100",
}
UBL_INVOICE = "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
UBL_CREDIT = "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2"
UNIT_NAMES = {"C62": "each", "EA": "each", "H87": "piece", "KGM": "kg", "LTR": "litre", "MTR": "m", "HUR": "hour",
              "DAY": "day", "MTK": "m2", "MTQ": "m3", "TNE": "tonne", "KWH": "kWh", "CS": "case", "XBX": "box"}


class EInvoiceError(Exception):
    pass


def is_einvoice(content: bytes) -> bool:
    head = content[:4000]
    return head.lstrip().startswith(b"<") and (b"Invoice-2" in head or b"CreditNote-2" in head
                                              or b"CrossIndustryInvoice" in head)


def _root(content: bytes) -> ET.Element:
    if len(content) > 15 * 1024 * 1024:
        raise EInvoiceError("The XML file is larger than 15 MB.")
    if re.search(rb"<!DOCTYPE|<!ENTITY", content[:5000], re.I):
        raise EInvoiceError("XML with DOCTYPE or entity declarations isn't accepted.")
    try:
        return ET.fromstring(content)
    except ET.ParseError as exc:
        raise EInvoiceError(f"The XML couldn't be read: {exc}")


def _t(el, path: str) -> str | None:
    if el is None:
        return None
    found = el.find(path, NS)
    return found.text.strip() if found is not None and found.text else None


def _n(v) -> float | None:
    try:
        return round(float(v), 4) if v not in (None, "") else None
    except ValueError:
        return None


def _cii_date(v: str | None) -> str | None:
    if v and re.fullmatch(r"\d{8}", v):
        return f"{v[:4]}-{v[4:6]}-{v[6:]}"
    return v


def parse(content: bytes) -> dict:
    root = _root(content)
    tag = root.tag
    if tag.startswith("{" + UBL_INVOICE) or tag.startswith("{" + UBL_CREDIT):
        data = _parse_ubl(root, credit=tag.startswith("{" + UBL_CREDIT))
    elif "CrossIndustryInvoice" in tag:
        data = _parse_cii(root)
    else:
        raise EInvoiceError("This XML isn't a UBL or CII invoice.")
    data["extraction_method"] = "e-invoice"
    data["confidence"] = 1.0
    return data


def _parse_ubl(root, credit: bool) -> dict:
    sup = root.find("cac:AccountingSupplierParty/cac:Party", NS)
    vat = None
    for scheme in (sup.findall("cac:PartyTaxScheme", NS) if sup is not None else []):
        cid = _t(scheme, "cbc:CompanyID")
        if cid and (_t(scheme, "cac:TaxScheme/cbc:ID") or "VAT").upper() == "VAT":
            vat = cid
    lines = []
    line_tag = "cac:CreditNoteLine" if credit else "cac:InvoiceLine"
    qty_tag = "cbc:CreditedQuantity" if credit else "cbc:InvoicedQuantity"
    for ln in root.findall(line_tag, NS):
        q = ln.find(qty_tag, NS)
        unit_code = q.get("unitCode") if q is not None else None
        base_qty = _n(_t(ln, "cac:Price/cbc:BaseQuantity")) or 1
        price = _n(_t(ln, "cac:Price/cbc:PriceAmount"))
        net = _n(_t(ln, "cbc:LineExtensionAmount"))
        rate = _n(_t(ln, "cac:Item/cac:ClassifiedTaxCategory/cbc:Percent"))
        lines.append({
            "description": _t(ln, "cac:Item/cbc:Name") or _t(ln, "cac:Item/cbc:Description") or "Item",
            "code": _t(ln, "cac:Item/cac:SellersItemIdentification/cbc:ID") or _t(ln, "cac:Item/cac:StandardItemIdentification/cbc:ID"),
            "unit": UNIT_NAMES.get(unit_code or "", unit_code),
            "quantity": _n(q.text if q is not None else None),
            "unit_price": round(price / base_qty, 4) if price is not None else None,
            "net_amount": net,
            "vat_rate": rate,
            "vat_amount": round(net * rate / 100, 2) if net is not None and rate is not None else None,
            "extras": {k: v for k, v in {"order_line": _t(ln, "cac:OrderLineReference/cbc:LineID"),
                                         "ean": _t(ln, "cac:Item/cac:StandardItemIdentification/cbc:ID")}.items() if v},
        })
    # Embedded PDF copy, if the supplier included one
    attachment = None
    for ref in root.findall("cac:AdditionalDocumentReference", NS):
        obj = ref.find("cac:Attachment/cbc:EmbeddedDocumentBinaryObject", NS)
        if obj is not None and (obj.get("mimeCode") or "").endswith("pdf") and obj.text:
            try:
                attachment = base64.b64decode(obj.text)
            except ValueError:
                pass
            break
    extras = {k: v for k, v in {
        "delivery_note": _t(root, "cac:DespatchDocumentReference/cbc:ID"),
        "reference": _t(root, "cbc:BuyerReference") or _t(root, "cac:ProjectReference/cbc:ID"),
        "contract": _t(root, "cac:ContractDocumentReference/cbc:ID"),
        "peppol_sender": (root.find("cac:AccountingSupplierParty/cac:Party/cbc:EndpointID", NS).text
                          if root.find("cac:AccountingSupplierParty/cac:Party/cbc:EndpointID", NS) is not None else None),
    }.items() if v}
    return {
        "document_type": "credit_note" if credit else "invoice",
        "supplier_name": _t(sup, "cac:PartyLegalEntity/cbc:RegistrationName") or _t(sup, "cac:PartyName/cbc:Name") or "",
        "supplier_vat_number": vat,
        "supplier_email": _t(sup, "cac:Contact/cbc:ElectronicMail"),
        "supplier_address": ", ".join(filter(None, [_t(sup, "cac:PostalAddress/cbc:StreetName"),
                                                    _t(sup, "cac:PostalAddress/cbc:CityName"),
                                                    _t(sup, "cac:PostalAddress/cbc:PostalZone")])) or None,
        "invoice_number": _t(root, "cbc:ID"),
        "invoice_date": _t(root, "cbc:IssueDate"),
        "due_date": _t(root, "cbc:DueDate") or _t(root, "cac:PaymentMeans/cbc:PaymentDueDate"),
        "po_number": _t(root, "cac:OrderReference/cbc:ID"),
        "currency": _t(root, "cbc:DocumentCurrencyCode") or "GBP",
        "net_total": _n(_t(root, "cac:LegalMonetaryTotal/cbc:TaxExclusiveAmount")),
        "vat_total": _n(_t(root, "cac:TaxTotal/cbc:TaxAmount")),
        "gross_total": _n(_t(root, "cac:LegalMonetaryTotal/cbc:PayableAmount")) or
                       _n(_t(root, "cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount")),
        "line_items": lines,
        "extras": extras,
        "notes": _t(root, "cbc:Note"),
        "_attachment": attachment,
    }


def _parse_cii(root) -> dict:
    tx = root.find("rsm:SupplyChainTradeTransaction", NS)
    doc = root.find("rsm:ExchangedDocument", NS)
    agr = tx.find("ram:ApplicableHeaderTradeAgreement", NS) if tx is not None else None
    sett = tx.find("ram:ApplicableHeaderTradeSettlement", NS) if tx is not None else None
    seller = agr.find("ram:SellerTradeParty", NS) if agr is not None else None
    vat = None
    for reg in (seller.findall("ram:SpecifiedTaxRegistration", NS) if seller is not None else []):
        idel = reg.find("ram:ID", NS)
        if idel is not None and (idel.get("schemeID") or "VA") == "VA":
            vat = idel.text
    lines = []
    for item in (tx.findall("ram:IncludedSupplyChainTradeLineItem", NS) if tx is not None else []):
        q = item.find("ram:SpecifiedLineTradeDelivery/ram:BilledQuantity", NS)
        net = _n(_t(item, "ram:SpecifiedLineTradeSettlement/ram:SpecifiedTradeSettlementLineMonetarySummation/ram:LineTotalAmount"))
        rate = _n(_t(item, "ram:SpecifiedLineTradeSettlement/ram:ApplicableTradeTax/ram:RateApplicablePercent"))
        lines.append({
            "description": _t(item, "ram:SpecifiedTradeProduct/ram:Name") or "Item",
            "code": _t(item, "ram:SpecifiedTradeProduct/ram:SellerAssignedID"),
            "unit": UNIT_NAMES.get(q.get("unitCode") if q is not None else "", q.get("unitCode") if q is not None else None),
            "quantity": _n(q.text if q is not None else None),
            "unit_price": _n(_t(item, "ram:SpecifiedLineTradeAgreement/ram:NetPriceProductTradePrice/ram:ChargeAmount")),
            "net_amount": net, "vat_rate": rate,
            "vat_amount": round(net * rate / 100, 2) if net is not None and rate is not None else None,
        })
    summ = sett.find("ram:SpecifiedTradeSettlementHeaderMonetarySummation", NS) if sett is not None else None
    type_code = _t(doc, "ram:TypeCode")
    return {
        "document_type": "credit_note" if type_code == "381" else "invoice",
        "supplier_name": _t(seller, "ram:Name") or "",
        "supplier_vat_number": vat,
        "supplier_email": _t(seller, "ram:DefinedTradeContact/ram:EmailURIUniversalCommunication/ram:URIID"),
        "invoice_number": _t(doc, "ram:ID"),
        "invoice_date": _cii_date(_t(doc, "ram:IssueDateTime/udt:DateTimeString")),
        "due_date": _cii_date(_t(sett, "ram:SpecifiedTradePaymentTerms/ram:DueDateDateTime/udt:DateTimeString")),
        "po_number": _t(agr, "ram:BuyerOrderReferencedDocument/ram:IssuerAssignedID"),
        "currency": _t(sett, "ram:InvoiceCurrencyCode") or "GBP",
        "net_total": _n(_t(summ, "ram:TaxBasisTotalAmount")),
        "vat_total": _n(_t(summ, "ram:TaxTotalAmount")),
        "gross_total": _n(_t(summ, "ram:DuePayableAmount")) or _n(_t(summ, "ram:GrandTotalAmount")),
        "line_items": lines,
        "extras": {},
    }


# ---- e-ordering: Peppol BIS Order 3 (UBL Order) --------------------------------------------

def _peppol_endpoint(pid: str | None) -> str:
    if pid and ":" in pid:
        scheme, value = pid.split(":", 1)
        return f'<cbc:EndpointID schemeID="{escape(scheme)}">{escape(value)}</cbc:EndpointID>'
    return ""


def order_xml(po: dict, buyer: dict, buyer_peppol: str | None, supplier_peppol: str | None) -> bytes:
    lines = []
    for i, l in enumerate(po["lines"], 1):
        qty = l.get("qty") or 0
        lines.append(f"""  <cac:OrderLine>
    <cac:LineItem>
      <cbc:ID>{escape(str(l.get('line', i)))}</cbc:ID>
      <cbc:Quantity unitCode="C62">{qty:g}</cbc:Quantity>
      <cbc:LineExtensionAmount currencyID="{escape(po.get('currency') or 'GBP')}">{(l.get('unit_price') or 0) * qty:.2f}</cbc:LineExtensionAmount>
      <cac:Price><cbc:PriceAmount currencyID="{escape(po.get('currency') or 'GBP')}">{(l.get('unit_price') or 0):.4f}</cbc:PriceAmount></cac:Price>
      <cac:Item>
        <cbc:Name>{escape(str(l.get('description') or 'Item'))[:200]}</cbc:Name>
        {f"<cac:SellersItemIdentification><cbc:ID>{escape(str(l['code']))}</cbc:ID></cac:SellersItemIdentification>" if l.get('code') else ""}
        <cac:ClassifiedTaxCategory><cbc:ID>{'S' if (l.get('vat_rate') or 0) > 0 else 'Z'}</cbc:ID><cbc:Percent>{(l.get('vat_rate') or 0):g}</cbc:Percent><cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:ClassifiedTaxCategory>
      </cac:Item>
    </cac:LineItem>
  </cac:OrderLine>""")
    cur = escape(po.get("currency") or "GBP")
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Order xmlns="urn:oasis:names:specification:ubl:schema:xsd:Order-2"
       xmlns:cac="{NS['cac']}" xmlns:cbc="{NS['cbc']}">
  <cbc:CustomizationID>urn:fdc:peppol.eu:poacc:trns:order:3</cbc:CustomizationID>
  <cbc:ProfileID>urn:fdc:peppol.eu:poacc:bis:order_only:3</cbc:ProfileID>
  <cbc:ID>{escape(po['po_number'])}</cbc:ID>
  <cbc:IssueDate>{escape(po.get('order_date') or date.today().isoformat())}</cbc:IssueDate>
  <cbc:DocumentCurrencyCode>{cur}</cbc:DocumentCurrencyCode>
  {f"<cbc:CustomerReference>{escape(po['reference'])}</cbc:CustomerReference>" if po.get('reference') else ""}
  <cac:BuyerCustomerParty><cac:Party>{_peppol_endpoint(buyer_peppol)}
    <cac:PartyName><cbc:Name>{escape(buyer['name'])}</cbc:Name></cac:PartyName>
  </cac:Party></cac:BuyerCustomerParty>
  <cac:SellerSupplierParty><cac:Party>{_peppol_endpoint(supplier_peppol)}
    <cac:PartyName><cbc:Name>{escape(po['supplier_name'])}</cbc:Name></cac:PartyName>
  </cac:Party></cac:SellerSupplierParty>
  {f"<cac:Delivery><cac:DeliveryLocation><cac:Address><cbc:StreetName>{escape(po['delivery_address'])}</cbc:StreetName></cac:Address></cac:DeliveryLocation>" + (f"<cac:RequestedDeliveryPeriod><cbc:EndDate>{escape(po['delivery_date'])}</cbc:EndDate></cac:RequestedDeliveryPeriod>" if po.get('delivery_date') else "") + "</cac:Delivery>" if po.get('delivery_address') else ""}
  <cac:AnticipatedMonetaryTotal><cbc:LineExtensionAmount currencyID="{cur}">{(po.get('net_total') or 0):.2f}</cbc:LineExtensionAmount><cbc:PayableAmount currencyID="{cur}">{(po.get('gross_total') or 0):.2f}</cbc:PayableAmount></cac:AnticipatedMonetaryTotal>
{chr(10).join(lines)}
</Order>
"""
    return xml.encode()
