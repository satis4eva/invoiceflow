"""Outgoing email over SMTP (works with Postmark, Brevo, SendGrid, Mailgun, Gmail, Hostinger mail...).

Without SMTP settings, emails are written to the log instead and the app
skips steps that need them (sign-ups are verified straight away).
"""
import logging
import smtplib
import ssl
from email.message import EmailMessage

from . import config

log = logging.getLogger("invoiceflow.mail")


def enabled() -> bool:
    return bool(config.SMTP_HOST and config.MAIL_FROM)


def send(to: str, subject: str, text: str, attachments: list[tuple[str, bytes, str]] | None = None) -> bool:
    if not enabled():
        log.warning("Email not sent (SMTP not configured) to=%s subject=%s\n%s", to, subject, text)
        return False
    msg = EmailMessage()
    msg["From"] = config.MAIL_FROM
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(text)
    for name, content, ctype in attachments or []:
        maintype, _, subtype = ctype.partition("/")
        msg.add_attachment(content, maintype=maintype, subtype=subtype, filename=name)
    try:
        if config.SMTP_PORT == 465:
            with smtplib.SMTP_SSL(config.SMTP_HOST, 465, context=ssl.create_default_context(), timeout=20) as s:
                if config.SMTP_USER:
                    s.login(config.SMTP_USER, config.SMTP_PASSWORD)
                s.send_message(msg)
        else:
            with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=20) as s:
                s.starttls(context=ssl.create_default_context())
                if config.SMTP_USER:
                    s.login(config.SMTP_USER, config.SMTP_PASSWORD)
                s.send_message(msg)
        return True
    except Exception as exc:  # never let a mail failure break a page
        log.error("Email to %s failed: %s", to, exc)
        return False


def link(path: str) -> str:
    return config.BASE_URL.rstrip("/") + path


def verify_email(to: str, token: str) -> bool:
    return send(to, f"Confirm your {config.APP_NAME} email",
                f"Welcome to {config.APP_NAME}.\n\nConfirm your email address to finish setting up your account:\n"
                f"{link('/verify/' + token)}\n\nThe link works for 48 hours.")


def reset_password(to: str, token: str) -> bool:
    return send(to, f"Reset your {config.APP_NAME} password",
                f"Someone asked to reset the password for this email address.\n\nChoose a new password here:\n"
                f"{link('/reset/' + token)}\n\nThe link works for 2 hours. If this wasn't you, ignore this email.")


def invite(to: str, token: str, company: str, inviter: str) -> bool:
    return send(to, f"You're invited to {company} on {config.APP_NAME}",
                f"{inviter} has invited you to review supplier invoices for {company}.\n\n"
                f"Accept the invitation and choose a password:\n{link('/invite/' + token)}\n\n"
                "The link works for 7 days.")


def payment_failed(to: str, company: str) -> bool:
    return send(to, f"Payment failed for {company}",
                f"We couldn't take the latest payment for your {config.APP_NAME} subscription.\n\n"
                f"Update your card here to keep access:\n{link('/account')}")
