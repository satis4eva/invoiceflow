"""Business-rule checks run after extraction and after every manual edit."""
import re
from datetime import date, timedelta

from . import config, db

UK_VAT_RATES = {0.0, 5.0, 20.0}


def issue(level: str, code: str, message: str) -> dict:
    return {"level": level, "code": code, "message": message}


def valid_uk_vat_number(vat: str) -> bool:
    """Format + HMRC mod-97 check digit test for 9-digit GB VAT numbers."""
    v = re.sub(r"\s", "", vat or "").upper()
    if v.startswith("XI"):  # Northern Ireland uses the same algorithm
        v = "GB" + v[2:]
    if re.fullmatch(r"GB(GD|HA)\d{3}", v):  # government departments / health authorities
        return True
    m = re.fullmatch(r"(?:GB)?(\d{9})(\d{3})?", v)
    if not m:
        return False
    d = [int(c) for c in m.group(1)]
    total = sum(x * w for x, w in zip(d[:7], range(8, 1, -1))) + int(m.group(1)[7:])
    return total % 97 == 0 or (total + 55) % 97 == 0


def _close(a, b) -> bool:
    return a is not None and b is not None and abs(a - b) <= config.TOLERANCE


def validate(inv: dict, invoice_id: int | None = None, file_hash: str | None = None,
             business_id: int | None = None) -> list[dict]:
    issues: list[dict] = []
    bid = business_id or inv.get("business_id")
    tol = config.TOLERANCE

    # --- required fields
    for field, label in [("supplier_name", "Supplier"), ("invoice_number", "Invoice number"),
                         ("invoice_date", "Invoice date"), ("gross_total", "Total amount")]:
        if inv.get(field) in (None, ""):
            issues.append(issue("error", "missing_" + field, f"{label} is missing"))

    if inv.get("document_type") not in (None, "invoice", "credit_note", "receipt"):
        issues.append(issue("error", "not_invoice", f"Document looks like a {inv.get('document_type')}, not an invoice"))
    if inv.get("document_type") == "credit_note":
        issues.append(issue("info", "credit_note", "Credit note - will be posted as a supplier credit"))

    # --- arithmetic
    net, vat, gross = inv.get("net_total"), inv.get("vat_total"), inv.get("gross_total")
    if None not in (net, vat, gross) and abs(net + vat - gross) > tol:
        issues.append(issue("error", "totals_mismatch",
                            f"Net {net:.2f} + VAT {vat:.2f} = {net + vat:.2f}, but total is {gross:.2f}"))

    lines = inv.get("line_items") or []
    if not lines:
        issues.append(issue("error", "no_lines", "No line items found"))
    else:
        line_net = round(sum(l.get("net_amount") or 0 for l in lines), 2)
        if net is not None and abs(line_net - net) > tol:
            issues.append(issue("error", "lines_mismatch",
                                f"Line items add up to {line_net:.2f}, but net total is {net:.2f}"))
        line_vat = round(sum(l.get("vat_amount") or 0 for l in lines), 2)
        if vat is not None and any(l.get("vat_amount") is not None for l in lines) and abs(line_vat - vat) > max(tol, 0.01 * len(lines)):
            issues.append(issue("warning", "line_vat_mismatch",
                                f"Line VAT adds up to {line_vat:.2f}, but VAT total is {vat:.2f}"))
        for n, l in enumerate(lines, 1):
            if l.get("net_amount") is None:
                issues.append(issue("error", "line_amount", f"Line {n} has no amount"))
            rate = l.get("vat_rate")
            if rate is not None and float(rate) not in UK_VAT_RATES:
                issues.append(issue("warning", "vat_rate", f"Line {n} VAT rate {rate:g}% is not a standard UK rate"))
            q, u, a = l.get("quantity"), l.get("unit_price"), l.get("net_amount")
            if None not in (q, u, a) and abs(q * u - a) > max(tol, 0.01):
                issues.append(issue("warning", "line_maths", f"Line {n}: {q:g} x {u:.2f} does not equal {a:.2f}"))

    # --- VAT compliance
    vat_no = inv.get("supplier_vat_number")
    if vat and vat > 0:
        if not vat_no:
            issues.append(issue("warning", "no_vat_number",
                                "VAT charged but no supplier VAT number - not a valid VAT invoice for reclaim"))
        elif vat_no.upper().startswith(("GB", "XI")) or vat_no.isdigit():
            if not valid_uk_vat_number(vat_no):
                issues.append(issue("error", "bad_vat_number", f"VAT number {vat_no} fails the HMRC check-digit test"))

    # --- dates
    today = date.today()
    inv_date = _d(inv.get("invoice_date"))
    due = _d(inv.get("due_date"))
    if inv_date:
        if inv_date > today + timedelta(days=1):
            issues.append(issue("warning", "future_date", "Invoice date is in the future"))
        if inv_date < today - timedelta(days=180):
            issues.append(issue("warning", "old_invoice", "Invoice is more than 6 months old"))
    if inv_date and due and due < inv_date:
        issues.append(issue("error", "due_before_date", "Due date is before the invoice date"))

    # --- currency
    if inv.get("currency") and inv["currency"] != config.DEFAULT_CURRENCY:
        issues.append(issue("warning", "foreign_currency", f"Invoice is in {inv['currency']}"))

    # --- duplicates
    if file_hash:
        dup = db.find_by_hash(bid, file_hash, invoice_id)
        if dup:
            issues.append(issue("error", "duplicate_file", f"Same file already uploaded (#{dup['id']})"))
    dups = db.find_duplicates(bid, inv.get("supplier_name"), inv.get("invoice_number"), invoice_id)
    if dups:
        ids = ", ".join(f"#{d['id']}" for d in dups)
        issues.append(issue("error", "duplicate_invoice",
                            f"Invoice {inv.get('invoice_number')} from this supplier already exists ({ids})"))

    # --- extraction quality
    conf = inv.get("confidence")
    if conf is not None and conf < 0.8:
        issues.append(issue("warning", "low_confidence", f"Low extraction confidence ({conf:.0%}) - check all fields"))

    # --- coding
    if lines and not all(l.get("account_code") for l in lines):
        issues.append(issue("info", "default_coding",
                            f"Some lines use the default expense account {config.DEFAULT_EXPENSE_ACCOUNT}"))
    return issues


def status_for(issues: list[dict]) -> str:
    return "needs_review" if any(i["level"] in ("error", "warning") for i in issues) else "ready"


def blocking(issues: list[dict]) -> list[dict]:
    return [i for i in issues if i["level"] == "error"]


def _d(v):
    try:
        return date.fromisoformat(v) if v else None
    except ValueError:
        return None
