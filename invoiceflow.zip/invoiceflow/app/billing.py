"""Stripe subscriptions: checkout, customer portal, webhooks and overage charges.

Setup (Stripe dashboard):
  1. Products > add the four packages, each with a monthly and a yearly GBP price.
  2. Copy each price ID into .env as STRIPE_PRICE_<PLAN>_<MONTHLY|YEARLY>.
  3. Developers > Webhooks > add endpoint https://<your domain>/stripe/webhook with events:
     checkout.session.completed, customer.subscription.updated, customer.subscription.deleted,
     invoice.paid, invoice.payment_failed, invoice.created
  4. Put the signing secret in STRIPE_WEBHOOK_SECRET and the secret key in STRIPE_SECRET_KEY.
  5. Settings > Billing > Customer portal: allow card updates, plan changes and cancellation.
"""
import hashlib
import hmac
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

from . import accounts, config, db, mailer, plans

API = "https://api.stripe.com/v1"


class BillingError(Exception):
    pass


def enabled() -> bool:
    return bool(config.STRIPE_SECRET_KEY)


def _flatten(data: dict, prefix: str = "") -> list[tuple[str, str]]:
    out = []
    for k, v in data.items():
        key = f"{prefix}[{k}]" if prefix else k
        if isinstance(v, dict):
            out += _flatten(v, key)
        elif isinstance(v, list):
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    out += _flatten(item, f"{key}[{i}]")
                else:
                    out.append((f"{key}[{i}]", str(item)))
        elif v is not None:
            out.append((key, str(v).lower() if isinstance(v, bool) else str(v)))
    return out


def _call(method: str, path: str, data: dict | None = None) -> dict:
    if not enabled():
        raise BillingError("Card payments are not set up yet.")
    body = urllib.parse.urlencode(_flatten(data or {})).encode() if data else None
    req = urllib.request.Request(API + path, data=body, method=method, headers={
        "Authorization": f"Bearer {config.STRIPE_SECRET_KEY}",
        "Content-Type": "application/x-www-form-urlencoded",
        "Stripe-Version": "2024-06-20",
    })
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        try:
            msg = json.loads(exc.read())["error"]["message"]
        except Exception:
            msg = f"HTTP {exc.code}"
        raise BillingError(f"Stripe: {msg}") from exc


def _ts(value) -> str | None:
    return datetime.fromtimestamp(int(value), timezone.utc).isoformat(timespec="seconds") if value else None


# ---- checkout & portal ----------------------------------------------------------------

def checkout_url(tenant: dict, user: dict, plan: str, interval: str) -> str:
    price = plans.stripe_price_id(plan, interval)
    if not price:
        raise BillingError(f"No Stripe price set for {plans.get(plan)['name']} ({interval}).")
    data = {
        "mode": "subscription",
        "line_items": [{"price": price, "quantity": 1}],
        "client_reference_id": str(tenant["id"]),
        "success_url": config.BASE_URL + "/account?billing=success",
        "cancel_url": config.BASE_URL + "/account?billing=cancelled",
        "allow_promotion_codes": True,
        "billing_address_collection": "required",
        "tax_id_collection": {"enabled": True},
        "subscription_data": {"metadata": {"tenant_id": tenant["id"], "plan": plan}},
        "metadata": {"tenant_id": tenant["id"], "plan": plan, "interval": interval},
    }
    if tenant.get("stripe_customer_id"):
        data["customer"] = tenant["stripe_customer_id"]
    else:
        data["customer_email"] = user["email"]
    # Carry any unused trial days over into the paid subscription
    left = accounts.days_left(tenant.get("trial_ends_at"))
    if tenant["status"] == "trialing" and left and left > 0 and not tenant.get("stripe_subscription_id"):
        data["subscription_data"]["trial_period_days"] = left
    return _call("POST", "/checkout/sessions", data)["url"]


def portal_url(tenant: dict) -> str:
    if not tenant.get("stripe_customer_id"):
        raise BillingError("No card on file yet - choose a package first.")
    data = {"customer": tenant["stripe_customer_id"], "return_url": config.BASE_URL + "/account"}
    if config.STRIPE_PORTAL_CONFIG:
        data["configuration"] = config.STRIPE_PORTAL_CONFIG
    return _call("POST", "/billing_portal/sessions", data)["url"]


# ---- webhooks ---------------------------------------------------------------------------

def verify_signature(payload: bytes, header: str, secret: str, tolerance: int = 300) -> bool:
    try:
        parts = dict(p.split("=", 1) for p in header.split(","))
        ts = int(parts["t"])
        sigs = [v for k, v in (p.split("=", 1) for p in header.split(",")) if k == "v1"]
    except Exception:
        return False
    if abs(time.time() - ts) > tolerance:
        return False
    expected = hmac.new(secret.encode(), f"{ts}.".encode() + payload, hashlib.sha256).hexdigest()
    return any(hmac.compare_digest(expected, s) for s in sigs)


STATUS_MAP = {
    "trialing": "trialing", "active": "active", "past_due": "past_due", "unpaid": "paused",
    "canceled": "cancelled", "incomplete": "trialing", "incomplete_expired": "cancelled", "paused": "paused",
}


def _apply_subscription(tenant: dict, sub: dict) -> None:
    item = (sub.get("items", {}).get("data") or [{}])[0]
    price_id = (item.get("price") or {}).get("id")
    found = plans.plan_for_price(price_id)
    values = {
        "stripe_subscription_id": sub["id"],
        "stripe_customer_id": sub.get("customer") or tenant.get("stripe_customer_id"),
        "status": STATUS_MAP.get(sub.get("status"), "paused"),
        "period_start": _ts(item.get("current_period_start") or sub.get("current_period_start")),
        "period_end": _ts(item.get("current_period_end") or sub.get("current_period_end")),
    }
    if sub.get("trial_end"):
        values["trial_ends_at"] = _ts(sub["trial_end"])[:10]
    if found:
        values["plan"], values["billing_interval"] = found
    db.update_tenant(tenant["id"], values)
    db.admin_log(tenant["id"], "subscription", f"{sub.get('status')} {found[0] if found else price_id}", "stripe")


def _owner_email(tenant_id: int) -> str | None:
    owner = next((u for u in db.list_users(tenant_id) if u["role"] == "owner"), None)
    return owner["email"] if owner else None


def _add_overage(tenant: dict, invoice: dict) -> None:
    """When Stripe drafts a renewal invoice, add a line for extra invoices read last period."""
    if invoice.get("billing_reason") != "subscription_cycle" or invoice.get("status") != "draft":
        return
    p = plans.get(tenant["plan"])
    start = tenant.get("period_start")
    if not start:
        return
    used = db.count_invoices_since(tenant["id"], start)
    extra = max(0, used - p["invoices"])
    if not extra:
        return
    _call("POST", "/invoiceitems", {
        "customer": invoice["customer"], "invoice": invoice["id"], "currency": "gbp",
        "amount": extra * p["overage_pence"],
        "description": f"{extra} extra invoices at {p['overage_pence']}p (package includes {p['invoices']})",
    })
    db.admin_log(tenant["id"], "overage", f"{extra} extra invoices billed", "stripe")


def handle_event(event: dict) -> str:
    etype, obj = event.get("type"), event.get("data", {}).get("object", {})
    if db.q1("SELECT 1 FROM stripe_events WHERE id = ?", (event.get("id"),)):
        return "duplicate"

    tenant = None
    if etype == "checkout.session.completed":
        tid = obj.get("client_reference_id") or (obj.get("metadata") or {}).get("tenant_id")
        tenant = db.get_tenant(int(tid)) if tid else None
        if tenant:
            db.update_tenant(tenant["id"], {"stripe_customer_id": obj.get("customer"),
                                            "stripe_subscription_id": obj.get("subscription")})
            if obj.get("subscription"):
                _apply_subscription(db.get_tenant(tenant["id"]), _call("GET", f"/subscriptions/{obj['subscription']}"))
    else:
        tenant = db.tenant_by_stripe(obj.get("customer"))
        if not tenant and (obj.get("metadata") or {}).get("tenant_id"):
            tenant = db.get_tenant(int(obj["metadata"]["tenant_id"]))
        if tenant:
            if etype in ("customer.subscription.created", "customer.subscription.updated",
                         "customer.subscription.deleted"):
                _apply_subscription(tenant, obj)
            elif etype == "invoice.paid":
                if tenant["status"] in ("past_due", "paused", "trialing"):
                    db.update_tenant(tenant["id"], {"status": "active"})
            elif etype == "invoice.payment_failed":
                db.update_tenant(tenant["id"], {"status": "past_due"})
                email = _owner_email(tenant["id"])
                if email:
                    mailer.payment_failed(email, tenant["name"])
            elif etype == "invoice.created":
                _add_overage(tenant, obj)

    db.stripe_event_seen(event.get("id") or f"noid-{time.time()}", etype or "")
    return "ok" if tenant else "ignored"
