"""2-way and 3-way matching: invoice lines against purchase order lines and goods received,
plus filling in missing invoice details from the PO."""
import difflib
import json
import re

from . import db
from .validation import issue


def _norm(s) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def find_po(business_id: int, inv: dict) -> dict | None:
    ref = _norm(inv.get("po_number"))
    if not ref:
        return None
    for po in db.q("SELECT * FROM purchase_orders WHERE business_id = ? AND status != 'cancelled'", (business_id,)):
        if _norm(po["po_number"]) == ref or (len(ref) >= 4 and _norm(po["po_number"]).endswith(ref)):
            po["lines"] = json.loads(po["lines"] or "[]")
            return po
    return None


def received_by_line(po_id: int) -> dict[int, float]:
    out: dict[int, float] = {}
    for g in db.q("SELECT lines FROM goods_receipts WHERE po_id = ?", (po_id,)):
        for l in json.loads(g["lines"] or "[]"):
            if l.get("po_line") is not None:
                out[int(l["po_line"])] = out.get(int(l["po_line"]), 0) + float(l.get("qty") or 0)
    return out


def invoiced_by_line(po_id: int, exclude_invoice: int | None) -> dict[int, float]:
    out: dict[int, float] = {}
    rows = db.q("""SELECT id, match_detail FROM invoices WHERE po_id = ? AND id != ?
                   AND status IN ('approved', 'posted')""", (po_id, exclude_invoice or -1))
    for r in rows:
        detail = json.loads(r["match_detail"] or "{}")
        for l in detail.get("lines", []):
            if l.get("po_line") is not None:
                out[int(l["po_line"])] = out.get(int(l["po_line"]), 0) + float(l.get("qty") or 0)
    return out


CARRIAGE = re.compile(r"carriage|delivery|freight|shipping|postage|fuel surcharge", re.I)


def _pair(inv_lines: list[dict], po_lines: list[dict]) -> list[int | None]:
    """For each invoice line, the index of the PO line it matches (or None)."""
    used, pairs = set(), []
    for li in inv_lines:
        best, best_score = None, 0.0
        code = _norm(li.get("code"))
        for i, pl in enumerate(po_lines):
            if i in used:
                continue
            if code and code == _norm(pl.get("code")):
                best, best_score = i, 2.0
                break
            score = difflib.SequenceMatcher(None, str(li.get("description", "")).lower(),
                                            str(pl.get("description", "")).lower()).ratio()
            if li.get("unit_price") is not None and pl.get("unit_price") is not None and \
                    abs(float(li["unit_price"]) - float(pl["unit_price"])) < 0.005:
                score += 0.15
            if score > best_score:
                best, best_score = i, score
        if best is not None and best_score >= 0.6:
            used.add(best)
            pairs.append(best)
        else:
            pairs.append(None)
    return pairs


def fill_gaps(inv: dict, po: dict | None, supplier: dict | None) -> list[str]:
    """Complete missing invoice details from the PO and the supplier record. Returns what was filled."""
    filled = []
    if supplier:
        if not inv.get("supplier_vat_number") and supplier.get("vat_number"):
            inv["supplier_vat_number"] = supplier["vat_number"]
            filled.append("supplier VAT number")
        if not inv.get("supplier_email") and supplier.get("email"):
            inv["supplier_email"] = supplier["email"]
    if not po:
        return filled
    extras = inv.setdefault("extras", {}) if isinstance(inv.get("extras"), dict) else inv.setdefault("extras", {})
    if po.get("reference") and not extras.get("reference"):
        extras["reference"] = po["reference"]
        filled.append("project / reference")
    if not inv.get("supplier_email") and po.get("supplier_email"):
        inv["supplier_email"] = po["supplier_email"]
    pairs = _pair(inv.get("line_items") or [], po["lines"])
    for li, idx in zip(inv.get("line_items") or [], pairs):
        if idx is None:
            continue
        pl = po["lines"][idx]
        for key, label in (("code", "product codes"), ("unit", "units"), ("account_code", "account codes")):
            if not li.get(key) and pl.get(key):
                li[key] = pl[key]
                if label not in filled:
                    filled.append(label)
        if li.get("vat_rate") is None and pl.get("vat_rate") is not None:
            li["vat_rate"] = pl["vat_rate"]
            if "VAT rates" not in filled:
                filled.append("VAT rates")
    return filled


def run(inv: dict, business_id: int, settings: dict, invoice_id: int | None = None) -> tuple[dict | None, dict, list[dict]]:
    """Match an invoice. Returns (po, detail, issues). Status in detail: matched, exceptions, no_po, not_required."""
    lines = inv.get("line_items") or []
    po = find_po(business_id, inv)
    need_po = settings.get("require_po")
    issues = []
    if not inv.get("po_number"):
        if need_po and inv.get("document_type") != "credit_note":
            issues.append(issue("error", "po_missing", "No PO number on the invoice, and this business requires one"))
        return None, {"status": "no_po" if need_po else "not_required", "lines": []}, issues
    if not po:
        issues.append(issue("error" if need_po else "warning", "po_not_found",
                            f"PO {inv['po_number']} wasn't found in your purchase orders"))
        return None, {"status": "exceptions", "lines": []}, issues

    three_way = settings.get("match_type") == "three_way"
    supplier_type = (db.get_supplier(business_id, inv.get("supplier_name") or "") or {}).get("match_type")
    if supplier_type in ("two_way", "three_way"):
        three_way = supplier_type == "three_way"
    price_tol = float(settings.get("price_tol_pct") or 0)
    qty_tol = float(settings.get("qty_tol_pct") or 0)
    carriage_allow = float(settings.get("carriage_allowance") or 0)

    if po["status"] in ("draft", "awaiting_approval", "rejected"):
        issues.append(issue("error", "po_not_approved", f"PO {po['po_number']} hasn't been approved"))
    if po["supplier_name"] and inv.get("supplier_name") and \
            difflib.SequenceMatcher(None, po["supplier_name"].lower(), inv["supplier_name"].lower()).ratio() < 0.6:
        issues.append(issue("warning", "po_supplier", f"PO {po['po_number']} was raised with {po['supplier_name']}"))

    received = received_by_line(po["id"]) if three_way else {}
    invoiced = invoiced_by_line(po["id"], invoice_id)
    pairs = _pair(lines, po["lines"])
    detail_lines, ok = [], True
    for n, (li, idx) in enumerate(zip(lines, pairs), 1):
        row = {"n": n, "description": li.get("description"), "qty": li.get("quantity") or 0,
               "unit_price": li.get("unit_price"), "po_line": None, "status": "matched", "note": ""}
        if idx is None:
            if CARRIAGE.search(li.get("description") or "") and (li.get("net_amount") or 0) <= carriage_allow:
                row["status"], row["note"] = "allowed", f"Carriage within £{carriage_allow:g} allowance"
            else:
                row["status"], row["note"] = "not_on_po", "Not on the purchase order"
                issues.append(issue("error", "not_on_po", f"Line {n} ({li.get('description', '')[:40]}) isn't on PO {po['po_number']}"))
                ok = False
            detail_lines.append(row)
            continue
        pl = po["lines"][idx]
        line_no = int(pl.get("line", idx + 1))
        row.update({"po_line": line_no, "po_qty": pl.get("qty"), "po_price": pl.get("unit_price")})
        qty = float(li.get("quantity") or 0)
        already = invoiced.get(line_no, 0)
        if pl.get("unit_price") is not None and li.get("unit_price") is not None:
            po_price, inv_price = float(pl["unit_price"]), float(li["unit_price"])
            if inv_price - po_price > max(0.005, po_price * price_tol / 100):
                row["status"], row["note"] = "price", f"Price {inv_price:.2f} vs PO {po_price:.2f}"
                issues.append(issue("error", "price_variance",
                                    f"Line {n}: price {inv_price:.2f} is above the PO price {po_price:.2f}"))
                ok = False
        limit_base = received.get(line_no, 0) if three_way else float(pl.get("qty") or 0)
        row["received"] = received.get(line_no, 0) if three_way else None
        allowed = limit_base * (1 + qty_tol / 100) - already
        if qty > allowed + 1e-9:
            what = "received" if three_way else "ordered"
            if three_way and limit_base == 0:
                row["status"], row["note"] = "not_received", "Nothing received yet"
                issues.append(issue("error", "not_received", f"Line {n}: no goods received against PO line {line_no} yet"))
            else:
                row["status"], row["note"] = "qty", f"Invoiced {qty:g}, {what} {limit_base:g}" + (f", already invoiced {already:g}" if already else "")
                issues.append(issue("error", "qty_variance",
                                    f"Line {n}: invoiced quantity {qty:g} is more than {what} ({limit_base:g}"
                                    + (f", {already:g} already invoiced)" if already else ")")))
            ok = False
        detail_lines.append(row)

    status = "matched" if ok and not any(i["level"] == "error" for i in issues) else "exceptions"
    if status == "matched":
        issues.append(issue("info", "matched", f"{'3-way' if three_way else '2-way'} matched to PO {po['po_number']}"))
    return po, {"status": status, "type": "three_way" if three_way else "two_way", "po_number": po["po_number"],
                "lines": detail_lines}, issues


def refresh_po_status(po_id: int) -> None:
    po = db.q1("SELECT * FROM purchase_orders WHERE id = ?", (po_id,))
    if not po or po["status"] in ("cancelled", "closed", "draft", "awaiting_approval", "rejected"):
        return
    lines = json.loads(po["lines"] or "[]")
    got = received_by_line(po_id)
    if not got:
        return
    full = all(got.get(int(l.get("line", i + 1)), 0) >= float(l.get("qty") or 0) for i, l in enumerate(lines))
    db.ex("UPDATE purchase_orders SET status = ?, updated_at = ? WHERE id = ?",
          ("received" if full else "part_received", db.now(), po_id))
