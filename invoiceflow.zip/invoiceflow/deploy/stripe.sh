#!/usr/bin/env bash
# Connect Stripe: asks for your secret key, creates packages/prices/webhook/portal in Stripe,
# saves everything to .env and restarts the app.
# Usage (on the server):  bash /root/invoiceflow/deploy/stripe.sh
set -euo pipefail
cd "$(dirname "$0")/.."

echo "Paste your Stripe secret key (starts sk_test_ for testing or sk_live_ for real payments)."
read -rsp "Secret key: " KEY; echo
case "$KEY" in sk_test_*|sk_live_*|rk_test_*|rk_live_*) ;; *) echo "That doesn't look like a Stripe secret key."; exit 1;; esac

set_env() {  # set_env NAME VALUE  (replace or append, value written literally)
  local name="$1" value="$2"
  grep -v "^${name}=" .env > .env.tmp || true
  printf '%s=%s\n' "$name" "$value" >> .env.tmp
  mv .env.tmp .env
}

set_env STRIPE_SECRET_KEY "$KEY"
chmod 600 .env
docker compose build app >/dev/null
OUT=$(docker compose run --rm -T -e STRIPE_SECRET_KEY="$KEY" app python -m app.stripe_setup)
while IFS='=' read -r name value; do
  [ -n "$name" ] && set_env "$name" "$value"
done <<< "$OUT"
chmod 600 .env
docker compose up -d
echo "Stripe is connected. Customers can now subscribe from their Account page."
