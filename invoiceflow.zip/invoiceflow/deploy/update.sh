#!/usr/bin/env bash
# Rebuild and restart after you change the code (data is kept).
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -d .git ]]; then git pull; fi
docker compose up -d --build
docker image prune -f >/dev/null
echo "Updated."
