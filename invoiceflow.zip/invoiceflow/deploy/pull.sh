#!/usr/bin/env bash
# Download the newest invoiceflow.zip from the GitHub repository, back up, and rebuild.
# Usage (on the server):  bash /root/invoiceflow/deploy/pull.sh
set -euo pipefail
REPO="${REPO:-satis4eva/invoiceflow}"
cd /root
bash invoiceflow/deploy/backup.sh || true
SHA=$(curl -fsSL "https://api.github.com/repos/${REPO}/commits/main" | grep -m1 '"sha"' | cut -d'"' -f4 || true)
[ -n "$SHA" ] || { echo "Couldn't read the latest version from GitHub"; exit 1; }
curl -fsSL -o invoiceflow.zip "https://raw.githubusercontent.com/${REPO}/${SHA}/invoiceflow.zip"
unzip -oq invoiceflow.zip
cd invoiceflow
docker compose up -d --build
docker image prune -f >/dev/null
echo "Updated to ${SHA:0:7}"
