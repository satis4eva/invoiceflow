#!/usr/bin/env bash
# Back up the database and uploaded invoices to /root/backups (keeps 14 days).
# Schedule daily:  (crontab -l 2>/dev/null; echo "30 2 * * * bash /root/invoiceflow/deploy/backup.sh") | crontab -
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /root/backups
STAMP=$(date +%Y%m%d-%H%M)
docker compose exec -T app tar czf - -C /data . > "/root/backups/invoiceflow-${STAMP}.tar.gz"
find /root/backups -name 'invoiceflow-*.tar.gz' -mtime +14 -delete
echo "Saved /root/backups/invoiceflow-${STAMP}.tar.gz"
