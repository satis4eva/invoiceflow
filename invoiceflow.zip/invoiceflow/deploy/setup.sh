#!/usr/bin/env bash
# One-time server setup for InvoiceFlow on a fresh Ubuntu VPS (e.g. Hostinger KVM).
# Usage (as root, from the invoiceflow folder):   bash deploy/setup.sh app.yourdomain.com
set -euo pipefail

DOMAIN="${1:-}"
if [[ -z "$DOMAIN" ]]; then
  echo "Usage: bash deploy/setup.sh app.yourdomain.com"; exit 1
fi
if [[ $EUID -ne 0 ]]; then
  echo "Run this as root (or with sudo)."; exit 1
fi
cd "$(dirname "$0")/.."

echo "==> Installing Docker (if needed)"
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker

echo "==> Opening the firewall for SSH, HTTP and HTTPS"
if command -v ufw >/dev/null 2>&1; then
  ufw allow OpenSSH >/dev/null
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
  ufw --force enable >/dev/null
fi

echo "==> Creating settings file (.env)"
if [[ ! -f .env ]]; then
  cp .env.example .env
  SECRET=$(openssl rand -hex 32)
  sed -i "s|^SECRET_KEY=.*|SECRET_KEY=${SECRET}|" .env
  read -rp "Choose an admin username [admin]: " AUSER
  AUSER=${AUSER:-admin}
  while true; do
    read -rsp "Choose an admin password (12+ characters): " APASS; echo
    [[ ${#APASS} -ge 12 ]] && break
    echo "Too short, try again."
  done
  sed -i "s|^ADMIN_USER=.*|ADMIN_USER=${AUSER}|" .env
  APASS_ESC=$(printf '%s' "$APASS" | sed -e 's/[\\/&|]/\\&/g')
  sed -i "s|^ADMIN_PASSWORD=.*|ADMIN_PASSWORD=${APASS_ESC}|" .env
  read -rp "Anthropic API key for AI reading (press Enter to skip for now): " AKEY
  sed -i "s|^ANTHROPIC_API_KEY=.*|ANTHROPIC_API_KEY=${AKEY}|" .env
fi
# DOMAIN is used by docker-compose for HTTPS and the Xero callback address
grep -q '^DOMAIN=' .env && sed -i "s|^DOMAIN=.*|DOMAIN=${DOMAIN}|" .env || echo "DOMAIN=${DOMAIN}" >> .env
chmod 600 .env

echo "==> Checking your domain points at this server"
MYIP=$(curl -fsS https://api.ipify.org || true)
DNSIP=$(getent ahostsv4 "$DOMAIN" | awk '{print $1; exit}' || true)
if [[ -n "$MYIP" && "$MYIP" != "$DNSIP" ]]; then
  echo "    WARNING: $DOMAIN points to '${DNSIP:-nothing}' but this server is $MYIP."
  echo "    HTTPS will start working once the DNS A record is updated (can take up to an hour)."
fi

echo "==> Building and starting"
docker compose up -d --build

echo
echo "Done. Open https://${DOMAIN} and sign in."
echo "Xero redirect URI to use in the Xero developer portal: https://${DOMAIN}/xero/callback"
