"""End-to-end tests: sign-up, packages, isolation between customers, invoices, billing webhooks, master control.

Run:  python -m tests.test_pipeline   (from the project root)
"""
import csv
import hashlib
import hmac
import io
import json
import os
import re
import shutil
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TMP = Path(tempfile.mkdtemp())
os.environ.update({
    "DATA_DIR": str(TMP), "ANTHROPIC_API_KEY": "", "ADMIN_USER": "admin", "ADMIN_PASSWORD": "test-admin-pass",
    "STRIPE_WEBHOOK_SECRET": "whsec_test", "STRIPE_PRICE_STANDARD_MONTHLY": "price_std_m",
    "STRIPE_PRICE_ADVANCED_MONTHLY": "price_adv_m", "SMTP_HOST": "",
})

from starlette.testclient import TestClient  # noqa: E402

from app import accounts, db, exports, validation, xero  # noqa: E402
from app.main import app  # noqa: E402

SAMPLES = ROOT / "samples"
failures = []


def check(cond, msg):
    print(("  ok   " if cond else "  FAIL ") + msg)
    if not cond:
        failures.append(msg)


def csrf(client, path="/login") -> str:
    return re.search(r'name="csrf" value="([^"]+)"', client.get(path).text).group(1)


def signup(client, company, email, plan="standard"):
    t = csrf(client, "/signup")
    return client.post("/signup", data={"csrf": t, "company": company, "name": "Test", "email": email,
                                        "password": "a-strong-pass-1", "plan": plan, "terms": "1"})


def webhook(client, event):
    body = json.dumps(event).encode()
    ts = int(time.time())
    sig = hmac.new(b"whsec_test", f"{ts}.".encode() + body, hashlib.sha256).hexdigest()
    return client.post("/stripe/webhook", content=body, headers={"stripe-signature": f"t={ts},v1={sig}"})


def main():
    print("Basics")
    check(validation.valid_uk_vat_number("GB284519630"), "valid GB VAT number passes")
    check(not validation.valid_uk_vat_number("GB284519631"), "wrong check digit fails")
    check(accounts.check_password("hello-world-1", accounts.hash_password("hello-world-1")), "password hashing")
    check(not accounts.check_password("nope", accounts.hash_password("hello-world-1")), "wrong password rejected")

    print("Public pages and sign-up")
    a = TestClient(app)
    r = a.get("/")
    check(r.status_code == 200 and "Practice" in r.text and "£299" in r.text, "pricing page shows four packages")
    r = a.get("/app", follow_redirects=False)
    check(r.status_code == 303 and "/login" in r.headers["location"], "app needs sign-in")
    r = signup(a, "Alpha Foods Ltd", "owner@alpha.test", "standard")
    check("free trial of Standard" in r.text, "self sign-up starts a Standard trial")
    alpha = db.list_tenants("alpha")[0]
    check(alpha["status"] == "trialing" and alpha["plan"] == "standard", "account created on trial")
    r = signup(TestClient(app), "Dup Ltd", "owner@alpha.test")
    check("already an account" in r.text, "duplicate email refused")

    print("Invoices inside Alpha")
    token = csrf(a, "/app")
    files = [("files", (p.name, p.read_bytes(), "application/pdf")) for p in sorted(SAMPLES.glob("*.pdf"))]
    r = a.post("/upload", data={"csrf": token}, files=files)
    check("Read 4 documents" in r.text, "four samples uploaded")
    biz_a = db.list_businesses(alpha["id"])[0]
    invs = {i["filename"]: i for i in db.list_invoices(biz_a["id"])}
    clean = invs["01-clean-invoice.pdf"]
    check(clean["supplier_name"] == "Thames Valley Catering Supplies Ltd" and clean["gross_total"] == 527.64,
          "clean invoice extracted")
    check(clean["tenant_id"] == alpha["id"], "invoice tagged with its account")
    wrong = invs["02-total-wrong.pdf"]
    check(any(i["code"] == "totals_mismatch" for i in wrong["issues"]), "wrong total flagged")
    check(invs["04-credit-note.pdf"]["document_type"] == "credit_note", "credit note detected")

    form = {"csrf": token, "action": "approve", "supplier_name": wrong["supplier_name"],
            "invoice_number": wrong["invoice_number"], "invoice_date": wrong["invoice_date"],
            "due_date": wrong["due_date"], "currency": "GBP", "document_type": "invoice",
            "net_total": "63.50", "vat_total": "0.00", "gross_total": "63.50", "line_count": "2",
            "line_0_description": "Red onions", "line_0_quantity": "4", "line_0_unit_price": "11.00",
            "line_0_net_amount": "44.00", "line_0_vat_rate": "0", "line_0_vat_amount": "0", "line_0_account_code": "310",
            "line_1_description": "Coriander", "line_1_quantity": "30", "line_1_unit_price": "0.65",
            "line_1_net_amount": "19.50", "line_1_vat_rate": "0", "line_1_vat_amount": "0", "line_1_account_code": "310"}
    a.post(f"/invoices/{wrong['id']}/save", data=form)
    check(db.get_invoice(wrong["id"])["status"] == "approved", "corrected invoice approved")
    check((db.get_supplier(biz_a["id"], wrong["supplier_name"]) or {}).get("account_code") == "310",
          "supplier coding learned (Standard)")
    r = a.get("/export/xero?status=approved")
    rows = list(csv.DictReader(io.StringIO(r.text)))
    check(len(rows) == 2 and rows[0]["*AccountCode"] == "310", "Xero CSV export")
    endpoint, payload = xero.build_payload(db.get_invoice(invs["04-credit-note.pdf"]["id"]))
    check(endpoint == "CreditNotes", "Xero credit note payload")

    print("Isolation between customers")
    b = TestClient(app)
    signup(b, "Beta Builders", "owner@beta.test", "basic")
    beta = db.list_tenants("beta")[0]
    r = b.get(f"/invoices/{clean['id']}")
    check(r.status_code == 404, "Beta can't open Alpha's invoice")
    r = b.get(f"/invoices/{clean['id']}/file")
    check(r.status_code == 404, "Beta can't download Alpha's file")
    r = b.get("/app")
    check("Thames Valley" not in r.text, "Beta's list doesn't show Alpha's invoices")
    tb = csrf(b, "/app")
    r = b.post(f"/invoices/{clean['id']}/reject", data={"csrf": tb, "reason": "x"})
    check(r.status_code == 404 and db.get_invoice(clean["id"])["status"] != "rejected", "Beta can't change Alpha's invoice")
    r = b.get("/export/xero?status=all")
    check("Thames" not in r.text, "Beta's export has no Alpha data")

    print("Phone photo link")
    r = a.get("/send-link")
    link = re.search(r'id="lnk" value="([^"]+)"', r.text)
    check(r.status_code == 200 and bool(link), "photo link page shows a link")
    token = link.group(1).rsplit("/c/", 1)[1]
    client = TestClient(app)  # the accountant's client: not signed in
    r = client.get(f"/c/{token}")
    check(r.status_code == 200 and "Sending to" in r.text and "Alpha Foods Ltd" in r.text, "client opens the link without logging in")
    ct = re.search(r'name="csrf" value="([^"]+)"', r.text).group(1)
    r = client.post(f"/c/{token}", data={"csrf": "wrong"}, files=[("files", ("a.pdf", b"%PDF", "application/pdf"))],
                    headers={"Accept": "application/json"})
    check(r.status_code == 400, "photo link needs the page's form token")
    before = len(db.list_invoices(biz_a["id"]))
    r = client.post(f"/c/{token}", data={"csrf": ct, "note": "paid by card"},
                    files=[("files", ("receipt.pdf", (SAMPLES / "03-no-vat-number.pdf").read_bytes(), "application/pdf")),
                           ("files", ("photo.png", b"\x89PNG\r\n\x1a\nfake", "image/png"))],
                    headers={"Accept": "application/json"})
    check(r.status_code == 200 and r.json().get("received") == 2, "client sends a PDF and a photo")
    new = [i for i in db.list_invoices(biz_a["id"])][: len(db.list_invoices(biz_a["id"])) - before]
    check(len(new) == 2 and all(i["source"] == "client_link" and i["client_note"] == "paid by card" for i in new),
          "client uploads land in the business queue, tagged with the note")
    check("From client" in a.get("/app").text, "accountant sees 'From client' tag")
    check(client.get(f"/c/{token}x").status_code == 404, "wrong link refused")
    a.post("/send-link", data={"csrf": csrf(a, "/send-link"), "action": "off"})
    r = client.post(f"/c/{token}", data={"csrf": ct}, files=[("files", ("a.pdf", b"%PDF", "application/pdf"))],
                    headers={"Accept": "application/json"})
    check(r.status_code in (403, 404), "switched-off link refuses uploads")
    a.post("/send-link", data={"csrf": csrf(a, "/send-link"), "action": "replace"})
    check(client.get(f"/c/{token}").status_code == 404, "replaced link stops working")
    newtok = db.get_business(biz_a["id"])["capture_token"]
    check(newtok != token and client.get(f"/c/{newtok}").status_code == 200, "new link works")
    check(client.get(f"/c/{newtok}/manifest.json").json()["start_url"] == f"/c/{newtok}", "add-to-home-screen manifest")

    print("Package limits")
    r = b.get("/api/invoices")
    check(r.status_code == 403, "API blocked on Basic")
    r = b.post("/post-xero", data={"csrf": tb, "xero_status": "DRAFT"})
    check("Standard and above" in r.text, "Xero posting blocked on Basic")
    r = b.post("/account/businesses", data={"csrf": tb, "name": "Second"})
    check(len(db.list_businesses(beta["id"])) == 1, "Basic can't add a second business")
    for i in range(2):
        b.post("/account/users", data={"csrf": tb, "email": f"staff{i}@beta.test", "role": "reviewer"})
    check(len(db.list_users(beta["id"])) == 2, "Basic capped at 2 users")
    db.q  # trial cap: fake 150 used
    biz_b = db.list_businesses(beta["id"])[0]
    for _ in range(150):
        db.insert_invoice({"tenant_id": beta["id"], "business_id": biz_b["id"], "filename": "x.pdf",
                           "stored_path": "/dev/null", "file_hash": "h", "status": "rejected"})
    r = b.post("/upload", data={"csrf": tb}, files=[("files", ("one.pdf", (SAMPLES / "03-no-vat-number.pdf").read_bytes(), "application/pdf"))])
    check("used all 150" in r.text, "trial stops at the package limit")

    print("Trial switch and expiry")
    r = b.post("/account/billing/checkout", data={"csrf": tb, "plan": "advanced"})
    check(db.get_tenant(beta["id"])["plan"] == "advanced", "trial can switch package without Stripe")
    r = b.post("/account/businesses", data={"csrf": tb, "name": "Second site"})
    check(len(db.list_businesses(beta["id"])) == 2, "Advanced allows a second business")
    db.update_tenant(beta["id"], {"trial_ends_at": "2000-01-01"})
    r = b.get("/app", follow_redirects=False)
    check(r.status_code == 303 and r.headers["location"] == "/account", "expired trial is sent to billing")
    check(b.get("/account").status_code == 200, "account page still opens after expiry")

    print("Stripe webhooks")
    r = b.post("/stripe/webhook", content=b"{}", headers={"stripe-signature": "t=1,v1=bad"})
    check(r.status_code == 400, "bad webhook signature rejected")
    sub = {"id": "sub_1", "customer": "cus_1", "status": "active", "metadata": {"tenant_id": str(beta["id"])},
           "items": {"data": [{"price": {"id": "price_std_m"}, "current_period_start": int(time.time()) - 60,
                               "current_period_end": int(time.time()) + 30 * 86400}]}}
    r = webhook(b, {"id": "evt_1", "type": "customer.subscription.updated", "data": {"object": sub}})
    t = db.get_tenant(beta["id"])
    check(r.status_code == 200 and t["status"] == "active" and t["plan"] == "standard" and t["stripe_customer_id"] == "cus_1",
          "subscription webhook activates account and sets package")
    r = webhook(b, {"id": "evt_1", "type": "customer.subscription.updated", "data": {"object": sub}})
    check(r.json().get("result") == "duplicate", "repeated webhook ignored")
    check(b.get("/app").status_code == 200, "paid account can use the app again")
    r = webhook(b, {"id": "evt_2", "type": "invoice.payment_failed", "data": {"object": {"customer": "cus_1"}}})
    check(db.get_tenant(beta["id"])["status"] == "past_due", "failed payment marks account past due")
    r = webhook(b, {"id": "evt_3", "type": "invoice.paid", "data": {"object": {"customer": "cus_1"}}})
    check(db.get_tenant(beta["id"])["status"] == "active", "paid invoice restores account")
    allowance, _ = accounts.upload_allowance(db.get_tenant(beta["id"]))
    check(allowance is None, "paying customers aren't capped (extras billed)")
    r = webhook(b, {"id": "evt_4", "type": "customer.subscription.deleted",
                    "data": {"object": {**sub, "status": "canceled"}}})
    check(db.get_tenant(beta["id"])["status"] == "cancelled", "cancelled subscription blocks the account")

    print("Master control")
    m = TestClient(app)
    tm = csrf(m)
    r = m.post("/login", data={"csrf": tm, "email": "admin", "password": "test-admin-pass"})
    check("Master control" in r.text, "admin signs in to master control")
    check(a.get("/admin", follow_redirects=False).headers.get("location") == "/", "customers can't open master control")
    r = m.get("/admin/accounts")
    check("Alpha Foods Ltd" in r.text and "Beta Builders" in r.text, "admin sees every account")
    tm = csrf(m, "/admin/accounts/new")
    r = m.post("/admin/accounts/new", data={"csrf": tm, "company": "Gamma Accountants", "name": "G", "email": "g@gamma.test",
                                            "plan": "practice", "access": "free", "days": "60"})
    gamma = db.list_tenants("gamma")[0]
    check(gamma["plan"] == "practice" and accounts.access(gamma)["state"] == "comped", "admin creates a free Practice account")
    check("/invite/" in r.text, "owner invite link given when email is off")
    owner = db.user_by_email("g@gamma.test")
    g = TestClient(app)
    tg = csrf(g, f"/invite/{owner['token']}")
    g.post(f"/invite/{owner['token']}", data={"csrf": tg, "password": "gamma-pass-123", "name": "Gina"})
    check(g.get("/app").status_code == 200, "invited owner sets a password and gets in")
    m.post(f"/admin/accounts/{beta['id']}/update", data={"csrf": tm, "action": "comp", "months": "2"})
    check(accounts.access(db.get_tenant(beta["id"]))["ok"], "free months re-open a cancelled account")
    m.post(f"/admin/accounts/{alpha['id']}/update", data={"csrf": tm, "action": "pause"})
    check(a.get("/app", follow_redirects=False).status_code == 303, "paused account is blocked")
    m.post(f"/admin/accounts/{alpha['id']}/update", data={"csrf": tm, "action": "activate"})
    check(a.get("/app").status_code == 200, "re-activated account works")
    r = m.post(f"/admin/accounts/{alpha['id']}/view-as", data={"csrf": tm})
    check("Support view" in r.text and "Alpha Foods" in r.text, "view as customer")
    r = m.post("/admin/exit-view", data={"csrf": tm})
    check("Package and details" in r.text, "back to master control")
    alpha_owner = db.user_by_email("owner@alpha.test")
    r = m.post(f"/admin/users/{alpha_owner['id']}", data={"csrf": tm, "action": "reset"})
    temp = re.search(r"Temporary password for owner@alpha.test: (\S+)", r.text)
    check(bool(temp), "admin sets a temporary password")
    if temp:
        x = TestClient(app)
        r = x.post("/login", data={"csrf": csrf(x), "email": "owner@alpha.test", "password": temp.group(1)})
        check("Supplier invoices" in r.text, "customer signs in with the temporary password")
    m.post(f"/admin/accounts/{alpha['id']}/update", data={"csrf": tm, "action": "close"})
    x = TestClient(app)
    r = x.post("/login", data={"csrf": csrf(x), "email": "owner@alpha.test", "password": temp.group(1) if temp else ""})
    check("don't match" in r.text or "don&#39;t match" in r.text, "closed account's users can't sign in")
    r = m.get("/admin")
    check(r.status_code == 200 and "Monthly recurring revenue" in r.text, "dashboard renders")

    email_and_esign(g, b)
    extras = globals().get("purchasing_tests")
    if extras:
        extras(g)

    shutil.rmtree(TMP, ignore_errors=True)
    print()
    print("ALL PASSED" if not failures else f"{len(failures)} FAILED")
    return 1 if failures else 0


SENT = []


class FakeSMTP:
    """Stands in for a real mail server: records messages, rejects the password 'bad'."""
    def __init__(self, host, port=0, context=None, timeout=None):
        self.host = host

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def starttls(self, context=None):
        pass

    def login(self, user, password):
        import smtplib
        if password == "bad":
            raise smtplib.SMTPAuthenticationError(535, b"bad credentials")

    def send_message(self, msg):
        SENT.append(msg)


def _png_signature() -> str:
    import base64
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (300, 100), (0, 0, 0, 0))
    ImageDraw.Draw(img).line([(10, 80), (120, 20), (200, 70), (290, 30)], fill=(29, 38, 54, 255), width=4)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def email_and_esign(g, b):
    from pypdf import PdfReader
    from app import mailboxes
    mailboxes.smtplib.SMTP = FakeSMTP
    mailboxes.smtplib.SMTP_SSL = FakeSMTP
    mailboxes.check_host = lambda host: None
    mailboxes._imap_save_sent = lambda settings, msg: None

    print("Email from each business")
    check("part of the" in b.get("/email").text, "email is locked on Standard")
    r = g.get("/email")
    check("Connect your work email first" in r.text, "Practice account is asked to connect a mailbox")
    t = csrf(g, "/email/mailboxes")
    r = g.post("/email/mailboxes", data={"csrf": t, "preset": "hostinger", "from_email": "gina@gamma.test",
                                         "from_name": "Gamma Accountants", "password": "bad", "shared": "1"})
    check("rejected the username or password" in r.text, "wrong mailbox password is caught before saving")
    r = g.post("/email/mailboxes", data={"csrf": t, "preset": "hostinger", "from_email": "gina@gamma.test",
                                         "from_name": "Gamma Accountants", "password": "secret-pw-1", "shared": "1"})
    box = db.q1("SELECT * FROM mailboxes WHERE from_email = 'gina@gamma.test'")
    check(box is not None and "secret-pw-1" not in box["config_enc"], "mailbox connected, password stored encrypted")
    gamma_biz = db.list_businesses(box["tenant_id"])[0]
    r = g.post("/email/send", data={"csrf": t, "mailbox_id": str(box["id"]), "to": "client@acme.test",
                                    "subject": "Year-end docs", "body": "Hi,\nplease see attached."},
               files=[("files", ("notes.txt", b"hello", "text/plain"))])
    msg = SENT[-1] if SENT else None
    check(msg is not None and msg["To"] == "client@acme.test" and "Gamma Accountants" in msg["From"]
          and any(p.get_filename() == "notes.txt" for p in msg.iter_attachments()), "email sent with attachment")
    check("Year-end docs" in g.get("/email").text, "email kept on the business record")
    row = db.q1("SELECT * FROM emails WHERE subject = 'Year-end docs'")
    check(row and row["business_id"] == gamma_biz["id"] and row["status"] == "sent", "email logged against the business")
    r = g.post("/email/send", data={"csrf": t, "mailbox_id": str(box["id"]), "to": "not-an-email",
                                    "subject": "x", "body": "y"})
    check("a valid email address" in r.text, "bad address refused")

    print("E-signing")
    check("part of the" in b.get("/esign").text, "e-sign is locked on Standard")
    t = csrf(g, "/esign/new")
    pdf = (SAMPLES / "01-clean-invoice.pdf").read_bytes()
    r = g.post("/esign/new", data={"csrf": t, "title": "Engagement letter 2026", "name_0": "Ann Client",
                                   "email_0": "ann@acme.test", "name_1": "Bob Director", "email_1": "bob@acme.test",
                                   "message": "Please sign by Friday"},
               files=[("file", ("letter.pdf", pdf, "application/pdf"))], follow_redirects=False)
    check(r.status_code == 303 and r.headers["location"].endswith("/prepare"), "upload goes to placing signatures")
    rid = int(r.headers["location"].split("/")[2])
    check(g.get(f"/esign/{rid}/prepare").status_code == 200, "prepare page renders")
    img = g.get(f"/esign/{rid}/page/0.png")
    check(img.status_code == 200 and img.content[:4] == b"\x89PNG", "page preview rendered")
    check(b.get(f"/esign/{rid}").status_code == 404, "another account can't see the request")
    signers = db.q("SELECT * FROM sign_signers WHERE request_id = ? ORDER BY position", (rid,))
    fields = {str(signers[0]["id"]): [{"page": 0, "x": 0.55, "y": 0.8, "w": 0.3, "h": 0.07}]}
    before = len(SENT)
    g.post(f"/esign/{rid}/send", data={"csrf": t, "fields": json.dumps(fields), "by_email": "1"})
    invites = SENT[before:]
    check(len(invites) == 2 and all("/sign/" in m.get_body(("plain",)).get_content() for m in invites),
          "each signer emailed their own link from the accountant's mailbox")
    check(db.q1("SELECT status FROM sign_requests WHERE id = ?", (rid,))["status"] == "sent", "request marked sent")

    ann, bob = TestClient(app), TestClient(app)
    r = ann.get(f"/sign/{signers[0]['token']}")
    check(r.status_code == 200 and "Sign here" in r.text and "Engagement letter 2026" in r.text, "signer opens link without an account")
    check(ann.get(f"/sign/{signers[0]['token']}/page/0.png").status_code == 200, "signer sees the pages")
    ta = re.search(r'name="csrf" value="([^"]+)"', r.text).group(1)
    r = ann.post(f"/sign/{signers[0]['token']}", data={"csrf": ta, "signed_name": "Ann Client", "kind": "drawn",
                                                      "drawing": _png_signature()})
    check("agree to sign electronically" in r.text, "consent is required")
    ann.post(f"/sign/{signers[0]['token']}", data={"csrf": ta, "signed_name": "Ann Client", "kind": "drawn",
                                                  "drawing": _png_signature(), "consent": "1"})
    check(db.q1("SELECT status FROM sign_signers WHERE id = ?", (signers[0]["id"],))["status"] == "signed", "first signer signed")
    r = bob.get(f"/sign/{signers[1]['token']}")
    tb2 = re.search(r'name="csrf" value="([^"]+)"', r.text).group(1)
    before = len(SENT)
    r = bob.post(f"/sign/{signers[1]['token']}", data={"csrf": tb2, "signed_name": "Bob Director", "kind": "typed",
                                                      "typed": "Bob Director", "consent": "1"})
    check("Everyone has signed" in r.text, "second signer completes the document")
    req = db.q1("SELECT * FROM sign_requests WHERE id = ?", (rid,))
    check(req["status"] == "completed" and req["final_path"] and Path(req["final_path"]).exists(), "signed PDF created")
    signed = PdfReader(req["final_path"])
    check(len(signed.pages) >= 2 and "Signature certificate" in signed.pages[-1].extract_text(), "certificate page added")
    check("Ann Client" in signed.pages[0].extract_text(), "signature stamped on the page")
    returned = SENT[before:]
    check(len(returned) == 3 and all(any(p.get_filename(" ").endswith("signed.pdf") for p in m.iter_attachments()) for m in returned),
          "signed copy emailed to both signers and back to the accountant")
    d = bob.get(f"/sign/{signers[1]['token']}/download")
    check(d.status_code == 200 and d.content[:4] == b"%PDF", "signer downloads the signed copy")
    check(g.get(f"/esign/{rid}/file/signed").status_code == 200, "accountant downloads the signed copy")
    check(TestClient(app).get("/sign/not-a-real-token-123456789").status_code == 404, "wrong signing link refused")

    t = csrf(g, "/esign/new")
    r = g.post("/esign/new", data={"csrf": t, "title": "Tax return", "name_0": "Cara", "email_0": "cara@acme.test",
                                   "access_code": "4321"}, files=[("file", ("tr.pdf", pdf, "application/pdf"))],
               follow_redirects=False)
    rid2 = int(r.headers["location"].split("/")[2])
    g.post(f"/esign/{rid2}/send", data={"csrf": t, "fields": "{}", "by_email": "1"})
    cara_tok = db.q1("SELECT token FROM sign_signers WHERE request_id = ?", (rid2,))["token"]
    cara = TestClient(app)
    r = cara.get(f"/sign/{cara_tok}")
    check("Enter your access code" in r.text, "access code asked for")
    check(cara.get(f"/sign/{cara_tok}/page/0.png").status_code == 404, "pages hidden until the code is entered")
    tc = re.search(r'name="csrf" value="([^"]+)"', r.text).group(1)
    r = cara.post(f"/sign/{cara_tok}/code", data={"csrf": tc, "code": "0000"})
    check("That code" in r.text, "wrong code refused")
    r = cara.post(f"/sign/{cara_tok}/code", data={"csrf": tc, "code": "4321"})
    check("Sign document" in r.text, "right code opens the document")
    r = cara.post(f"/sign/{cara_tok}/decline", data={"csrf": tc, "reason": "Figures wrong"})
    check(db.q1("SELECT status FROM sign_requests WHERE id = ?", (rid2,))["status"] == "declined", "signer can decline with a reason")
    r = g.post(f"/esign/{rid}/action", data={"csrf": t, "action": "delete"})
    check(db.q1("SELECT 1 FROM sign_requests WHERE id = ?", (rid,)) is not None, "completed documents can't be deleted")



def ubl_invoice(number, po, lines, supplier="Thames Valley Catering Supplies Ltd", vat_no="GB284519630", days_ago=2):
    from datetime import date, timedelta
    d = (date.today() - timedelta(days=days_ago)).isoformat()
    net = sum(q * p for _, _, q, p in lines)
    vat = round(net * 0.2, 2)
    body = "".join(f"""<cac:InvoiceLine><cbc:ID>{i}</cbc:ID><cbc:InvoicedQuantity unitCode="C62">{q}</cbc:InvoicedQuantity>
      <cbc:LineExtensionAmount currencyID="GBP">{q * p:.2f}</cbc:LineExtensionAmount>
      <cac:Item><cbc:Name>{desc}</cbc:Name><cac:SellersItemIdentification><cbc:ID>{code}</cbc:ID></cac:SellersItemIdentification>
      <cac:ClassifiedTaxCategory><cbc:ID>S</cbc:ID><cbc:Percent>20</cbc:Percent><cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:ClassifiedTaxCategory></cac:Item>
      <cac:Price><cbc:PriceAmount currencyID="GBP">{p:.2f}</cbc:PriceAmount></cac:Price></cac:InvoiceLine>"""
                   for i, (code, desc, q, p) in enumerate(lines, 1))
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
 xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
 xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
 <cbc:CustomizationID>urn:cen.eu:en16931:2017#compliant#urn:fdc:peppol.eu:2017:poacc:billing:3.0</cbc:CustomizationID>
 <cbc:ID>{number}</cbc:ID><cbc:IssueDate>{d}</cbc:IssueDate><cbc:DueDate>{d}</cbc:DueDate>
 <cbc:InvoiceTypeCode>380</cbc:InvoiceTypeCode><cbc:DocumentCurrencyCode>GBP</cbc:DocumentCurrencyCode>
 <cac:OrderReference><cbc:ID>{po}</cbc:ID></cac:OrderReference>
 <cac:AccountingSupplierParty><cac:Party><cbc:EndpointID schemeID="9932">{vat_no}</cbc:EndpointID>
  <cac:PartyTaxScheme><cbc:CompanyID>{vat_no}</cbc:CompanyID><cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:PartyTaxScheme>
  <cac:PartyLegalEntity><cbc:RegistrationName>{supplier}</cbc:RegistrationName></cac:PartyLegalEntity></cac:Party></cac:AccountingSupplierParty>
 <cac:TaxTotal><cbc:TaxAmount currencyID="GBP">{vat:.2f}</cbc:TaxAmount></cac:TaxTotal>
 <cac:LegalMonetaryTotal><cbc:TaxExclusiveAmount currencyID="GBP">{net:.2f}</cbc:TaxExclusiveAmount>
  <cbc:PayableAmount currencyID="GBP">{net + vat:.2f}</cbc:PayableAmount></cac:LegalMonetaryTotal>
 {body}
</Invoice>""".encode()


def new_po(g, number, supplier, lines, email="orders@supplier.test", action="save"):
    t = csrf(g, "/purchasing/new")
    data = {"csrf": t, "po_number": number, "supplier_name": supplier, "supplier_email": email, "action": action}
    for i, (code, desc, q, p) in enumerate(lines):
        data.update({f"l{i}_code": code, f"l{i}_description": desc, f"l{i}_qty": str(q), f"l{i}_unit_price": str(p),
                     f"l{i}_vat_rate": "20"})
    r = g.post("/purchasing/new", data=data, follow_redirects=False)
    return int(r.headers["location"].rsplit("/", 1)[1]) if r.status_code == 303 and "/purchasing/" in r.headers["location"] else None


def purchasing_tests(g):
    from app import einvoice
    print("Purchase orders and 3-way matching")
    t = csrf(g, "/settings/rules")
    g.post("/settings/rules", data={"csrf": t, "action": "matching", "match_type": "three_way", "price_tol_pct": "0",
                                    "qty_tol_pct": "0", "total_tol": "1", "carriage_allowance": "10",
                                    "auto_approve_matched": "1", "po_approval_limit": "0", "po_prefix": "PO-"})
    lines = [("GN-65", "Stainless gastronorm pans 1/1 x 65mm", 12, 18.50), ("CF-450", "Commercial cling film 450mm", 6, 14.95),
             ("GL-100", "Blue nitrile gloves, box of 100", 20, 6.40)]
    pid = new_po(g, "PO-2231", "Thames Valley Catering Supplies Ltd", lines)
    po = db.q1("SELECT * FROM purchase_orders WHERE id = ?", (pid,)) if pid else None
    check(po is not None and po["status"] == "approved" and po["gross_total"] == 527.64, "purchase order raised and approved")
    check("PO-2231" in g.get("/purchasing").text, "order listed")
    biz = db.get_business(po["business_id"])
    t = csrf(g, "/app")
    g.post("/upload", data={"csrf": t}, files=[("files", ("inv.pdf", (SAMPLES / "01-clean-invoice.pdf").read_bytes(), "application/pdf"))])
    inv = db.list_invoices(biz["id"])[0]
    check(inv["po_id"] == pid and inv["match_status"] == "exceptions" and any(i["code"] == "not_received" for i in inv["issues"]),
          "3-way: invoice held until goods are received")
    r = g.get(f"/invoices/{inv['id']}")
    check("3-way match to" in r.text and "Nothing received yet" in r.text, "review screen shows the match lines")
    g.post(f"/purchasing/{pid}/receive", data={"csrf": t, "r0": "12", "r1": "6", "r2": "20", "delivery_note": "DN-1"})
    inv = db.get_invoice(inv["id"])
    check(inv["match_status"] == "matched" and not [i for i in inv["issues"] if i["code"] in ("not_received", "qty_variance")],
          "receiving goods re-matches the waiting invoice")
    check(db.q1("SELECT status FROM purchase_orders WHERE id = ?", (pid,))["status"] == "received", "order marked received")
    detail = g.get(f"/purchasing/{pid}").text
    check("Invoices against this order" in detail and "DN-1" in detail, "order shows deliveries and invoices")

    print("E-invoicing")
    parsed = einvoice.parse(ubl_invoice("EI-1", "PO-4000", [("A1", "Bolts M8", 10, 2.5)]))
    check(parsed["invoice_number"] == "EI-1" and parsed["line_items"][0]["code"] == "A1" and parsed["confidence"] == 1.0,
          "Peppol UBL invoice read exactly")
    cii = b"""<rsm:CrossIndustryInvoice xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
      xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"
      xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
      <rsm:ExchangedDocument><ram:ID>CII-9</ram:ID><ram:TypeCode>380</ram:TypeCode><ram:IssueDateTime><udt:DateTimeString format="102">20261020</udt:DateTimeString></ram:IssueDateTime></rsm:ExchangedDocument>
      <rsm:SupplyChainTradeTransaction><ram:ApplicableHeaderTradeAgreement><ram:SellerTradeParty><ram:Name>CII Supplier</ram:Name></ram:SellerTradeParty></ram:ApplicableHeaderTradeAgreement>
      <ram:ApplicableHeaderTradeSettlement><ram:InvoiceCurrencyCode>GBP</ram:InvoiceCurrencyCode><ram:SpecifiedTradeSettlementHeaderMonetarySummation>
      <ram:TaxBasisTotalAmount>100.00</ram:TaxBasisTotalAmount><ram:TaxTotalAmount currencyID="GBP">20.00</ram:TaxTotalAmount><ram:DuePayableAmount>120.00</ram:DuePayableAmount>
      </ram:SpecifiedTradeSettlementHeaderMonetarySummation></ram:ApplicableHeaderTradeSettlement></rsm:SupplyChainTradeTransaction></rsm:CrossIndustryInvoice>"""
    p2 = einvoice.parse(cii)
    check(p2["invoice_number"] == "CII-9" and p2["invoice_date"] == "2026-10-20" and p2["gross_total"] == 120.0, "CII invoice read")
    try:
        einvoice.parse(b'<?xml version="1.0"?><!DOCTYPE x [<!ENTITY a "b">]><x/>')
        check(False, "unsafe XML refused")
    except einvoice.EInvoiceError:
        check(True, "unsafe XML refused")
    pid2 = new_po(g, "PO-4000", "Thames Valley Catering Supplies Ltd", [("A1", "Bolts M8", 10, 2.50), ("A2", "Washers M8", 10, 0.40)])
    g.post(f"/purchasing/{pid2}/receive", data={"csrf": t, "r0": "10", "r1": "10"})
    xml = ubl_invoice("EI-100", "PO-4000", [("A1", "Bolts M8", 10, 2.50), ("A2", "Washers M8", 10, 0.40)])
    g.post("/upload", data={"csrf": t}, files=[("files", ("einvoice.xml", xml, "application/xml"))])
    ei = db.list_invoices(biz["id"])[0]
    check(ei["extraction_method"] == "e-invoice" and ei["match_status"] == "matched" and ei["status"] == "approved",
          "matched e-invoice approved automatically, no human touch")
    xml_bad = ubl_invoice("EI-101", "PO-4000", [("A1", "Bolts M8", 10, 2.95)])
    g.post("/upload", data={"csrf": t}, files=[("files", ("e2.xml", xml_bad, "application/xml"))])
    bad = db.list_invoices(biz["id"])[0]
    check(any(i["code"] == "price_variance" for i in bad["issues"]) and bad["status"] == "needs_review",
          "price above the PO is caught")
    check(any(i["code"] == "qty_variance" for i in bad["issues"]), "re-invoicing goods already invoiced is caught")
    xml_extra = ubl_invoice("EI-102", "PO-4000", [("Z9", "Mystery item", 1, 50)])
    g.post("/upload", data={"csrf": t}, files=[("files", ("e3.xml", xml_extra, "application/xml"))])
    check(any(i["code"] == "not_on_po" for i in db.list_invoices(biz["id"])[0]["issues"]), "line not on the PO is caught")

    print("E-ordering")
    pid3 = new_po(g, "PO-5000", "Fresh Fish Co", [("SAL", "Salmon fillet kg", 5, 21.0)], email="sales@fish.test", action="send")
    before = len(SENT)
    po3 = db.q1("SELECT * FROM purchase_orders WHERE id = ?", (pid3,))
    sent_msg = SENT[-1] if SENT else None
    names = [p.get_filename() for p in sent_msg.iter_attachments()] if sent_msg else []
    check(po3["status"] == "sent" and "PO-5000.pdf" in names and "PO-5000.xml" in names, "order emailed with PDF and Peppol order XML")
    sup = TestClient(app)
    r = sup.get(f"/po/{po3['ack_token']}")
    check(r.status_code == 200 and "Salmon fillet" in r.text, "supplier opens the order link")
    ts = re.search(r'name="csrf" value="([^"]+)"', r.text).group(1)
    sup.post(f"/po/{po3['ack_token']}", data={"csrf": ts, "action": "accept", "note": "Delivering Thursday"})
    po3 = db.q1("SELECT * FROM purchase_orders WHERE id = ?", (pid3,))
    check(po3["status"] == "acknowledged" and po3["ack_note"] == "Delivering Thursday", "supplier confirms the order")
    check(g.get(f"/purchasing/{pid3}/file/xml").text.startswith("<?xml") and
          g.get(f"/purchasing/{pid3}/file/pdf").content[:4] == b"%PDF", "order PDF and XML download")
    t = csrf(g, "/settings/rules")
    g.post("/settings/rules", data={"csrf": t, "action": "matching", "match_type": "three_way", "price_tol_pct": "0",
                                    "qty_tol_pct": "0", "total_tol": "1", "carriage_allowance": "10",
                                    "po_approval_limit": "1000", "po_prefix": "PO-"})
    csv_body = "PO number,Supplier,Code,Description,Qty,Unit price\nPO-6000,Builder Depot,CEM,Cement 25kg,40,6.5\nPO-6000,Builder Depot,SND,Sharp sand,10,45\n"
    g.post("/purchasing/import", data={"csrf": t}, files=[("file", ("pos.csv", csv_body.encode(), "text/csv"))])
    imp = db.q1("SELECT * FROM purchase_orders WHERE po_number = 'PO-6000'")
    check(imp is not None and imp["source"] == "csv" and imp["gross_total"] == round((40 * 6.5 + 450) * 1.2, 2), "orders imported from CSV")

    print("Business rules and industries")
    t = csrf(g, "/settings/rules")
    g.post("/settings/rules", data={"csrf": t, "action": "add_rule", "name": "Thames needs a look", "field_0": "supplier_name",
                                    "op_0": "contains", "value_0": "thames", "rule_action": "warning", "message": "Check Thames prices"})
    g.post("/settings/recheck", data={"csrf": t})
    waiting = [i for i in db.list_invoices(biz["id"]) if i["status"] in ("needs_review", "ready")]
    check(waiting and all(any(x["message"] == "Check Thames prices" for x in i["issues"]) for i in waiting
                          if "Thames" in (i["supplier_name"] or "")), "custom rule applied to waiting invoices")
    g.post("/settings/rules", data={"csrf": t, "action": "add_rule", "name": "Code fuel", "field_0": "supplier_name",
                                    "op_0": "contains", "value_0": "thames", "rule_action": "set_account", "rule_value": "449"})
    from app import rules as rules_mod
    check(len(rules_mod.settings_for(biz["id"])["rules"]) == 2, "rules saved per business")
    g.post("/settings/rules", data={"csrf": t, "action": "industry", "industry": "construction", "starter": "1"})
    st = rules_mod.settings_for(biz["id"])
    check(st["industry"] == "construction" and st["require_po"] and st["rules"][0]["action"] == "needs_manager",
          "construction set-up applies its tolerances and starter rules")
    g.post("/upload", data={"csrf": t}, files=[("files", ("cis.pdf", (SAMPLES / "03-no-vat-number.pdf").read_bytes(), "application/pdf"))])
    target = db.list_invoices(biz["id"])[0]
    r = g.get(f"/invoices/{target['id']}")
    check("CIS deduction rate" in r.text and "Construction details" in r.text, "construction fields shown for review")
    form = {"csrf": t, "action": "save", "supplier_name": "Bob Groundworks", "invoice_number": "BG-1", "invoice_date": target["invoice_date"],
            "currency": "GBP", "document_type": "invoice", "net_total": "1500", "vat_total": "300", "gross_total": "1800",
            "po_number": "", "line_count": "1", "line_0_description": "Groundworks labour and materials", "line_0_quantity": "1",
            "line_0_unit_price": "1500", "line_0_net_amount": "1500", "line_0_vat_rate": "20", "line_0_vat_amount": "300",
            "x_cis_labour": "1000", "x_cis_materials": "500", "x_cis_rate": "20", "x_cis_deduction": "150",
            "x_reverse_charge": "yes", "x_retention_pct": "5", "x_retention_amount": "75"}
    g.post(f"/invoices/{target['id']}/save", data=form)
    codes = {i["code"] for i in db.get_invoice(target["id"])["issues"]}
    check({"cis_maths", "reverse_charge_vat", "po_missing"} <= codes, "CIS maths, reverse charge VAT and missing PO caught")
    form.update({"x_cis_deduction": "200", "vat_total": "0", "gross_total": "1500", "line_0_vat_rate": "0", "line_0_vat_amount": "0"})
    g.post(f"/invoices/{target['id']}/save", data=form)
    inv = db.get_invoice(target["id"])
    check(not {"cis_maths", "reverse_charge_vat"} & {i["code"] for i in inv["issues"]}, "correct CIS and reverse charge pass")
    check("1,225.00" in g.get(f"/invoices/{target['id']}").text, "amount to pay after CIS and retention shown (1,500 - 200 - 75)")
    g.post("/settings/rules", data={"csrf": t, "action": "industry", "industry": "general", "starter": "1"})

    print("Statement reconciliation")
    stmt = ("Date,Reference,Type,Amount\n"
            f"{date_str(5)},TVC-10482,Invoice,527.64\n{date_str(4)},TVC-99999,Invoice,120.00\n"
            f"{date_str(3)},CN-777,Credit,44.40\n{date_str(2)},EI-100,Invoice,99.00\n{date_str(1)},BACS,Payment,300\n")
    r = g.post("/statements/upload", data={"csrf": t, "supplier": "Thames Valley Catering Supplies Ltd"},
               files=[("file", ("statement.csv", stmt.encode(), "text/csv"))])
    s = db.q1("SELECT * FROM statements ORDER BY id DESC LIMIT 1")
    res = json.loads(s["result"])
    by = {row["reference"]: row["status"] for row in res["rows"]}
    check(by.get("TVC-10482") == "matched" and by.get("TVC-99999") == "missing" and by.get("CN-777") == "missing_credit"
          and by.get("EI-100") == "different" and by.get("BACS") == "payment", "statement lines matched, missing, missing credit and different")
    check("Invoices you don" in r.text and "TVC-99999" in r.text, "statement page lists what's missing")
    before = len(SENT)
    box = db.q1("SELECT id FROM mailboxes WHERE from_email = 'gina@gamma.test'")
    body = re.search(r'<textarea id="bd" name="body" rows="10">(.*?)</textarea>', r.text, re.S)
    g.post(f"/statements/{s['id']}/request", data={"csrf": t, "mailbox_id": str(box["id"]), "to": "accounts@tvcatering.test",
                                                    "body": body.group(1) if body else "Missing"})
    check(len(SENT) == before + 1 and "TVC-99999" in SENT[-1].get_body(("plain",)).get_content(), "request for missing copies emailed")

    print("API and Peppol")
    g.post("/settings/api-keys", data={"csrf": t, "action": "create", "label": "ERP"})
    msg = g.get("/settings").text
    key = re.search(r"(ifk_[A-Za-z0-9_\-]+)", g.get("/app").text) or re.search(r"(ifk_[A-Za-z0-9_\-]+)", msg)
    raw = None
    for row in [db.q1("SELECT * FROM api_keys ORDER BY id DESC LIMIT 1")]:
        raw = row and row["prefix"]
    api = TestClient(app)
    check(api.get("/api/v1/invoices").status_code == 401, "API needs a key")
    import hashlib as _h
    newkey = "ifk_testkey_" + "x" * 20
    db.ex("INSERT INTO api_keys (tenant_id, business_id, label, key_hash, prefix, created_at) VALUES (?, ?, 'test', ?, 'ifk_test', ?)",
          (biz["tenant_id"], biz["id"], _h.sha256(newkey.encode()).hexdigest(), db.now()))
    r = api.post("/api/v1/invoices", headers={"Authorization": f"Bearer {newkey}"},
                 files={"file": ("api.xml", ubl_invoice("API-1", "", [("Q1", "Service", 1, 10)]), "application/xml")})
    check(r.status_code == 201 and r.json()["id"], "invoice sent in through the API")
    r = api.get("/api/v1/invoices", headers={"Authorization": f"Bearer {newkey}"})
    check(r.status_code == 200 and any(i["invoice_number"] == "API-1" for i in r.json()), "API lists invoices")
    os.environ["PEPPOL_WEBHOOK_SECRET"] = "peppol-secret"
    g.post("/settings/peppol", data={"csrf": t, "peppol_id": "0088:5012345678900"})
    import base64 as _b
    payload = {"recipient": "0088:5012345678900", "id": "MSG1", "document": _b.b64encode(ubl_invoice("PEP-1", "", [("P1", "Parts", 2, 5)])).decode()}
    check(api.post("/peppol/inbound", json=payload, headers={"X-Peppol-Secret": "wrong"}).status_code == 401, "Peppol webhook needs its secret")
    r = api.post("/peppol/inbound", json=payload, headers={"X-Peppol-Secret": "peppol-secret"})
    pep = db.get_invoice(r.json().get("invoice_id", 0)) if r.status_code == 200 else None
    check(pep is not None and pep["source"] == "peppol" and pep["invoice_number"] == "PEP-1", "invoice received over Peppol lands in the right business")


def date_str(days_ago):
    from datetime import date, timedelta
    return (date.today() - timedelta(days=days_ago)).strftime("%d/%m/%Y")


if __name__ == "__main__":
    raise SystemExit(main())
