"""End-to-end tests: sign-up, packages, isolation between customers, invoices, billing webhooks, master control.

Run:  python -m tests.test_pipeline   (from the project root)
"""
import csv
import hashlib
import hmac
import io
import json
import os
import re
import shutil
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TMP = Path(tempfile.mkdtemp())
os.environ.update({
    "DATA_DIR": str(TMP), "ANTHROPIC_API_KEY": "", "ADMIN_USER": "admin", "ADMIN_PASSWORD": "test-admin-pass",
    "STRIPE_WEBHOOK_SECRET": "whsec_test", "STRIPE_PRICE_STANDARD_MONTHLY": "price_std_m",
    "STRIPE_PRICE_ADVANCED_MONTHLY": "price_adv_m", "SMTP_HOST": "",
})

from starlette.testclient import TestClient  # noqa: E402

from app import accounts, db, exports, validation, xero  # noqa: E402
from app.main import app  # noqa: E402

SAMPLES = ROOT / "samples"
failures = []


def check(cond, msg):
    print(("  ok   " if cond else "  FAIL ") + msg)
    if not cond:
        failures.append(msg)


def csrf(client, path="/login") -> str:
    return re.search(r'name="csrf" value="([^"]+)"', client.get(path).text).group(1)


def signup(client, company, email, plan="standard"):
    t = csrf(client, "/signup")
    return client.post("/signup", data={"csrf": t, "company": company, "name": "Test", "email": email,
                                        "password": "a-strong-pass-1", "plan": plan, "terms": "1"})


def webhook(client, event):
    body = json.dumps(event).encode()
    ts = int(time.time())
    sig = hmac.new(b"whsec_test", f"{ts}.".encode() + body, hashlib.sha256).hexdigest()
    return client.post("/stripe/webhook", content=body, headers={"stripe-signature": f"t={ts},v1={sig}"})


def main():
    print("Basics")
    check(validation.valid_uk_vat_number("GB284519630"), "valid GB VAT number passes")
    check(not validation.valid_uk_vat_number("GB284519631"), "wrong check digit fails")
    check(accounts.check_password("hello-world-1", accounts.hash_password("hello-world-1")), "password hashing")
    check(not accounts.check_password("nope", accounts.hash_password("hello-world-1")), "wrong password rejected")

    print("Public pages and sign-up")
    a = TestClient(app)
    r = a.get("/")
    check(r.status_code == 200 and "Practice" in r.text and "£299" in r.text, "pricing page shows four packages")
    r = a.get("/app", follow_redirects=False)
    check(r.status_code == 303 and "/login" in r.headers["location"], "app needs sign-in")
    r = signup(a, "Alpha Foods Ltd", "owner@alpha.test", "standard")
    check("free trial of Standard" in r.text, "self sign-up starts a Standard trial")
    alpha = db.list_tenants("alpha")[0]
    check(alpha["status"] == "trialing" and alpha["plan"] == "standard", "account created on trial")
    r = signup(TestClient(app), "Dup Ltd", "owner@alpha.test")
    check("already an account" in r.text, "duplicate email refused")

    print("Invoices inside Alpha")
    token = csrf(a, "/app")
    files = [("files", (p.name, p.read_bytes(), "application/pdf")) for p in sorted(SAMPLES.glob("*.pdf"))]
    r = a.post("/upload", data={"csrf": token}, files=files)
    check("Read 4 documents" in r.text, "four samples uploaded")
    biz_a = db.list_businesses(alpha["id"])[0]
    invs = {i["filename"]: i for i in db.list_invoices(biz_a["id"])}
    clean = invs["01-clean-invoice.pdf"]
    check(clean["supplier_name"] == "Thames Valley Catering Supplies Ltd" and clean["gross_total"] == 527.64,
          "clean invoice extracted")
    check(clean["tenant_id"] == alpha["id"], "invoice tagged with its account")
    wrong = invs["02-total-wrong.pdf"]
    check(any(i["code"] == "totals_mismatch" for i in wrong["issues"]), "wrong total flagged")
    check(invs["04-credit-note.pdf"]["document_type"] == "credit_note", "credit note detected")

    form = {"csrf": token, "action": "approve", "supplier_name": wrong["supplier_name"],
            "invoice_number": wrong["invoice_number"], "invoice_date": wrong["invoice_date"],
            "due_date": wrong["due_date"], "currency": "GBP", "document_type": "invoice",
            "net_total": "63.50", "vat_total": "0.00", "gross_total": "63.50", "line_count": "2",
            "line_0_description": "Red onions", "line_0_quantity": "4", "line_0_unit_price": "11.00",
            "line_0_net_amount": "44.00", "line_0_vat_rate": "0", "line_0_vat_amount": "0", "line_0_account_code": "310",
            "line_1_description": "Coriander", "line_1_quantity": "30", "line_1_unit_price": "0.65",
            "line_1_net_amount": "19.50", "line_1_vat_rate": "0", "line_1_vat_amount": "0", "line_1_account_code": "310"}
    a.post(f"/invoices/{wrong['id']}/save", data=form)
    check(db.get_invoice(wrong["id"])["status"] == "approved", "corrected invoice approved")
    check((db.get_supplier(biz_a["id"], wrong["supplier_name"]) or {}).get("account_code") == "310",
          "supplier coding learned (Standard)")
    r = a.get("/export/xero?status=approved")
    rows = list(csv.DictReader(io.StringIO(r.text)))
    check(len(rows) == 2 and rows[0]["*AccountCode"] == "310", "Xero CSV export")
    endpoint, payload = xero.build_payload(db.get_invoice(invs["04-credit-note.pdf"]["id"]))
    check(endpoint == "CreditNotes", "Xero credit note payload")

    print("Isolation between customers")
    b = TestClient(app)
    signup(b, "Beta Builders", "owner@beta.test", "basic")
    beta = db.list_tenants("beta")[0]
    r = b.get(f"/invoices/{clean['id']}")
    check(r.status_code == 404, "Beta can't open Alpha's invoice")
    r = b.get(f"/invoices/{clean['id']}/file")
    check(r.status_code == 404, "Beta can't download Alpha's file")
    r = b.get("/app")
    check("Thames Valley" not in r.text, "Beta's list doesn't show Alpha's invoices")
    tb = csrf(b, "/app")
    r = b.post(f"/invoices/{clean['id']}/reject", data={"csrf": tb, "reason": "x"})
    check(r.status_code == 404 and db.get_invoice(clean["id"])["status"] != "rejected", "Beta can't change Alpha's invoice")
    r = b.get("/export/xero?status=all")
    check("Thames" not in r.text, "Beta's export has no Alpha data")

    print("Package limits")
    r = b.get("/api/invoices")
    check(r.status_code == 403, "API blocked on Basic")
    r = b.post("/post-xero", data={"csrf": tb, "xero_status": "DRAFT"})
    check("Standard and above" in r.text, "Xero posting blocked on Basic")
    r = b.post("/account/businesses", data={"csrf": tb, "name": "Second"})
    check(len(db.list_businesses(beta["id"])) == 1, "Basic can't add a second business")
    for i in range(2):
        b.post("/account/users", data={"csrf": tb, "email": f"staff{i}@beta.test", "role": "reviewer"})
    check(len(db.list_users(beta["id"])) == 2, "Basic capped at 2 users")
    db.q  # trial cap: fake 150 used
    biz_b = db.list_businesses(beta["id"])[0]
    for _ in range(150):
        db.insert_invoice({"tenant_id": beta["id"], "business_id": biz_b["id"], "filename": "x.pdf",
                           "stored_path": "/dev/null", "file_hash": "h", "status": "rejected"})
    r = b.post("/upload", data={"csrf": tb}, files=[("files", ("one.pdf", (SAMPLES / "03-no-vat-number.pdf").read_bytes(), "application/pdf"))])
    check("used all 150" in r.text, "trial stops at the package limit")

    print("Trial switch and expiry")
    r = b.post("/account/billing/checkout", data={"csrf": tb, "plan": "advanced"})
    check(db.get_tenant(beta["id"])["plan"] == "advanced", "trial can switch package without Stripe")
    r = b.post("/account/businesses", data={"csrf": tb, "name": "Second site"})
    check(len(db.list_businesses(beta["id"])) == 2, "Advanced allows a second business")
    db.update_tenant(beta["id"], {"trial_ends_at": "2000-01-01"})
    r = b.get("/app", follow_redirects=False)
    check(r.status_code == 303 and r.headers["location"] == "/account", "expired trial is sent to billing")
    check(b.get("/account").status_code == 200, "account page still opens after expiry")

    print("Stripe webhooks")
    r = b.post("/stripe/webhook", content=b"{}", headers={"stripe-signature": "t=1,v1=bad"})
    check(r.status_code == 400, "bad webhook signature rejected")
    sub = {"id": "sub_1", "customer": "cus_1", "status": "active", "metadata": {"tenant_id": str(beta["id"])},
           "items": {"data": [{"price": {"id": "price_std_m"}, "current_period_start": int(time.time()) - 60,
                               "current_period_end": int(time.time()) + 30 * 86400}]}}
    r = webhook(b, {"id": "evt_1", "type": "customer.subscription.updated", "data": {"object": sub}})
    t = db.get_tenant(beta["id"])
    check(r.status_code == 200 and t["status"] == "active" and t["plan"] == "standard" and t["stripe_customer_id"] == "cus_1",
          "subscription webhook activates account and sets package")
    r = webhook(b, {"id": "evt_1", "type": "customer.subscription.updated", "data": {"object": sub}})
    check(r.json().get("result") == "duplicate", "repeated webhook ignored")
    check(b.get("/app").status_code == 200, "paid account can use the app again")
    r = webhook(b, {"id": "evt_2", "type": "invoice.payment_failed", "data": {"object": {"customer": "cus_1"}}})
    check(db.get_tenant(beta["id"])["status"] == "past_due", "failed payment marks account past due")
    r = webhook(b, {"id": "evt_3", "type": "invoice.paid", "data": {"object": {"customer": "cus_1"}}})
    check(db.get_tenant(beta["id"])["status"] == "active", "paid invoice restores account")
    allowance, _ = accounts.upload_allowance(db.get_tenant(beta["id"]))
    check(allowance is None, "paying customers aren't capped (extras billed)")
    r = webhook(b, {"id": "evt_4", "type": "customer.subscription.deleted",
                    "data": {"object": {**sub, "status": "canceled"}}})
    check(db.get_tenant(beta["id"])["status"] == "cancelled", "cancelled subscription blocks the account")

    print("Master control")
    m = TestClient(app)
    tm = csrf(m)
    r = m.post("/login", data={"csrf": tm, "email": "admin", "password": "test-admin-pass"})
    check("Master control" in r.text, "admin signs in to master control")
    check(a.get("/admin", follow_redirects=False).headers.get("location") == "/", "customers can't open master control")
    r = m.get("/admin/accounts")
    check("Alpha Foods Ltd" in r.text and "Beta Builders" in r.text, "admin sees every account")
    tm = csrf(m, "/admin/accounts/new")
    r = m.post("/admin/accounts/new", data={"csrf": tm, "company": "Gamma Accountants", "name": "G", "email": "g@gamma.test",
                                            "plan": "practice", "access": "free", "days": "60"})
    gamma = db.list_tenants("gamma")[0]
    check(gamma["plan"] == "practice" and accounts.access(gamma)["state"] == "comped", "admin creates a free Practice account")
    check("/invite/" in r.text, "owner invite link given when email is off")
    owner = db.user_by_email("g@gamma.test")
    g = TestClient(app)
    tg = csrf(g, f"/invite/{owner['token']}")
    g.post(f"/invite/{owner['token']}", data={"csrf": tg, "password": "gamma-pass-123", "name": "Gina"})
    check(g.get("/app").status_code == 200, "invited owner sets a password and gets in")
    m.post(f"/admin/accounts/{beta['id']}/update", data={"csrf": tm, "action": "comp", "months": "2"})
    check(accounts.access(db.get_tenant(beta["id"]))["ok"], "free months re-open a cancelled account")
    m.post(f"/admin/accounts/{alpha['id']}/update", data={"csrf": tm, "action": "pause"})
    check(a.get("/app", follow_redirects=False).status_code == 303, "paused account is blocked")
    m.post(f"/admin/accounts/{alpha['id']}/update", data={"csrf": tm, "action": "activate"})
    check(a.get("/app").status_code == 200, "re-activated account works")
    r = m.post(f"/admin/accounts/{alpha['id']}/view-as", data={"csrf": tm})
    check("Support view" in r.text and "Alpha Foods" in r.text, "view as customer")
    r = m.post("/admin/exit-view", data={"csrf": tm})
    check("Package and details" in r.text, "back to master control")
    alpha_owner = db.user_by_email("owner@alpha.test")
    r = m.post(f"/admin/users/{alpha_owner['id']}", data={"csrf": tm, "action": "reset"})
    temp = re.search(r"Temporary password for owner@alpha.test: (\S+)", r.text)
    check(bool(temp), "admin sets a temporary password")
    if temp:
        x = TestClient(app)
        r = x.post("/login", data={"csrf": csrf(x), "email": "owner@alpha.test", "password": temp.group(1)})
        check("Supplier invoices" in r.text, "customer signs in with the temporary password")
    m.post(f"/admin/accounts/{alpha['id']}/update", data={"csrf": tm, "action": "close"})
    x = TestClient(app)
    r = x.post("/login", data={"csrf": csrf(x), "email": "owner@alpha.test", "password": temp.group(1) if temp else ""})
    check("don't match" in r.text or "don&#39;t match" in r.text, "closed account's users can't sign in")
    r = m.get("/admin")
    check(r.status_code == 200 and "Monthly recurring revenue" in r.text, "dashboard renders")

    shutil.rmtree(TMP, ignore_errors=True)
    print()
    print("ALL PASSED" if not failures else f"{len(failures)} FAILED")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
