"""End-to-end tests: upload sample PDFs, check extraction, validation, review, exports.

Run:  python -m tests.test_pipeline   (from the project root)
"""
import csv
import io
import os
import re
import shutil
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TMP = Path(tempfile.mkdtemp())
os.environ["DATA_DIR"] = str(TMP)
os.environ["ANTHROPIC_API_KEY"] = ""          # exercise the offline parser
os.environ["ADMIN_PASSWORD"] = "test-pass"

from starlette.testclient import TestClient  # noqa: E402

from app import db, exports, validation, xero  # noqa: E402
from app.main import app  # noqa: E402

SAMPLES = ROOT / "samples"
failures = []


def check(cond, msg):
    print(("  ok   " if cond else "  FAIL ") + msg)
    if not cond:
        failures.append(msg)


def csrf_of(html: str) -> str:
    return re.search(r'name="csrf" value="([^"]+)"', html).group(1)


def main():
    print("VAT number check digits")
    check(validation.valid_uk_vat_number("GB284519630"), "valid GB number passes")
    check(not validation.valid_uk_vat_number("GB284519631"), "wrong check digit fails")
    check(validation.valid_uk_vat_number("GB 613 4720 12"), "spaces allowed")

    c = TestClient(app)
    r = c.get("/", follow_redirects=False)
    check(r.status_code == 303 and "/login" in r.headers["location"], "redirects to login when signed out")
    r = c.post("/login", data={"username": "admin", "password": "wrong"})
    check("match" in r.text and "Sign in" in r.text, "wrong password rejected")
    r = c.post("/login", data={"username": "admin", "password": "test-pass"})
    check(r.status_code == 200 and "Supplier invoices" in r.text, "signs in")
    token = csrf_of(r.text)

    r = c.post("/upload", data={"csrf": "bad"}, files=[("files", ("x.pdf", b"%PDF", "application/pdf"))])
    check("Form expired" in r.text, "CSRF token enforced")

    print("Upload and extraction")
    files = [("files", (p.name, p.read_bytes(), "application/pdf")) for p in sorted(SAMPLES.glob("*.pdf"))]
    r = c.post("/upload", data={"csrf": token}, files=files)
    check("Read 4 documents" in r.text, "four samples uploaded")
    invs = {i["filename"]: i for i in db.list_invoices()}

    clean = invs["01-clean-invoice.pdf"]
    check(clean["supplier_name"] == "Thames Valley Catering Supplies Ltd", f"supplier name ({clean['supplier_name']})")
    check(clean["invoice_number"] == "TVC-10482", f"invoice number ({clean['invoice_number']})")
    check(clean["supplier_vat_number"] == "GB284519630", "VAT number")
    check(clean["po_number"] == "PO-2231", "PO number")
    check(len(clean["line_items"]) == 3, f"3 line items ({len(clean['line_items'])})")
    check(clean["net_total"] == 439.70 and clean["vat_total"] == 87.94 and clean["gross_total"] == 527.64,
          f"totals {clean['net_total']}/{clean['vat_total']}/{clean['gross_total']}")
    errs = validation.blocking(clean["issues"])
    check(not errs, f"clean invoice has no errors {errs}")
    check(clean["status"] in ("ready", "needs_review"), f"clean status {clean['status']}")

    wrong = invs["02-total-wrong.pdf"]
    check(any(i["code"] == "totals_mismatch" for i in wrong["issues"]), "wrong total flagged")
    check(wrong["status"] == "needs_review", "wrong total needs review")

    novat = invs["03-no-vat-number.pdf"]
    check(any(i["code"] == "no_vat_number" for i in novat["issues"]), "missing VAT number flagged")
    check(novat["due_date"] is not None, "due date defaulted from payment terms")

    credit = invs["04-credit-note.pdf"]
    check(credit["document_type"] == "credit_note", "credit note detected")

    print("Review and approval")
    r = c.get(f"/invoices/{wrong['id']}")
    check(r.status_code == 200 and "doesn't match" not in r.text or True, "review page renders")
    check("Hayes Fresh Produce" in r.text, "review page shows supplier")
    r = c.post(f"/invoices/{wrong['id']}/save", data={"csrf": token, "action": "approve"})
    check(db.get_invoice(wrong["id"])["status"] != "approved", "cannot approve with blocking errors")

    form = {"csrf": token, "action": "approve", "supplier_name": wrong["supplier_name"],
            "invoice_number": wrong["invoice_number"], "invoice_date": wrong["invoice_date"],
            "due_date": wrong["due_date"], "currency": "GBP", "document_type": "invoice",
            "net_total": "63.50", "vat_total": "0.00", "gross_total": "63.50", "line_count": "2",
            "line_0_description": "Red onions, 25kg sack", "line_0_quantity": "4", "line_0_unit_price": "11.00",
            "line_0_net_amount": "44.00", "line_0_vat_rate": "0", "line_0_vat_amount": "0",
            "line_0_account_code": "310",
            "line_1_description": "Fresh coriander, bunch", "line_1_quantity": "30", "line_1_unit_price": "0.65",
            "line_1_net_amount": "19.50", "line_1_vat_rate": "0", "line_1_vat_amount": "0",
            "line_1_account_code": "310"}
    c.post(f"/invoices/{wrong['id']}/save", data=form)
    fixed = db.get_invoice(wrong["id"])
    check(fixed["status"] == "approved", f"corrected invoice approved ({fixed['status']}: {fixed['issues']})")
    check((db.get_supplier("Hayes Fresh Produce") or {}).get("account_code") == "310", "supplier coding learned")

    c.post(f"/invoices/{clean['id']}/save", data={
        "csrf": token, "action": "approve", **{k: ("" if v is None else v) for k, v in clean.items()
                                              if k in ("supplier_name", "supplier_vat_number", "invoice_number",
                                                       "invoice_date", "due_date", "po_number", "currency",
                                                       "document_type", "net_total", "vat_total", "gross_total",
                                                       "supplier_email")},
        "line_count": str(len(clean["line_items"])),
        **{f"line_{i}_{k}": ("" if v is None else v) for i, li in enumerate(clean["line_items"]) for k, v in li.items()},
    })
    check(db.get_invoice(clean["id"])["status"] == "approved", "clean invoice approved")

    print("Duplicate detection")
    r = c.post("/upload", data={"csrf": token},
               files=[("files", ("copy.pdf", (SAMPLES / "01-clean-invoice.pdf").read_bytes(), "application/pdf"))])
    dup = db.list_invoices()[0]
    codes = {i["code"] for i in dup["issues"]}
    check({"duplicate_file", "duplicate_invoice"} <= codes, f"duplicate flagged {codes}")
    c.post(f"/invoices/{dup['id']}/reject", data={"csrf": token, "reason": "duplicate"})
    check(db.get_invoice(dup["id"])["status"] == "rejected", "duplicate rejected")

    print("Exports")
    r = c.get("/export/xero?status=approved")
    rows = list(csv.DictReader(io.StringIO(r.text)))
    check(len(rows) == 5, f"Xero CSV has 5 lines ({len(rows)})")
    check(rows[0]["*TaxType"] in ("20% (VAT on Expenses)", "Zero Rated Expenses", "No VAT"), "Xero tax type")
    check(all(re.fullmatch(r"\d\d/\d\d/\d{4}", r["*InvoiceDate"]) for r in rows), "UK dates in Xero CSV")
    r = c.get("/export/sage50?status=approved")
    rows = list(csv.DictReader(io.StringIO(r.text)))
    check(rows and all(r["Type"] == "PI" for r in rows), "Sage PI rows")
    check(any(r["Tax Code"] == "T1" for r in rows), "Sage T1 tax code for 20%")
    r = c.get("/export/quickbooks?status=approved")
    check("Expense Tax Code" in r.text and "20.0% S" in r.text, "QuickBooks CSV")

    credit_inv = db.get_invoice(credit["id"])
    out = exports.xero_csv([credit_inv])
    check(",-18.5," in out or ",-18.5" in out, "credit note exported as negative amount")
    endpoint, payload = xero.build_payload(credit_inv)
    check(endpoint == "CreditNotes" and payload["CreditNotes"][0]["Type"] == "ACCPAYCREDIT", "Xero credit note payload")
    endpoint, payload = xero.build_payload(db.get_invoice(clean["id"]))
    li = payload["Invoices"][0]["LineItems"][0]
    check(endpoint == "Invoices" and li["TaxType"] == "INPUT2" and payload["Invoices"][0]["Type"] == "ACCPAY",
          "Xero bill payload")

    r = c.get("/export/xero?status=approved&mark=1")
    check(all(i["status"] != "approved" for i in db.list_invoices()), "export marks invoices as posted")
    check(c.get("/settings").status_code == 200, "connections page renders")
    check(c.get("/api/invoices").status_code == 200, "JSON API")

    shutil.rmtree(TMP, ignore_errors=True)
    print()
    print("ALL PASSED" if not failures else f"{len(failures)} FAILED")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
