"""Generate realistic UK sample invoices for demos and tests.

    python samples/make_samples.py   ->  writes PDFs into samples/
"""
from datetime import date, timedelta
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet

OUT = Path(__file__).parent
TODAY = date.today()


def uk(d: date) -> str:
    return d.strftime("%d/%m/%Y")


def make(filename, supplier, address, vat_no, email, title, number, inv_date, due, po, lines,
         vat_rate=20, override_total=None):
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(OUT / filename), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm)
    story = [
        Paragraph(f"<b>{supplier}</b>", styles["Title"]),
        Paragraph(address, styles["Normal"]),
        Paragraph(f"Email: {email}", styles["Normal"]),
    ]
    if vat_no:
        story.append(Paragraph(f"VAT Reg No: {vat_no}", styles["Normal"]))
    story += [Spacer(1, 8 * mm), Paragraph(f"<b>{title}</b>", styles["Heading2"])]
    meta = [f"{'Credit Note' if 'CREDIT' in title else 'Invoice'} No: {number}", f"Invoice Date: {uk(inv_date)}"]
    if due:
        meta.append(f"Due Date: {uk(due)}")
    if po:
        meta.append(f"PO Number: {po}")
    meta.append("Bill to: Demo Buyer Ltd, 1 High Street, London W1 1AA")
    for m in meta:
        story.append(Paragraph(m, styles["Normal"]))
    story.append(Spacer(1, 6 * mm))

    rows = [["Description", "Qty", "Unit Price", "VAT %", "Net Amount"]]
    net = 0
    for desc, qty, unit in lines:
        amt = round(qty * unit, 2)
        net += amt
        rows.append([desc, f"{qty:g}", f"{unit:,.2f}", f"{vat_rate}%", f"{amt:,.2f}"])
    net = round(net, 2)
    vat = round(net * vat_rate / 100, 2)
    total = override_total if override_total is not None else round(net + vat, 2)
    t = Table(rows, colWidths=[80 * mm, 15 * mm, 25 * mm, 18 * mm, 30 * mm])
    t.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.black),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
    ]))
    story += [t, Spacer(1, 6 * mm)]
    totals = Table([["Subtotal:", f"£{net:,.2f}"], [f"VAT @ {vat_rate}%:", f"£{vat:,.2f}"],
                    ["Total Due:", f"£{total:,.2f}"]], colWidths=[40 * mm, 30 * mm], hAlign="RIGHT")
    totals.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "RIGHT"), ("FONT", (0, 2), (-1, 2), "Helvetica-Bold")]))
    story += [totals, Spacer(1, 10 * mm), Paragraph("Payment by BACS within 30 days. Thank you for your business.", styles["Normal"])]
    doc.build(story)


def main():
    d1 = TODAY - timedelta(days=5)
    make("01-clean-invoice.pdf", "Thames Valley Catering Supplies Ltd",
         "Unit 4, Brunel Park, Slough SL1 4QT", "GB284519630", "accounts@tvcatering.co.uk",
         "TAX INVOICE", "TVC-10482", d1, d1 + timedelta(days=30), "PO-2231",
         [("Stainless gastronorm pans 1/1 x 65mm", 12, 18.50), ("Commercial cling film 450mm", 6, 14.95),
          ("Blue nitrile gloves, box of 100", 20, 6.40)])

    d2 = TODAY - timedelta(days=12)
    make("02-total-wrong.pdf", "Hayes Fresh Produce",
         "Arch 22, Western International Market, Hayes UB3 1DB", "GB613472012", "orders@hayesfresh.co.uk",
         "INVOICE", "HFP-7731", d2, d2 + timedelta(days=14), None,
         [("Red onions, 25kg sack", 4, 11.00), ("Fresh coriander, bunch", 30, 0.65)],
         vat_rate=0, override_total=75.50)

    d3 = TODAY - timedelta(days=3)
    make("03-no-vat-number.pdf", "QuickFix Kitchen Repairs",
         "45 Station Road, Feltham TW13 4AZ", None, "quickfix.repairs@gmail.com",
         "INVOICE", "QF-0098", d3, None, None,
         [("Call-out and labour: tandoor oven thermostat", 1, 145.00), ("Replacement thermostat", 1, 62.00)])

    d4 = TODAY - timedelta(days=2)
    make("04-credit-note.pdf", "Thames Valley Catering Supplies Ltd",
         "Unit 4, Brunel Park, Slough SL1 4QT", "GB284519630", "accounts@tvcatering.co.uk",
         "CREDIT NOTE", "TVC-CN-0211", d4, None, "PO-2231",
         [("Returned: gastronorm pans damaged in transit", 2, 18.50)])
    print("Samples written to", OUT)


if __name__ == "__main__":
    main()
