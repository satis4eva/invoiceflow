# Putting InvoiceFlow online with Hostinger

You'll end up with the app at `https://app.yourdomain.com`. Allow about 45 minutes.

## 1. Buy a VPS
1. In hPanel go to **VPS** and choose **KVM 2** (2 CPU, 8 GB RAM). KVM 1 also works for a single buyer.
2. Pick a location close to your users, such as the United Kingdom or Europe.
3. Operating system: **Ubuntu 24.04** (plain, no control panel).
4. Set a strong **root password** and save it in a password manager.
5. When it's ready, copy the server's **IP address** from the VPS overview page.

## 2. Point your domain at the server
1. In hPanel go to **Domains**, choose your domain, then **DNS / Nameservers**.
2. Add a record:
   - Type: **A**
   - Name: **app**
   - Points to: *your VPS IP*
   - TTL: **300**
3. Save. It usually takes 5 to 30 minutes to take effect.

If your domain is registered somewhere else, add the same A record there.

## 3. Copy the software to the server
From your own computer, open Terminal (Mac) or PowerShell (Windows) in the folder that contains `invoiceflow.zip`:

```
scp invoiceflow.zip root@YOUR_VPS_IP:/root/
```

Type `yes` if asked to trust the server, then enter the root password.

## 4. Install and start it
Connect to the server, either with `ssh root@YOUR_VPS_IP` or with the **Browser terminal** button in hPanel. Then run:

```
apt update && apt install -y unzip
cd /root && unzip invoiceflow.zip && cd invoiceflow
bash deploy/setup.sh app.yourdomain.com
```

The script asks for an admin username, a password, and your Anthropic API key. You can leave the key blank and add it later. It installs everything, turns on HTTPS and starts the app.

## 5. Sign in
Open `https://app.yourdomain.com` and sign in. Upload the four PDFs in `samples/` to check it works.

## 6. Add AI reading later (if you skipped it)
```
cd /root/invoiceflow
nano .env          # fill in ANTHROPIC_API_KEY=..., then Ctrl+O, Enter, Ctrl+X
docker compose up -d
```

## 7. Connect Xero
1. Go to developer.xero.com, then **My Apps**, **New app**, **Web app**.
2. Set the redirect URI to `https://app.yourdomain.com/xero/callback`.
3. Put the client ID and secret into `.env` (`XERO_CLIENT_ID`, `XERO_CLIENT_SECRET`), then run `docker compose up -d`.
4. In the app, open **Connections** and choose **Connect Xero**.

## 8. Turn on backups
```
(crontab -l 2>/dev/null; echo "30 2 * * * bash /root/invoiceflow/deploy/backup.sh") | crontab -
```
Also turn on weekly snapshots under VPS, Snapshots & Backups in hPanel.

## Everyday commands
| Task | Command (run inside /root/invoiceflow) |
|---|---|
| Restart | `docker compose restart` |
| See logs | `docker compose logs -f app` |
| Apply a new version | upload the new files, then `bash deploy/update.sh` |
| Back up now | `bash deploy/backup.sh` |

## If something goes wrong
- **Browser says the site can't be reached:** the DNS record isn't live yet, or it points at the wrong IP. Check with `ping app.yourdomain.com`.
- **Certificate or "not secure" warning:** wait 10 minutes after DNS starts working, then run `docker compose restart caddy`.
- **Sign-in doesn't stick:** make sure you are using `https://`, not `http://`.
- **Anything else:** `docker compose logs --tail 100` shows the error. Paste it to Claude.
