# Putting InvoiceFlow online with Hostinger

You'll end up with the app at `https://app.yourdomain.com`. Allow about 45 minutes.

## 1. Buy a VPS
1. In hPanel go to **VPS** and choose **KVM 2** (2 CPU, 8 GB RAM). KVM 1 also works for a single buyer.
2. Pick a location close to your users, such as the United Kingdom or Europe.
3. Operating system: **Ubuntu 24.04** (plain, no control panel).
4. Set a strong **root password** and save it in a password manager.
5. When it's ready, copy the server's **IP address** from the VPS overview page.

## 2. Point your domain at the server
1. In hPanel go to **Domains**, choose your domain, then **DNS / Nameservers**.
2. Add a record:
   - Type: **A**
   - Name: **app**
   - Points to: *your VPS IP*
   - TTL: **300**
3. Save. It usually takes 5 to 30 minutes to take effect.

If your domain is registered somewhere else, add the same A record there.

## 3. Copy the software to the server
From your own computer, open Terminal (Mac) or PowerShell (Windows) in the folder that contains `invoiceflow.zip`:

```
scp invoiceflow.zip root@YOUR_VPS_IP:/root/
```

Type `yes` if asked to trust the server, then enter the root password.

## 4. Install and start it
Connect to the server, either with `ssh root@YOUR_VPS_IP` or with the **Browser terminal** button in hPanel. Then run:

```
apt update && apt install -y unzip
cd /root && unzip invoiceflow.zip && cd invoiceflow
bash deploy/setup.sh app.yourdomain.com
```

The script asks for an admin username, a password, and your Anthropic API key. You can leave the key blank and add it later. It installs everything, turns on HTTPS and starts the app.

## 5. Sign in
Open `https://app.yourdomain.com` and sign in. Upload the four PDFs in `samples/` to check it works.

## 6. Add AI reading later (if you skipped it)
```
cd /root/invoiceflow
nano .env          # fill in ANTHROPIC_API_KEY=..., then Ctrl+O, Enter, Ctrl+X
docker compose up -d
```

## 7. Connect Xero
1. Go to developer.xero.com, then **My Apps**, **New app**, **Web app**.
2. Set the redirect URI to `https://app.yourdomain.com/xero/callback`.
3. Put the client ID and secret into `.env` (`XERO_CLIENT_ID`, `XERO_CLIENT_SECRET`), then run `docker compose up -d`.
4. In the app, open **Connections** and choose **Connect Xero**.

## 8. Turn on backups
```
(crontab -l 2>/dev/null; echo "30 2 * * * bash /root/invoiceflow/deploy/backup.sh") | crontab -
```
Also turn on weekly snapshots under VPS, Snapshots & Backups in hPanel.

## Everyday commands
| Task | Command (run inside /root/invoiceflow) |
|---|---|
| Restart | `docker compose restart` |
| See logs | `docker compose logs -f app` |
| Apply a new version | upload the new files, then `bash deploy/update.sh` |
| Back up now | `bash deploy/backup.sh` |

## If something goes wrong
- **Browser says the site can't be reached:** the DNS record isn't live yet, or it points at the wrong IP. Check with `ping app.yourdomain.com`.
- **Certificate or "not secure" warning:** wait 10 minutes after DNS starts working, then run `docker compose restart caddy`.
- **Sign-in doesn't stick:** make sure you are using `https://`, not `http://`.
- **Anything else:** `docker compose logs --tail 100` shows the error. Paste it to Claude.

## Master control and customer sign-up
- Customers sign up themselves at `https://app.yourdomain.com/signup` (or from the pricing page), pick a package and start a free trial.
- You sign in at `https://app.yourdomain.com/login` with the admin login and land in **Master control**: every customer, package, usage and revenue; add customers by hand; extend trials; give free months; pause or close accounts; reset passwords; view any account as the customer.

## Switch on emails (sign-up confirmation, invitations, password resets)
Add your SMTP details to `.env`, then run `docker compose up -d`. With a Hostinger mailbox:
```
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=hello@yourdomain.com
SMTP_PASSWORD=<mailbox password>
MAIL_FROM=YourBrand <hello@yourdomain.com>
```

## Switch on card payments (Stripe)
1. In Stripe, go to **Product catalogue** and add four products (Basic, Standard, Advanced, Practice), each with a **monthly** and a **yearly** recurring price in GBP.
2. Copy each price ID (starts `price_`) into `.env` as `STRIPE_PRICE_BASIC_MONTHLY`, `STRIPE_PRICE_BASIC_YEARLY` and so on.
3. **Developers, API keys:** copy the secret key into `STRIPE_SECRET_KEY`.
4. **Developers, Webhooks, Add endpoint:** URL `https://app.yourdomain.com/stripe/webhook`, events `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.paid`, `invoice.payment_failed`, `invoice.created`. Copy the signing secret into `STRIPE_WEBHOOK_SECRET`.
5. **Settings, Billing, Customer portal:** allow customers to update cards, switch between your four products and cancel.
6. Run `docker compose up -d`. Test with Stripe's test keys first (card 4242 4242 4242 4242), then switch to live keys.

## Sign in with Google or Microsoft (optional)
Without this, accountants connect any mailbox with its mail settings (works today with Hostinger, Microsoft 365, Gmail app passwords, Zoho and others).
- **Google:** in Google Cloud Console create an OAuth client (Web application), add the redirect URI `https://app.yourdomain.com/mail/oauth/google/callback`, enable the Gmail API, and request the `gmail.send` scope. Google must verify the app before the public can use it (this can take weeks).
- **Microsoft:** in Microsoft Entra, register an app (any organisation + personal accounts), add the redirect URI `https://app.yourdomain.com/mail/oauth/microsoft/callback`, add the delegated permissions `Mail.Send`, `User.Read`, `offline_access`, and create a client secret.
Put the IDs and secrets in `.env` and run `docker compose up -d`. "Sign in with Google / Microsoft" buttons then appear on the Mailboxes page.

## Peppol e-invoicing network (optional)
E-invoice XML (Peppol UBL and CII) is already read when uploaded, sent through the API, or forwarded. To send and receive over the Peppol network you need an accredited Peppol access point partner. Once you sign up with one:
1. Set `PEPPOL_API_URL`, `PEPPOL_API_KEY` and a long random `PEPPOL_WEBHOOK_SECRET` in `.env`.
2. Ask the provider to deliver inbound documents to `https://app.yourdomain.com/peppol/inbound` with the header `X-Peppol-Secret`.
3. Each business enters its Peppol ID under Settings. Adjust `app/peppol.py` to the provider's exact API if it differs.

## API
Advanced and Practice customers create API keys under Settings and can `POST` PDFs, photos or e-invoice XML to `/api/v1/invoices` (multipart field `file`, header `Authorization: Bearer <key>`), and `GET` the same address to list invoices with their match status.

## Supplier payments

Customers pay suppliers from their own accounts; the platform never holds money, so you don't need payment licences for the file, Wise or Airwallex options.

- **Bank payment files** (Standard and above): after approval, customers download a UK bulk payment CSV or an ISO 20022 pain.001 XML file and upload it to their bank's bulk payments screen.
- **Wise and Airwallex** (Advanced and Practice): each customer connects their own account under Payments, then Payment settings. Scheduled payments are sent on their dates by a background job (`PAYMENTS_SCHEDULER=1`) and marked paid when the provider confirms. Test with each provider's sandbox first.
- **Open Banking** (Advanced and Practice): needs a contract with an FCA-authorised payment initiation provider (for example TrueLayer, Yapily or Token). Put their API address and key in `OB_PARTNER_URL` and `OB_PARTNER_KEY`, set a random `OB_WEBHOOK_SECRET`, and point their payment-status webhook at `https://YOUR-DOMAIN/payments/ob/webhook` with the header `X-Webhook-Secret`. The adapter in `app/pay_providers.py` (`ob_create`) may need small changes to match your partner's API.

Safeguards built in: supplier bank details only take effect after a second owner or admin verifies them; the person who prepares a run can't approve it; runs over a set amount can require two approvers; the bank details are frozen at approval; every step is logged. To mark bills paid in Xero, customers reconnect Xero once (to grant the payments permission) and enter their Xero bank account code in Payment settings.
