# InvoiceFlow: supplier invoice automation (MVP)

Reads supplier invoices (PDFs, scans, phone photos), checks them against UK VAT and accounting rules, queues them for approval, then sends approved bills to Xero or exports them for QuickBooks Online and Sage 50.

Rename it by setting `APP_NAME` in `.env`.

## What it does

1. **Capture.** Drag in one or many PDFs or images in the browser.
2. **Read.** AI extraction (Claude API) pulls out the supplier, VAT number, invoice number, dates, PO, every line item, VAT and totals. It handles scans and photos, so no separate OCR engine is needed. Without an API key, a built-in parser reads digital PDFs only.
3. **Check.** Each invoice is validated automatically:
   - Net + VAT = total, and the line items add up to the net.
   - VAT rates are standard UK rates (20/5/0).
   - Supplier VAT number passes the HMRC check-digit test.
   - VAT charged with no VAT number (not reclaimable) is flagged.
   - Duplicates are caught: the same file, or the same supplier and invoice number.
   - Dates are checked: future-dated, older than 6 months, or due before issue.
   - Foreign currency and low-confidence reads are flagged.
4. **Review.** A side-by-side screen shows the original document next to editable fields, with live total checks. Problems are highlighted. Invoices with errors can't be approved.
5. **Learn.** When a reviewer codes a supplier to an account, later invoices from that supplier are coded the same way.
6. **Post.**
   - **Xero:** an OAuth connection sends approved invoices as draft or awaiting-payment bills, with the original PDF attached. Supplier credit notes go in as credits.
   - **QuickBooks Online:** CSV in the bill import layout.
   - **Sage 50 (UK):** CSV in the audit-trail transactions layout (PI/PC, T1/T5/T0/T9 tax codes).
7. **Audit.** Every upload, edit, approval, rejection and post is logged per invoice.

## Run it locally

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                     # then edit .env
uvicorn app.main:app --reload
```

Open http://localhost:8000 and sign in with `ADMIN_USER` / `ADMIN_PASSWORD`.

To try it with test data, run `python samples/make_samples.py` and upload the four PDFs from `samples/`. They include a clean invoice, a wrong total, a missing VAT number and a credit note.

Run the tests with `python -m tests.test_pipeline`.

## Turn on AI reading

1. Create an API key at https://console.anthropic.com and add billing.
2. Put it in `.env` as `ANTHROPIC_API_KEY=...` and restart.

The default model is `claude-sonnet-5-5`. You can change `EXTRACTION_MODEL` to trade cost against accuracy. At under 1,000 invoices a month the API cost is small. Check current pricing on Anthropic's site before quoting the buyer.

## Connect Xero

1. Go to https://developer.xero.com/app/manage, choose **New app**, then **Web app**.
2. Set the redirect URI to your `XERO_REDIRECT_URI` (for example `https://invoices.yourdomain.com/xero/callback`).
3. Copy the client ID and secret into `.env` and restart.
4. In the app, open **Connections** and choose **Connect Xero**.

Xero apps created on or after 2 March 2026 must use granular scopes. The app requests `accounting.invoices`, `accounting.contacts`, `accounting.settings.read` and `accounting.attachments`.

## Deploy for the buyer

The simplest option is one small VPS (Hostinger, DigitalOcean or Hetzner) per client, running Docker:

```bash
docker build -t invoiceflow .
docker run -d --name invoiceflow -p 8000:8000 --env-file .env -v invoiceflow-data:/data invoiceflow
```

Put it behind HTTPS (Caddy, Nginx or Cloudflare) on a subdomain, and back up the `/data` volume. It holds the database and the original invoices.

## Before charging for it: production checklist

- [ ] Strong `ADMIN_PASSWORD` and random `SECRET_KEY`; HTTPS only.
- [ ] Daily backup of the data volume.
- [ ] A data processing agreement with the buyer (UK GDPR). Invoices contain personal data, and they're sent to the AI provider for reading.
- [ ] Test the CSV imports against the buyer's actual QuickBooks or Sage company file. Their tax codes and nominal codes may differ from the defaults.
- [ ] Agree support terms and response times.

## Roadmap ideas (phase 2)

- Email inbox capture (forward invoices to `bills@...`).
- Multiple users with approval limits (for example, over £1,000 needs a manager).
- Direct QuickBooks Online and Sage Accounting API posting.
- Three-way PO matching against purchase orders and goods received notes.
- Multi-client SaaS: tenant per buyer, PostgreSQL, Stripe billing.

## Project layout

```
app/
  main.py         web routes, login, review, posting, exports
  extraction.py   AI extraction + offline PDF text parser
  validation.py   UK VAT and accounting checks, duplicate detection
  pipeline.py     upload -> extract -> validate -> store; edits and approval
  exports.py      Xero / QuickBooks / Sage 50 CSV layouts
  xero.py         Xero OAuth2 and bill posting
  db.py           SQLite storage and audit log
  templates/      HTML pages
  static/         styles
samples/          sample invoice generator
tests/            end-to-end tests
```
